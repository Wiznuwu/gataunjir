let didYouMean = require("didyoumean2").default
let handler = (m) => m;
handler.before = async (m, { conn, usedPrefix, command }) => {
  conn.listPlug = conn.listPlug ? conn.listPlug : null;
  conn.listTags = conn.listTags ? conn.listTags : null;
  if (!m.text.match(global.prefix)) return;
 if (!m.isGroup && !db.data.chats["120363236413068628@g.us"].member.includes(m.sender) && !db.data.users[m.sender].premium) return;
const textTanpaTitik = m.text.replace(global.prefix, "");
const newText = textTanpaTitik.split(' ')[0];

  if (conn.listPlug === null || conn.listTags === null) {
  conn.listPlug = []
  conn.listTags = []
  let data = []
for (let key in global.plugins) {
  if (global.plugins.hasOwnProperty(key)) {
    const commands = global.plugins[key].command;
    const help = global.plugins[key].help;
    const tags = global.plugins[key].tags;
    if (Array.isArray(commands)) {
      conn.listPlug.push(...commands);
   } 
   if (Array.isArray(help)) {
   conn.listPlug.push(...help)
  }
 if (Array.isArray(tags)) {
   conn.listTags.push(...tags)
 }
}
 const baru = await conn.listPlug.map(element => element.split(' ')[0])
 conn.listPlug = baru
}
  } else {
    let maksud = await didYouMean(newText.toLowerCase(), conn.listPlug);
    if (newText.toLowerCase() === maksud || maksud === null) {
      return;
    } else {
      m.reply(`Command tidak ada.\napakah kamu mencari *.${maksud}*`);
    }
  }
};

module.exports = handler;