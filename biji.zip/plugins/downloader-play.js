const ytdl = require("@distube/ytdl-core");
const yts = require("yt-search");
const fs = require("fs");
const { pipeline } = require("stream");
const { promisify } = require("util");
const streamPipeline = promisify(pipeline);
const os = require("os");
const axios = require('axios');
const {
  generateWAMessageFromContent,
  proto,
  prepareWAMessageMedia,
} = require("@whiskeysockets/baileys");


function levenshtein(str1, str2) {
  const dp = [];

  // Initialize rows and columns
  for (let i = 0; i <= str1.length; i++) {
    dp[i] = new Array(str2.length + 1).fill(i);
  }

  for (let i = 1; i <= str2.length; i++) {
    dp[0][i] = i;
  }

  // Calculate Levenshtein distance
  for (let i = 1; i <= str1.length; i++) {
    for (let j = 1; j <= str2.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, // Deletion
        dp[i][j - 1] + 1, // Insertion
        dp[i - 1][j - 1] + (str1[i - 1] !== str2[j - 1] ? 1 : 0) // Substitution
      );
    }
  }

  return dp[str1.length][str2.length];
}

function trimYouTubeUrl(url) {
  return url.split("?")[0];
}

const handler = async (m, { conn, command, text, usedPrefix }) => {
  conn.play = conn.play || {};
  if (!text) throw `*Example:* ${usedPrefix + command} Kaguya love is war`;
  m.reply("*Wait, Processing Your Request...*");

  let url;
    const trimmedUrl = trimYouTubeUrl(text + " song");
    const search = await yts(trimmedUrl);
    if (!search) throw "Not Found, Try Another Title";
    const videos = search.videos;

    // Simple String Matching
    const simpleMatchScores = videos.map((video) => {
      const titleTokens = video.title.toLowerCase().split(" ");
      const queryTokens = text.toLowerCase().split(" ");
      const matchCount = titleTokens.filter((token) => queryTokens.includes(token)).length;
      return matchCount;
    });

    // Levenshtein Distance
    const levenshteinDistances = videos.map((video) => {
      return levenshtein(text.toLowerCase(), video.title.toLowerCase());
    });

    // Combine Scores
    const combinedScores = videos.map((video, i) => {
      const simpleMatchScore = simpleMatchScores[i];
      const levenshteinDistance = levenshteinDistances[i];
      const normalizedDistance = levenshteinDistance / (video.title.length + 1); // Normalize distance based on title length
      const combinedScore = simpleMatchScore - normalizedDistance; // Prioritize simple matches while considering Levenshtein distance
      return { ...video, combinedScore };
    });
    // Select Most Similar Video
    const mostSimilarVideo = combinedScores.sort((a, b) => b.combinedScore - a.combinedScore)[0]; // Select video with the highest combined score
    // Filter Similar Titles with Highest Views
    const similarTitleVideos = videos.filter(
      (video) => video.title.toLowerCase().includes(text.toLowerCase())
    );
    const highestViewSimilarTitleVideo = similarTitleVideos.sort((a, b) => {
      return b.views - a.views; // Sort by views in descending order
    });
    const vid = videos[0]; // Select the video with the highest views        
    const finalVideo = vid || mostSimilarVideo; // Choose video with highest views among similar titles, or fallback to most similar video if no similar titles found
    const { title, thumbnail, views, ago, url: videoUrl, seconds } = finalVideo;
     if (seconds > 3600) return m.reply("*[ DURATION TOO LONG ]*\nI cannot download media that exceeds *1 hour* duration.");
    const judul = title.replace(/\//g, "");
    const caption = `*• Caption:* ${title}\n*• Views:* ${views}\n*• Ago:* ${ago}\n*• Duration:* ${seconds} seconds\n*• Thumbnail:* ${thumbnail}\n*• Source Yt:* ${videoUrl}\n\n\`Pilih Audio/Video di bawah ini\``;
    let sections = [{

		rows: [{

	    title: 'AUDIO',

    	description: `Mengirim Audio`, 

    	id: `.ytmp3 ${videoUrl}`,

    	},

    	{

		title: 'VIDEO', 

		description: "Mengirim Video", 

		id: `.ytmp4 ${videoUrl}`
	    }]

     }]



let listMessage = {

    title: 'Video/Audio', 

    sections

};
let msg = generateWAMessageFromContent(m.chat, {

  viewOnceMessage: {

    message: {

        "messageContextInfo": {

          "deviceListMetadata": {},

          "deviceListMetadataVersion": 2

        },

        interactiveMessage: proto.Message.InteractiveMessage.create({

        contextInfo: {

        	mentionedJid: [m.sender], 

        	isForwarded: true, 

	        forwardedNewsletterMessageInfo: {

			newsletterJid: '120363279823265967@newsletter',

			newsletterName: 'Makima Channel Is Here.', 

			serverMessageId: -1

		},

	businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },

            externalAdReply: {  

                title: `${title}`, 

                thumbnailUrl: `${thumbnail}`, 

                sourceUrl: `${videoUrl}`,

                mediaType: 1,

                renderLargerThumbnail: true

            }

          }, 

          body: proto.Message.InteractiveMessage.Body.create({

            text: caption

          }),

          footer: proto.Message.InteractiveMessage.Footer.create({

            text: 'Powered By : ᴍᴇᴘʜɪsᴛᴏᴅ'

          }),

          header: proto.Message.InteractiveMessage.Header.create({

            title: `*[ YOUTUBE PLAY ]*`,

            subtitle: "Makima Bot",

            hasMediaAttachment: true,...(await prepareWAMessageMedia({ document: { url: 'https://wa.me/' }, mimetype: 'image/png', fileName: "[ Youtube Play ]", jpegThumbnail: await conn.resize("https://telegra.ph/file/651a478d9d2d7383eacf5.jpg", 400, 400), fileLength: 0 }, { upload: conn.waUploadToServer }))

,
          }),

          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({

            buttons: [              
              
              {

                "name": "single_select",

                "buttonParamsJson": JSON.stringify(listMessage) 

              },
           ],

          })

        })

    }

  }

}, { quoted: m})



await conn.relayMessage(msg.key.remoteJid, msg.message, {

  messageId: msg.key.id

})
};
handler.help = ["play *[query]*"];
handler.tags = ["downloader"];
handler.command = /^(play)$/i;
handler.limit = true;

handler.register = true;
module.exports = handler;