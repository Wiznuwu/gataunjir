const { googleImage } = require("@bochilteam/scraper"); // Assuming this is for illustrative purposes

let handler = async (m, { conn, args, usedPrefix, command }) => {
  try {
    let response = args.join(" ").split("--");
    let query = response[0];
    let jumlah = parseInt(response[1]);

    if (!query) throw `*• Example :* ${usedPrefix + command} *[query]*`;

    // Function to fetch and send a random image with retry logic
    async function fetchAndSendImage(attempt = 1) {
      try {
        const res = await Func.fetchJson(`https://api.betabotz.eu.org/api/search/googleimage?text1=${query}&apikey=${global.apibeta}`);
        let image = res.result[Math.floor(Math.random() * res.result.length)];
        let caption = `*[ GOOGLE IMAGE ]*
*• Result from :* ${query}`;

        await conn.sendMessage(m.chat, { image: { url: image.url }, caption: caption }, { quoted: m });
      } catch (error) {
        console.log(`Error fetching image on attempt ${attempt}: ${error}`);

        // Set a maximum number of retries to avoid infinite loops
        if (attempt < 10) {
          console.log(`Retrying image fetch for "${query}" (attempt ${attempt + 1})`);
          await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds before retry
          await fetchAndSendImage(attempt + 1);
        } else {
          console.log(`Failed to fetch image for "${query}" after ${attempt} attempts.`);
          m.reply("Gagal mengirim hasil gambar. Maaf atas ketidaknyamanan ini.");
        }
      }
    }

    if (!jumlah) {
      m.reply(wait);
      await fetchAndSendImage();
    } else {
      if (jumlah > 10) {
        throw "Kebanyakan bang ";
      }
      m.reply(wait);
      for (let i = 0; i < jumlah; i++) {
        await new Promise(resolve => setTimeout(resolve, i * 3000)); // Delay between images
        await fetchAndSendImage();
      }
    }
  } catch (error) {
    console.log(error);
    m.reply("Gagal mengirim hasil gambar");
  }
};

handler.help = ["gimage *[query]*", "image *[query]*"];
handler.tags = ["tools"];
handler.command = ["gimage", "image"];
handler.register = true;
module.exports = handler;