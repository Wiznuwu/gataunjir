console.log("✅ Starting.....");
console.clear();
const http = require("http");
const os = require("os");
const port = 3000; //custom ports here, sample: (8080,3000,5000) and others
const express = require("express");
const Cfonts = require("cfonts");
const app = express();
Cfonts.say("Lucy Maeril", { font: "tiny" });
app.get("/", (req, res) => {
  res.setHeader("Content-Type", "application/json");
  const data = {
    status: "true",
    message: "Kaguya is now running",
    author: "Lexic team",
  };

  const result = {
    response: data,
  };
  res.send(JSON.stringify(result, null, 2));
});

app.listen(port, () => {
  //console.log(`Listening on port ${port}`);
});

const cluster = require("cluster");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

let isRunning = false;

function start(file) {
  if (isRunning) return;
  isRunning = true;

  const args = [path.join(__dirname, file), ...process.argv.slice(2)];
  const p = spawn(process.argv[0], args, {
    stdio: ["inherit", "inherit", "inherit", "ipc"],
  });

  p.on("message", (data) => {
    console.log(`[ Syaii ]${data}`);
    switch (data) {
      case "reset":
        p.kill();
        isRunning = false;
        start.apply(this, arguments);
        break;
      case "uptime":
        p.send(process.uptime());
        break;
    }
  });

  p.on("exit", (code) => {
    isRunning = false;
    console.log(`❌ sistem bot mati dengan kode: ${code}`);

    if (code === 0) return;

    // Restart bot jika code null atau error
    if (code === null || code !== 0) {
      console.log("🔄 Bot restart karena null atau error...");
      start(file);
    }
  });

  p.on("error", (err) => {
    console.log("\x1b[31m%s\x1b[0m", `Error: ${err}`);
    p.kill();
    isRunning = false;
    start(file);
  });

  const pluginsFolder = path.join(__dirname, "plugins");

  fs.readdir(pluginsFolder, (err, files) => {
    if (err) {
      console.log(`Error reading plugins folder: ${err}`);
      return;
    }

    const chalk = require("chalk");
    let table = `${chalk.blue.bold("© MAKIMA - Bot made by MEPSHISTOD")}
${chalk.yellow.bold("-------------------------------------------------------------")}`;
    console.log(table);
  });

  setInterval(() => {}, 1000);
}

start("main.js");

process.on("unhandledRejection", () => {
  console.log(
    "\x1b[31m%s\x1b[0m",
    "Unhandled promise rejection. Script will restart...",
  );
  start("main.js");
});

process.on("exit", (code) => {
  console.log(`Exited with code: ${code}`);
  console.log("Script will restart...");
  start("main.js");
});
