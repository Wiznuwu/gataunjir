const cheerio = require('cheerio');
const PDFDocument = require('pdfkit');
const imageSize = require('image-size');
const fs = require("fs")
const didyoumean2 = require("didyoumean2").default;
const Jimp = require('jimp');

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
conn.komiku = conn.komiku ? conn.komiku : {};
if (!text) throw "> Contoh penggunaan\n.komiku search mushoku tensei\n.komiku solo leveling 9"
const keyword = text.split(" ")[0];
const data = text.slice(keyword.length + 1);
if (keyword === "search") {
if (!data) throw "masukan judul komik!"
try {
const title = await Scraper["Other"].fetchKomik(data)
let hasil = title
      .map(
        (v, index) =>
          `*${index + 1}.* *Title:* ${v.title}`,
      )
      .join("\n\n");
    let { key } = await conn.reply(m.chat, hasil, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "Komiku Downloader",
body: "Created by Mephistod",
thumbnailUrl: "https://files.catbox.moe/5ohkj9.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true,
},
},
});
    await conn.reply(
      m.chat,
      `Ketik angka *1 - ${title.length}* sesuai dengan pesan di atas`,
      null,
    );
    conn.komiku[m.sender] = {
       komik: title,
       pilih: true
       }
      } catch {
      m.reply("judul yang kamu cari tidak di temukan")
      }
} else {
try {
let words = text.split(' ');
let kapital = '';
let angka = null;
for (let i = 0; i < words.length; i++) {
let word = words[i];
if (!isNaN(Number(word))) {
angka = parseInt(word);
} else {
kapital += word.charAt(0).toUpperCase() + word.slice(1) + ' ';
}
}
kapital = kapital.trim(); 
let hasil = await Scraper["Other"].fetchKomik(kapital, angka)
let { judul, path } = hasil
let pdfnya = await fs.readFileSync(path)
await conn.sendMessage(m.chat, { document: pdfnya, mimetype: "application/pdf", fileName: judul, caption: `chapter ${angka}` }, { quoted: m });
await fs.unlinkSync(path);
} catch {
m.reply("> Contoh penggunaan\n.komiku search mushoku tensei\n.komiku solo leveling 9")
}
}
}
handler.before = async (m, { conn }) => {
    conn.komiku = conn.komiku ? conn.komiku : {};
    if (m.isBaileys) return;
    if (!m.text) return;
    if (!conn.komiku[m.sender]) return;
    if (conn.komiku[m.sender].pilih) {
    if (
      isNaN(m.text) ||
      m.text <= 0 ||
      m.text > conn.komiku[m.sender].komik.length
    ) return;      
    let pilihan = conn.komiku[m.sender].komik[m.text - 1].link
    let judul = conn.komiku[m.sender].komik[m.text - 1].title
const html = await Func.fetchJson(pilihan)
const $ = cheerio.load(html);
const chapterLinks = [];
$('#chapterlist ul li').each((index, element) => {
const chapterLink = $(element).find('a').attr('href');
chapterLinks.push(chapterLink);
});
let terbalik = chapterLinks.reverse()
let hasil = terbalik.length
await conn.reply(m.chat, `Anda memilih komik berjudul\n*${judul}*\nSilahlan pilih chapter berapa yang ingin anda download,\nada *${hasil}* chapter yang tersedia.\nsilahkan ketik *1 - ${hasil}* untuk memilih chapter\n\nJika anda ingin membatch anda bisa memilih chapter yang ingin anda batch.\nContoh penggunaan:\nketik *10 20* untuk membtach chapter 10 - 20.\n\nketik *10* untuk memilih chapter 10`, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "Komiku Downloader",
body: "Created by Mephistod",
thumbnailUrl: "https://files.catbox.moe/5ohkj9.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true,
},
},
});    
conn.komiku[m.sender].pilih = false
conn.komiku[m.sender].pilihan = terbalik
conn.komiku[m.sender].judul = judul
} else {
let range = m.text.split(' ');  
if (range.length === 1) {
 if (
isNaN(range[0])
) return;
let chapter = parseInt(range[0]);
if (chapter > conn.komiku[m.sender].pilihan.length) return;
let pilihan = conn.komiku[m.sender].pilihan[chapter - 1];
let judul = conn.komiku[m.sender].judul;
console.log(pilihan);
const regex = /https?:\/\/cdn\.uqni\.net\/images\/[0-9]+\/[a-zA-Z-]+\/chapter-[0-9]+\/[0-9]+\.jpg/g;
const html = await Func.fetchJson(pilihan);
m.reply(wait);
try {
let images = [];
if (html.match(regex)) {
images = html.match(regex);
} else {
images = await chapterLink(pilihan);
}
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
for (let i = 0; i < images.length; i++) {
const link = images[i];
try {
const buffer = await conn.getBuffer(link);
const dimensions = imageSize(buffer);
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth;
const pageHeight = imgHeight + 100;
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(buffer, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Image ${i + 1}`, 250, 550);
} catch (error) {
console.log(`Error fetching image ${i + 1}: ${error.message}`);
continue;
}
}
const pdfStream = fs.createWriteStream('output.pdf');
pdf.pipe(pdfStream);
pdf.end();
pdfStream.on('finish', () => {
const hasilpdf = fs.readFileSync("output.pdf");
conn.sendMessage(m.chat, { document: hasilpdf, mimetype: "application/pdf", fileName: judul, caption: `chapter ${chapter}` }, { quoted: m });
fs.unlinkSync('output.pdf');
delete conn.komiku[m.sender];
});
} catch {
m.reply("Chapter tidak tersedia. gunakan *.komiku search (nama komik) untuk melihat chapter)");
}
} else if (range.length === 2) {
 if (
isNaN(range[0]) || isNaN(range[1])
) return;
if (range[1] < range[0]) return m.reply("masukan chapter yang valid!\ncontoh: 1 10")
let jumlahan = Math.abs(range[0] - range[1])
console.log(jumlahan)
if (jumlahan > 10) return m.reply("Jumlah tidak bisa lebih dari 10!\ncontoh: 5 15")
try {
m.reply(wait)
let start = parseInt(range[0]);
let end = parseInt(range[1]);
if (start > conn.komiku[m.sender].pilihan.length || end > conn.komiku[m.sender].pilihan.length) return;
let judul = conn.komiku[m.sender].judul;
let images = [];
for (let i = start - 1; i <= end - 1; i++) { // changed from < to <=
let pilihan = conn.komiku[m.sender].pilihan[i];
const html = await Func.fetchJson(pilihan);
const regex = /https?:\/\/cdn\.uqni\.net\/images\/[0-9]+\/[a-zA-Z-]+\/chapter-[0-9]+\/[0-9]+\.jpg/g;
let chapterImages = [];
if (html.match(regex)) {
chapterImages = html.match(regex);
} else {
chapterImages = await chapterLink(pilihan);
}
images = images.concat(chapterImages);
}
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
for (let i = 0; i < images.length; i++) {
const link = images[i];
try {
const buffer = await conn.getBuffer(link);
const kecilkan = await compressImage(buffer);
const dimensions = imageSize(kecilkan);
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth;
const pageHeight = imgHeight + 100;
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(kecilkan, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Image ${i + 1}`, 250, 550);
} catch (error) {
console.log(`Error fetching image ${i + 1}: ${error.message}`);
continue;
}
}
const pdfStream = fs.createWriteStream('output.pdf');
pdf.pipe(pdfStream);
pdf.end();
pdfStream.on('finish', () => {
const hasilpdf = fs.readFileSync("output.pdf");
conn.sendMessage(m.chat, { document: hasilpdf, mimetype: "application/pdf", fileName: judul, caption: `chapter ${start} - ${end}` }, { quoted: m });
fs.unlinkSync('output.pdf');
delete conn.komiku[m.sender]
})
} catch {
m.reply("Chapter tidak tersedia. gunakan *.komiku search (nama komik) untuk melihat chapter)")
}
}
}
}
handler.help = ["komiku"].map((a) => a + " *[judul]*");
handler.tags = ["downloader"];
handler.command = ["komiku"];
handler.register = true;
handler.limit = true;

module.exports = handler;

async function fetchAllComicTitles(url, maxPages) {
async function getComicTitles(html) {
const $ = require('cheerio').load(html);
const titles = [];
$('.bigor .tt').each((i, el) => {
titles.push({
title: $(el).text().trim(),
link: $(el).closest('a').attr('href')
});
});
return titles;
}
async function fetchComicTitles(judul, page, maxPages) {
const url = 'https://kiryuu.org/'
const html = await Func.fetchJson(url + `page/${page}/?s=${judul}`);
const titles = await getComicTitles(html);
if (titles.length === 0) {
return [];
}
return titles.concat(await fetchComicTitles(url, page + 1, maxPages));
}
const allTitles = await fetchComicTitles(url, 1, maxPages);
return allTitles;
}

function chapterLink(url) {
return new Promise((resolve, reject) => {
Func.fetchJson(url)
.then(html => {
const $ = cheerio.load(html);
const noscriptHtml = $('#readerarea noscript').html();
const imageLinks = [];
const regex = /src=['"]([^'"]+)['"]/g;
let match;
while ((match = regex.exec(noscriptHtml)) !== null) {
const src = match[1];
imageLinks.push(src);
}
resolve(imageLinks);
})
.catch(reject);
});
}

function compressImage(buffer) {
return new Promise((resolve, reject) => {
Jimp.read(buffer)
.then(image => {
image.quality(15); // adjust the quality to reduce file size
return image.getBufferAsync(Jimp.MIME_JPEG);
})
.then(compressedBuffer => {
resolve(compressedBuffer);
})
.catch(err => {
reject(err);
});
});
}