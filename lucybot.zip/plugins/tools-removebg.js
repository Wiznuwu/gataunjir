let fetch = require("node-fetch");
let uploadImage = require("../lib/uploadImage.js");
let axios = require("axios")
const fs = require('fs')
const https = require('https');
const FormData = require('form-data');

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let who =
    m.mentionedJid && m.mentionedJid[0]
      ? m.mentionedJid[0]
      : m.fromMe
        ? conn.user.jid
        : m.sender;
  let name = await conn.getName(who);
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw "Kirim/Reply Gambar dengan caption .removebg";
  m.reply("Tunggu Sebentar...");
  let media = await q.download();
  let url = await Uploader.catbox(media)
  removeBackground(url, "tz1pVFrP9w2Z3hjfDy64sLtz")
  setTimeout(() => {
  let img = fs.readFileSync("no-bg.png")
   conn.sendMessage(m.chat, { image: img, caption: "*Sukses menghapus background*" }, { quoted: m }).then(() => {
        fs.unlinkSync("no-bg.png")
      });
  }, 10000); 
}
handler.help = ["removebg *[reply/send img]*"];
handler.tags = ["tools"];
handler.command = ["hapuslatar", "removebg", "nobg"]
handler.limit = true;

handler.register = true;
module.exports = handler;

async function removeBackground(imageUrl, apiKey, outputFilename = 'no-bg.png') {
  try {
    const formData = new FormData();
    formData.append('image_url', imageUrl);
    formData.append('size', 'auto'); // Or set a specific size as needed

    const requestOptions = {
      method: 'POST',
      hostname: 'api.remove.bg',
      path: '/v1.0/removebg',
      headers: {
        'X-API-Key': apiKey,
        ...formData.getHeaders(), // Include headers from FormData
      },
    };

    const req = https.request(requestOptions, (res) => {
      if (res.statusCode !== 200) {
        throw new Error(`Error: ${res.statusCode} ${res.statusMessage}`);
      }

      const fileStream = fs.createWriteStream(outputFilename);
      res.pipe(fileStream);

      fileStream.on('finish', () => {
        console.log(`Background removed successfully. Image saved to ${outputFilename}`);       
      });

      fileStream.on('error', (err) => {
        console.error(`Error saving image: ${err}`);
      });
    });

    formData.pipe(req);
    req.end();
  } catch (error) {
    console.error(`Error removing background: ${error}`);
  }
}