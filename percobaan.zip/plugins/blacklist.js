let handler = async (m, { conn, text, command }) => { 
if (!text) throw `contoh\n.blacklist *tag/reply*`
switch (command) {
case "blacklist": {
conn.listBisu = conn.listBisu ? conn.listBisu : []
let who = m.quoted?.sender || m.mentionedJid?.[0];
conn.listBisu.push(who)
m.reply("Sukses memblacklist user")
  }
break;
case "unblacklist": {
conn.listBisu = conn.listBisu ? conn.listBisu : []
let who = m.quoted?.sender || m.mentionedJid?.[0];
let hapus = conn.listBisu.filter(item => item && item !== who);
conn.listBisu = hapus
m.reply("Sukses unblacklist user")
   }
break
 }
}
 handler.before = async (m, { conn, usedPrefix }) => {
 conn.listBisu = conn.listBisu ? conn.listBisu : []
    if (conn.listBisu === []) return
    if (conn.listBisu.includes(m.sender) && m.text.match(global.prefix)) {
      return await conn.sendMessage(m.chat, { delete: { ...m.key }});
    }
    if (conn.listBisu.includes(m.sender)) {
     return await conn.sendMessage(m.chat, { delete: { ...m.key }});
    }
  }
handler.command = ["blacklist", "unblacklist"];
handler.botAdmin = true;
handler.rowner = true;
handler.register = true;
module.exports = handler;