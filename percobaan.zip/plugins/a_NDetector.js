let handler = (m) => m;
handler.before = async (m, { conn, usedPrefix, isBotAdmin, isAdmin, command }) => {
let isFoto = m.mtype
  let mime = (m.msg || m).mimetype || "";
if (!isFoto === "imageMessage") return;
if (/webp/.test(mime)) return;
  if (!db.data.chats[m.chat].isNDetector) return;
  if (m.text.match(global.prefix)) return;
  if (!/image/.test(mime)) return;
  if (!isBotAdmin) return;
  let media = await m.download()
  let link = await Uploader.catbox(media).catch(async _ => await Uploader.telegraPh(media))
  let data = await Func.fetchJson(`https://api.betabotz.eu.org/api/tools/nsfw-detect?url=${link}&apikey=${global.apibeta}`)
  console.log(data)
  if (data.result.labelName.includes("NSFW")) {
  m.reply("*[ NSFW DETECTED ]*\nTolong jangan mengirim gambar tidak senonoh di grub ini")
  return conn.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant,
          },
        });
  } else {
  return;
 }
}
module.exports = handler;