const fs = require('fs');
const didyoumean2 = require("didyoumean2").default;

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    if (!args[0]) {
        return m.reply('Silakan berikan nama karakter');
    }

    let characterName = args[0].toLowerCase();
    let filePath = `/home/container/lib/genshin.json`;

    try {
        let tersedia = Object.keys(JSON.parse(fs.readFileSync(filePath)));
        if (!tersedia.includes(characterName)) {
            let maksud = await didyoumean2(characterName, tersedia);
            let apala = maksud === null ? "Character yang kamu cari tidak ada" : `apakah character yang kamu maksud adalah *${maksud}*?`;
            m.reply(apala);
        } else {
            m.reply(wait);

            // Ubah nama karakter ke huruf kecil agar sesuai dengan nama file
            let buildData = JSON.parse(fs.readFileSync(filePath))[characterName].build;
            let materialData = JSON.parse(fs.readFileSync(filePath))[characterName].material;

            await conn.sendFile(m.chat, buildData, 'image.jpg', `*\`[ BUILD ]\`*\nMenampilkan Build *[ ${characterName} ]*`, m);
            await conn.sendFile(m.chat, materialData, 'image.jpg', `*\`[ MATERIAL ]\`*\nMenampilkan Material *[ ${characterName} ]*`, m); // Assuming materialData is sent separately
        }
    } catch (error) {
        console.error(error);
        m.reply('Error: ' + error.message);
    }
};

handler.help = ["build *[nama karakter]*"];
handler.tags = ["genshin"];
handler.command = ["build", "buildgi"];
module.exports = handler;