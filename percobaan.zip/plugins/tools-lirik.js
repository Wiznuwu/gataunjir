let handler = async (m, { conn, text }) => {
if (!text) throw "Masukan judul atau lirik lagu"
m.reply(wait)
let lirik = await Func.fetchJson(`https://api.betabotz.eu.org/api/search/lirik?lirik=${text}&apikey=${global.apibeta}`)
let { lyrics, title, artist, image } = lirik.result
let pesan = `Judul: ${title}\nArtist: ${artist}\n\nLyrics:\n${lyrics}`
await conn.sendMessage(m.chat, { image: { url: image }, caption: pesan }, { quoted: m })
};
handler.command = ["lirik", "lyrics"]
handler.help = ["lyrics *[judul lagu]*"]
handler.tags = ["tools"]
handler.limit = true;
module.exports = handler;