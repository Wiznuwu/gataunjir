let { webp2png } = require("../lib/webp2mp4");
let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted) throw `balas stiker dengan caption *${usedPrefix + command}*`;
  let mime = m.quoted.mimetype || "";
  if (!/webp/.test(mime))
    throw `balas stiker dengan caption *${usedPrefix + command}*`;
  let media = await m.quoted.download();
  let link = await Uploader.catbox(media)
  let hasil = await Func.fetchJson(`https://api.betabotz.eu.org/api/tools/webp2png?url=${link}&apikey=${global.apibeta}`)
  await conn.sendMessage(
    m.chat,
    { image: { url: hasil.result }, caption: "*DONE*" },
    { quoted: m },
  );
};
handler.help = ["toimg *[reply]*"];
handler.tags = ["sticker","tools"];
handler.command = ["toimg"];
handler.register = true;
module.exports = handler;