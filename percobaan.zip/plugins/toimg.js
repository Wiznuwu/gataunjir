const sharp = require('sharp');

async function convertWebPToJPEG(media, quality = 90) {
  try {
    const jpegBuffer = await sharp(media)
      .jpeg({ quality: quality })
      .toBuffer();
    return jpegBuffer;
  } catch (error) {
    console.error('Error during conversion:', error);
    throw error; // Melempar kembali error untuk ditangani di luar
  }
}

let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted) throw `balas stiker dengan caption *${usedPrefix + command}*`;
  let mime = m.quoted.mimetype || "";
  if (!/webp/.test(mime))
    throw `balas stiker dengan caption *${usedPrefix + command}*`;
    let media = await m.quoted.download();
    const jpegBuffer = await convertWebPToJPEG(media, 90);
    await conn.sendMessage(
    m.chat,
    { image: jpegBuffer, caption: "*DONE*" },
    { quoted: m },
  );
};
handler.help = ["toimg *[reply]*"];
handler.tags = ["sticker","tools"];
handler.command = ["toimg"];
handler.register = true;
module.exports = handler;