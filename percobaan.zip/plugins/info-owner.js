let handler = async (m, { conn, text, usedPrefix, command }) => {
const pp = "https://telegra.ph/file/241b747767455c4bcfc7b.jpg"
  let nomor = global.owner;
  let list = [
    {
      displayName: 'Mephistod',
  vcard: 'BEGIN:VCARD\n' +
    'VERSION:3.0\n' +
    'N:;Mephistod;;;\n' +
    'FN:Mephistod\n' +
    'item1.TEL;waid=6285161703966:+62 851-6170-3966\n' +
        'item1.X-ABLabel:Click here to chat\n' +
        'item2.EMAIL;type=INTERNET:YouTube: -\n' +
        'item2.X-ABLabel:YouTube\n' +
        'item3.URL:GitHub: -\n' +
        'item3.X-ABLabel:GitHub\n' +
        'item4.ADR:;;Indonesia, West Java, North Jakarta;;;;\n' +
        'item4.X-ABLabel:Region\n' +
        'END:VCARD'
    }
  ]
               let { key } = await conn.sendMessage(m.chat, {
                    contacts: {
                        displayName: `${list.length} Contact`,
                        contacts: list
                    }, contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: 'Makima Bot',
                                body: 'Mephistod',
                                thumbnailUrl: pp,
                                sourceUrl: 'https://whatsapp.com/channel/0029VaVGWDa8V0teNLJGWF0e',
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                }, {
                    quoted: m
                })
                conn.sendMessage(m.chat, { text: "Jika nomor kamu di kirim bug, jangan protes ke owner, owner ga tau apa apa :p" }, { quoted: key })
            };
handler.help = ["owner", "creator"].map((a) => a + " *[Contact Owner]*");
handler.tags = ["info"];
handler.command = ["owner", "creator"];

handler.register = true;
module.exports = handler;