let { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
function processChatMessages(message) {
  // Split the message by commas
  const chatParts = message.split('##');

  // Initialize the combined message
  let combinedMessage = "";

  // Iterate through each part
  for (const part of chatParts) {
    // Trim the part
    const trimmedPart = part.trim();

    // Check if the part is not empty
    if (trimmedPart !== '') {
      // Add the part to the combined message with a newline
      combinedMessage += trimmedPart + '\n';
    }
  }

  // Remove trailing newline
  return combinedMessage.trim();
}

function filterChatMessages(chat, maxChats) {
  const messages = chat.split('##').reverse();
  if (messages.length <= maxChats) {
    return 
  }
  // Remove the last message
  messages.pop();
  // Slice and Join the remaining messages
  const filteredMessages = messages.slice(-maxChats);
  return filteredMessages.reverse().join('##');
}



let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.cai = conn.cai ? conn.cai : {};
  let name = m.sender;
  if (!text)
    throw `*• Example:* ${usedPrefix + command} *[on/off]*
*• Example search Chara:* ${usedPrefix + command} search *[characters name]*`;
  const keyword = text.split(" ")[0];
  const data = text.slice(keyword.length + 1);
  if (keyword === "search") {
    if (!data) throw `*• Example:* ${usedPrefix + command} ${keyword} Hutao`;
    m.reply(`_🔍searching data.... *[ ${data} ]*_`);
    let search = await Func.fetchJson(
      "https://api.apigratis.site/cai/search_characters?query=" + data,
    );
    let karakter = search.result.characters
      .map(
        (a, index) => `*[ ${index + 1}. ${a.participant__name} ]*
*• Greeting:* \`${a.greeting}\`
*• Visibility:* ${a.visibility}
*• Creator:* ${a.user__username}`,
      )
      .join("\n\n");
    const reply = await conn.reply(m.chat, karakter, fkontak, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: search.result.characters[0].participant__name,
          body: search.result.characters[0].greeting,
          thumbnailUrl:
            search.result.characters[0].avatar_file_name,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true,
        },
      },
    });
    await conn.reply(
      m.chat,
      `*[ KETIK ANGKA 1 SAMPAI ${search.result.characters.length} ]*
> • _! Pilih karakter anda dengan mengetik *.cai set (nomor urut)* sesuai dengan pesan diatas_`,
      reply,
    );
    conn.cai[m.sender] = {
      pilih: search.result.characters,
    };
  } else if (keyword === "set") {
    if (!conn.cai[m.sender])
      throw `*[ KAMU BELUM MENCARI CHARACTER ]*
> _ketik *.cai search* untuk mencari characters favorit mu_`;
    if (!conn.cai[m.sender].pilih)
      throw `*[ KAMU SUDAH PUNYA CHARACTER ]*
> _ketik *.cai search* untuk menganti characters_`;
    if (!data) throw `*• Example:* ${usedPrefix + command} ${keyword} 1`;
    let pilihan = conn.cai[m.sender].pilih[data - 1];
    let info = await Func.fetchJson(
      "https://api.apigratis.site/cai/character_info?external_id=" +
        pilihan.external_id,
    );
    let caption = `*[ INFO CHARACTERS NO ${data} ]*
*• Name:* ${pilihan.participant__name}
*• Greeting:* \`${pilihan.greeting}\`
*• Visibily:* ${pilihan.visibility}
*• Info:* Ketik *.cai* on untuk memulai
*• Refresh:* Ketik *.cai fix* untuk mengganti jawaban dari Ai`
    let q = await conn.reply(m.chat, caption, m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: pilihan.participant__name,
          body: pilihan.greeting,
          thumbnailUrl:
            pilihan.avatar_file_name,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true,
        },
      },
    });
    let hmm = await conn.getBuffer(pilihan.avatar_file_name)
    conn.cai[m.sender] = {
      isChats: false,
      id: pilihan.external_id,
      thumb: hmm,
      name: pilihan.participant__name,
    };
  } else if (keyword === "on") {
    if (!conn.cai[m.sender])
      throw `*[ KAMU BELUM MENCARI CHARACTER ]*
> _ketik *.cai search* untuk mencari characters favorit mu_`;
    conn.cai[m.sender].isChats = true;
    conn.sendMessage(m.chat, {
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: "C.Ai",
                            body: "SELAMAT MENGHALU",
                            previewType: "PHOTO",
                            thumbnailUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKUwr3DSjexBilKKg_-8FuDSdsd60-IWGqsTlWHIakg&s",
                            sourceUrl: "",
                        }
                    },
                    text: "_*[ ✓ ] Room chat berhasil dibuat*_"
                })
  } else if (keyword === "off") {
    if (!conn.cai[m.sender])
      throw `*[ KAMU BELUM MENCARI CHARACTER ]*
> _ketik *.cai search* untuk mencari characters favorit mu_`;
    conn.cai[m.sender].isChats = false;
    conn.sendMessage(m.chat, {
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: "C.Ai",
                            body: null,
                            previewType: "PHOTO",
                            thumbnailUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKUwr3DSjexBilKKg_-8FuDSdsd60-IWGqsTlWHIakg&s",
                            sourceUrl: "",
                        }
                    },
                    text: "_*[ ✓ ] Berhasil keluar dari Room chat*_"
                })
  } else if (keyword === "fix") {
 if (!conn.cai[m.sender].isChats) throw `*[ KAMU BELUM MEMULAI PERCAKAPAN ]*
> _ketik *.cai on* untuk membuat room chat dengan character_`;
    m.reply("_*Jawaban Anda Akan Segera Di Perbarui....*_");   
    try { 
    let currentChat = conn.cai[m.sender].chats || "";   
    m.quoted ? m.quoted.delete() : ''
    const maxChatLines = 6;
let messages = currentChat.split('##').slice(-maxChatLines);
messages.pop(); // Remove the last message (most recent)
const updatedChatLog = messages.join('##');
const modifiedMessages = await processChatMessages(updatedChatLog);
    let { data } = await axios.post(
        `https://api.apigratis.site/cai/send_message`, {
            external_id: conn.cai[m.sender].id,
            message: `*Lanjutan Roleplay Menggunakan Bahasa Indonesia*\n\n(Saat ini Kamu sedang berbicara dengan ${conn.getName(name)}, berikan jawaban sesuai konteks percakapan)\nkonteks percakapan:\n${modifiedMessages})`
        }
    );
let sections = [{
		title: 'Opsi Cai ( Character Ai )', 
		highlight_label: '',
		rows: [{
	    title: '⟩「Ganti Jawaban」',
    	description: `mengganti jawaban bot`, 
    	id: '.cai fix'    	
	    },
	    {
	    title: '⟩「Reset Chat」',
    	description: `mereset chat karakter`, 
    	id: '.cai reset'    	
	    },
        {
	    title: '⟩「Keluar Dari Chat」',
    	description: `Menghapus session`, 
    	id: '.cai off'    	
	    }]
     }]


let listMessage = {
    title: 'Options', 
    sections
};
    let msg = generateWAMessageFromContent(m.chat, {

  viewOnceMessage: {

    message: {

        "messageContextInfo": {

          "deviceListMetadata": {},

          "deviceListMetadataVersion": 2

        },

        interactiveMessage: proto.Message.InteractiveMessage.create({

        contextInfo: {

        	mentionedJid: [m.sender], 

        	isForwarded: true, 

	        forwardedNewsletterMessageInfo: {

			newsletterJid: '120363279823265967@newsletter',

			newsletterName: 'Makima Channel Is Here.',

			serverMessageId: -1

		},

	businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },

            externalAdReply: {  

                title: '[ Beta ] C.ai', 

                thumbnailUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKUwr3DSjexBilKKg_-8FuDSdsd60-IWGqsTlWHIakg&s', 

                sourceUrl: 'C.ai',

                mediaType: 1,

                renderLargerThumbnail: false

            }

          }, 

          body: proto.Message.InteractiveMessage.Body.create({

            text: data.result.replies[0].text

          }),

          footer: proto.Message.InteractiveMessage.Footer.create({

            text: ''

          }),

          header: proto.Message.InteractiveMessage.Header.create({

            title: ``,

            subtitle: "Makima Bot",

            hasMediaAttachment: true,...(await prepareWAMessageMedia({ document: { url: 'https://wa.me/' }, mimetype: 'image/png', fileName: conn.cai[m.sender].name, jpegThumbnail: conn.cai[m.sender].thumb, fileLength: 0 }, { upload: conn.waUploadToServer }))

,
          }),

          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({

            
          buttons: [              

              {

                "name": "single_select",

                "buttonParamsJson": JSON.stringify(listMessage) 

              }]

          })

        })

    }

  }

}, { quoted: m})



await conn.relayMessage(msg.key.remoteJid, msg.message, {

  messageId: msg.key.id

})
                console.log(modifiedMessages)
                currentChat = updatedChatLog
  const newChat = `${conn.cai[m.sender].name}: ${data.result.replies[0].text}`;
  conn.cai[m.sender].chats = currentChat + "##" + newChat;
  } catch {
  m.reply("Terjadi Error...\n\nKetik .cai fix untuk mencoba mengganti pesan")
  }
 } else if (keyword === "reset") {
  conn.cai[m.sender].chats = null
  conn.sendMessage(m.chat, {
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: "C.Ai",
                            body: "SELAMAT MENGHALU",
                            previewType: "PHOTO",
                            thumbnailUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKUwr3DSjexBilKKg_-8FuDSdsd60-IWGqsTlWHIakg&s",
                            sourceUrl: "",
                        }
                    },
                    text: "_*[ ✓ ] Berhasil Mereset Percakapan*_"
                })
} else {
 throw `*• Example:* ${usedPrefix + command} *[on/off]*
*• Example search Chara:* ${usedPrefix + command} search *[characters name]*`;
 }
};

handler.before = async (m, { conn, usedPrefix }) => {
  conn.cai = conn.cai ? conn.cai : {};
  const isROwner = [
        conn.decodeJid(global.conn.user.id),
        ...global.owner.map(a => a + "@s.whatsapp.net")
      ].includes(m.sender);
  if (!m.text) return;
  if (m.text.includes("♻️ GANTI JAWABAN")) return;
  if (m.text.includes("⚠️ RESET PERCAKAPAN")) return;
  if (m.text.match(global.prefix)) return; // Ignore bot commands
  if (!conn.cai[m.sender] || !conn.cai[m.sender].isChats) return;
  if (m.isGroup && !isROwner && m.quoted.fromMe) return;
  if (m.isGroup && !m.quoted.fromMe) return;
  try {
  let name = m.sender;
  let currentChat = conn.cai[m.sender].chats || "";
const modifiedMessages = await processChatMessages(currentChat);
console.log(modifiedMessages);
  let { data } = await axios.post(
 `https://api.apigratis.site/cai/send_message`, { external_id: conn.cai[m.sender].id, message: `*Lanjutan Roleplay Menggunakan Bahasa Indonesia*\n\n(Saat ini Kamu sedang berbicara dengan ${conn.getName(name)}, berikan jawaban sesuai konteks percakapan)\nkonteks percakapan:\n${modifiedMessages}\n\n${conn.getName(name)}: ${m.text}` });
let sections = [{
		title: 'Opsi Cai ( Character Ai )', 
		highlight_label: '',
		rows: [{
	    title: '⟩「Ganti Jawaban」',
    	description: `mengganti jawaban bot`, 
    	id: '.cai fix'    	
	    },
	    {
	    title: '⟩「Reset Chat」',
    	description: `mereset chat karakter`, 
    	id: '.cai reset'    	
	    },
        {
	    title: '⟩「Keluar Dari Chat」',
    	description: `Menghapus session`, 
    	id: '.cai off'    	
	    }]
     }]

let listMessage = {
    title: 'Options', 
    sections
};
  let msg = generateWAMessageFromContent(m.chat, {

  viewOnceMessage: {

    message: {

        "messageContextInfo": {

          "deviceListMetadata": {},

          "deviceListMetadataVersion": 2

        },

        interactiveMessage: proto.Message.InteractiveMessage.create({

        contextInfo: {

        	mentionedJid: [m.sender], 

        	isForwarded: true, 

	        forwardedNewsletterMessageInfo: {

			newsletterJid: '120363279823265967@newsletter',

			newsletterName: 'Makima Channel Is Here.',

			serverMessageId: -1

		},

	businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },

            externalAdReply: {  

                title: '[ Beta ] C.ai', 

                thumbnailUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKUwr3DSjexBilKKg_-8FuDSdsd60-IWGqsTlWHIakg&s', 

                sourceUrl: 'C.ai',

                mediaType: 1,

                renderLargerThumbnail: false

            }

          }, 

          body: proto.Message.InteractiveMessage.Body.create({

            text: data.result.replies[0].text

          }),

          footer: proto.Message.InteractiveMessage.Footer.create({

            text: ''

          }),

          header: proto.Message.InteractiveMessage.Header.create({

            title: ``,

            subtitle: "Makima Bot",

            hasMediaAttachment: true,...(await prepareWAMessageMedia({ document: { url: 'https://wa.me/' }, mimetype: 'image/png', fileName: conn.cai[m.sender].name, jpegThumbnail: conn.cai[m.sender].thumb, fileLength: 0 }, { upload: conn.waUploadToServer }))

,
          }),

          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({

                        buttons: [              

              {

                "name": "single_select",

                "buttonParamsJson": JSON.stringify(listMessage) 

              }]

          })

        })

    }

  }

}, { quoted: m})

await conn.relayMessage(msg.key.remoteJid, msg.message, {

  messageId: msg.key.id

})
  // Store the key from the reply in handler.before
  const newChat = `${conn.getName(name)}: ${m.text}##${conn.cai[m.sender].name}: ${data.result.replies[0].text}`;
  conn.cai[m.sender].chats = currentChat + "##" + newChat;
  } catch {
  m.reply('Maaf terjadi kesalahan...\n\nkirim ulang pesan agar bot dapat merespon')
  }
};
handler.help = ["cai"].map((a) => a + " *[beta cai]*");
handler.tags = ["ai","cai","premium"];
handler.command = ["cai"];
handler.premium = true;
handler.private = true
handler.register = true;
module.exports = handler