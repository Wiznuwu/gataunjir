let handler = async (m, { teks, conn, command, isOwner, isAdmin, args }) => {
    conn.listBisu = conn.listBisu || [];
    let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";

    switch (command) {
        case "blacklist": {
            if (m.quoted) {
                if ([ownerGroup, conn.user.jid].includes(m.quoted.sender)) return;
                conn.listBisu.push(m.quoted.sender);
                m.reply("Sukses memblacklist user");
                return;
            }
            if (!m.mentionedJid[0]) throw `*• Example :* .blacklist *[reply/tag user]*`;
            let users = m.mentionedJid.filter(
                (u) => ![ownerGroup, conn.user.jid].includes(u)
            );
            for (let user of users) {
                if (user.endsWith("@s.whatsapp.net")) {
                    conn.listBisu.push(user);
                }
            }
            m.reply("Sukses memblacklist user");
            break;
        }

        case "unblacklist": {
            if (m.quoted) {
                if ([ownerGroup, conn.user.jid].includes(m.quoted.sender)) return;
                conn.listBisu = conn.listBisu.filter(item => item !== m.quoted.sender);
                m.reply("Sukses unblacklist user");
                return;
            }
            if (!m.mentionedJid[0]) throw `*• Example :* .unblacklist *[reply/tag user]*`;
            let users = m.mentionedJid.filter(
                (u) => ![ownerGroup, conn.user.jid].includes(u)
            );
            conn.listBisu = conn.listBisu.filter(item => !users.includes(item));
            m.reply("Sukses unblacklist user");
            break;
        }
    }
};

handler.before = async (m, { conn, usedPrefix }) => {
    conn.listBisu = conn.listBisu || [];
    if (conn.listBisu.length === 0) return;
    if (conn.listBisu.includes(m.sender)) {
        await conn.sendMessage(m.chat, { delete: { ...m.key } });
    }
};

handler.command = ["blacklist", "unblacklist"];
handler.botAdmin = true;
handler.rowner = true;
handler.register = true;

module.exports = handler;