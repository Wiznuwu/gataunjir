//*Fitur by Mephistod (Wisnu)*
//

const axios = require('axios');
async function fetchLumin(content, user, prompt, image) {
try {
const payload = {
content: content,
user: user,
prompt: prompt,
imageBuffer: image,
};
const response = await axios.post('https://luminai.my.id/', payload);
console.log(response.data);
return response.data.result;
} catch (error) {
console.error(error);
throw error;
}
}
function generateRandomUserId() {
return 'user-' + Math.floor(Math.random() * 10000);
}
let picture = ["https://files.catbox.moe/efswka.jpg", "https://files.catbox.moe/micnho.jpg", "https://files.catbox.moe/1zh821.jpg"]
let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) return m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
const [commandName, ...args] = text.split(/\s+/);
if (commandName.toLowerCase() === "start") {
conn.luminAi = conn.luminAi || {};
let userId = generateRandomUserId();
conn.luminAi[m.sender] = {
userName: conn.getName(m.sender),
id: userId,
pictM: picture[Math.floor(Math.random() * picture.length)]
};
m.reply(`Hai!, Makima ai siap di gunakan`)
} else if (commandName.toLowerCase() === "stop") {
if (conn.luminAi[m.sender]) {
clearTimeout(conn.luminAi[m.sender].timeoutId);
delete conn.luminAi[m.sender];
m.reply("Sesi chat dengan LuminAI telah dihentikan.");
} else {
m.reply("Tidak ada sesi chat LuminAI yang aktif saat ini.");
 }
} else if (commandName.toLowerCase() === "reset") {
if (conn.luminAi[m.sender]) {
let userId = generateRandomUserId();
conn.luminAi[m.sender].id = userId
m.reply("Sukses mereset sesi.");
} else {
m.reply("Tidak ada sesi chat LuminAI yang aktif saat ini.");
 }
} else {
m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
}
};
handler.before = async (m, { conn, usedPrefix }) => {
conn.luminAi = conn.luminAi || {};
if (m.isGroup && !m.sender.includes(idOwner)) return;
if (m.isGroup && !m.quoted) return;
if (m.quoted && !m.quoted.fromMe) return;
if (!conn.luminAi[m.sender]) return;
if (m.text.match(global.prefix)) return;
if (m.text.startsWith("=") || m.text.startsWith(">") || m.text.startsWith("$")) return;
if (m.quoted && m.quoted.mtype === "interactiveMessage") return;
if (!m.text) return;
let media;
let teks
if (m.quoted && m.quoted.mtype === 'imageMessage') {
media = await m.quoted.download();
} else if (m.mtype === 'imageMessage') {
media = await m.download();
teks = "jelaskan gambar ini"
} else {
media = undefined
}
try {
const data = await fetchLumin(m.text || teks, media == undefined ? conn.luminAi[m.sender].id : generateRandomUserId(), `namamu adalah Makima, kamu adalah ai wanita feminim yang cantik dan cerdas, kamu dikembangkan oleh Wisnu, kamu feminim seperti wanita, kamu berpengetahuan luas, jawab menggunakan bahasa Indonesia, dan saat ini kamu sedang berbicara dengan ${conn.luminAi[m.sender].userName}.`, media);
await conn.reply(m.chat, data, m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: "Makima",
          body: "Created by Mephistod",
          thumbnailUrl: conn.luminAi[m.sender].pictM,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: false,
        },
      },
    });
} catch (error) {
console.error(error);
m.reply('An error occurred. Please try again later.');
}
};
handler.help = ["makima"].map((a) => a + " *[start/stop]*");
handler.tags = ["ai","cai"];
handler.command = ["makima"];
handler.private= true
module.exports = handler;