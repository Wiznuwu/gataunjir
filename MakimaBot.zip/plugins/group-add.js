let handler = async (m, { teks, conn, isOwner, isAdmin, args }) => {
let blockwwww = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
await conn.groupParticipantsUpdate(m.chat, [blockwwww], 'add')
m.reply("done")
}
handler.help = ["add"].map((a) => a + " *[reply/tag user]*");
handler.tags = ["group"];
handler.command = ["add"];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

handler.register = true;
module.exports = handler;