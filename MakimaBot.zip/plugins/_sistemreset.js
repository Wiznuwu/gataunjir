const cron = require("node-cron");
const fs = require("fs");
const path = require("path");
const archiver = require("archiver"); // Pastikan sudah diinstall
let handler = (m) => m;
let messageSent = false; // Flag untuk menghindari multiple execution

handler.before = async function (m) {
  cron.schedule(
    "00 00 * * *",
    () => {
      if (messageSent) return; // Jika sudah berjalan, hentikan
      messageSent = true;

      // Langkah 1: Backup
      const createBackup = () => {
        return new Promise((resolve, reject) => {
          const backupName = "MakimaBot.zip";
          const output = fs.createWriteStream(backupName);
          const archive = archiver("zip", { zlib: { level: 9 } });

          output.on("close", async () => {
            console.log("Backup berhasil dibuat.");
            try {
              const caption = `*[ BACKUP SCRIPT ]*\n> • *Nama file:* ${backupName}\n> • *Ukuran file:* ${archive.pointer()} bytes`;
              await conn.sendMessage(
                "6281244622905@s.whatsapp.net",
                {
                  document: {
                    url: backupName,
                  },
                  fileName: backupName,
                  caption: caption,
                  mimetype: "application/zip",
                }
              );
              console.log("Backup berhasil dikirim.");
              // Hapus file backup setelah dikirim
              fs.rmSync(backupName);
              console.log("File backup berhasil dihapus.");
              resolve();
            } catch (err) {
              console.error("Gagal mengirim backup:", err);
              reject(err);
            }
          });

          archive.on("warning", (err) => {
            if (err.code === "ENOENT") {
              console.warn("Warning:", err);
            } else {
              reject(err);
            }
          });

          archive.on("error", (err) => reject(err));

          archive.pipe(output);
          archive.glob("**/*", {
            cwd: path.resolve(__dirname, "../"),
            ignore: [
              "node_modules/**",
              "tmp/**",
              "**/flyaudio/**",
              "**.pm2/**",
              ".npm/**",
              "session/**",
              "video.mp4",
              backupName,
            ],
          });
          archive.finalize();
        });
      };

      // Langkah 2: Reset Limit dan Chat
      const resetLimitAndChat = () => {
        return new Promise((resolve) => {
          const users = Object.entries(db.data.users);
          users.forEach(([user, data]) => {
            data.limit = 100; // Reset limit menjadi 100
            data.chat = 0; // Reset chat menjadi 0
          });
          console.log("Limit dan total chat semua pengguna berhasil direset.");
          resolve();
        });
      };

      // Langkah 3: Hapus Session
      const clearSessions = () => {
        return new Promise((resolve, reject) => {
          const directory = "./session";

          fs.readdir(directory, (err, files) => {
            if (err) {
              console.error("Terjadi kesalahan saat membaca folder:", err);
              reject(err);
              return;
            }

            files.forEach((file) => {
              if (file !== "creds.json") {
                fs.unlink(path.join(directory, file), (err) => {
                  if (err) {
                    console.error("Gagal menghapus file:", err);
                  } else {
                    console.log(`File ${file} berhasil dihapus.`);
                  }
                });
              }
            });
            resolve();
          });
        });
      };

      // Langkah 4: Kirim Notifikasi
      const sendNotification = () => {
        return new Promise((resolve) => {
          const q = {
            key: {
              remoteJid: "status@broadcast",
              participant: "0@s.whatsapp.net",
              fromMe: false,
              id: "",
            },
            message: { conversation: "Berhasil Mereset Sistem!" },
          };

          conn.sendMessage(
            `120363236413068628@g.us`,
            {
              text: "*[Server Notif]*\n\nBot baru saja di-reset. Silakan tunggu beberapa detik sebelum menggunakan bot lagi.",
            },
            { quoted: q }
          )
            .then(() => {
              console.log("Notifikasi berhasil dikirim.");
              resolve();
            })
            .catch((err) => {
              console.error("Gagal mengirim notifikasi:", err);
              resolve(); // Lanjutkan meskipun gagal
            });
        });
      };

      // Jalankan Proses Asinkron
      (async () => {
        try {
          await createBackup(); // Langkah 1: Backup
          await resetLimitAndChat(); // Langkah 2: Reset Limit dan Chat
          await clearSessions(); // Langkah 3: Hapus Session
          await sendNotification(); // Langkah 4: Kirim Notifikasi
          console.log("Proses reset selesai.");
        } catch (err) {
          console.error("Terjadi kesalahan dalam proses:", err);
        } finally {
          process.send("reset");          
        }
      })();
    },
    {
      scheduled: true,
      timezone: "Asia/Jakarta",
    }
  );
};

module.exports = handler;