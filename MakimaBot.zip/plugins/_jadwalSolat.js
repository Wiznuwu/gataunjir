let cron = require("node-cron");
let handler = (m) => m;
const prayerTimes = {
  Subuh: "04:26",
  Dzuhur: "11:41",
  Ashar: "15:07",
  Maghrib: "17:54",
  Isya: "18:56",
};
let messageFlags = {
  Subuh: false,
  Dzuhur: false,
  Ashar: false,
  Maghrib: false,
  Isya: false,
};
const prayerVerses = [
  `وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ وَارْكَعُوا مَعَ الرَّاكِعِينَ
— "_Dan dirikanlah salat, tunaikanlah zakat, dan rukuklah beserta orang-orang yang rukuk._" (QS. Al-Baqarah: 43)`,

  `إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ
— "_Sesungguhnya salat itu mencegah dari perbuatan keji dan mungkar._" (QS. Al-‘Ankabut: 45)`,

  `فَوَيْلٌ لِلْمُصَلِّينَ * الَّذِينَ هُمْ عَنْ صَلَاتِهِمْ سَاهُونَ
— "_Maka celakalah orang-orang yang salat, (yaitu) yang lalai terhadap salatnya._" (QS. Al-Ma’un: 4–5)`,

  `الَّذِينَ يُقِيمُونَ الصَّلَاةَ وَيُؤْتُونَ الزَّكَاةَ وَهُمْ بِالْآخِرَةِ هُمْ يُوقِنُونَ
— "_Yaitu orang-orang yang mendirikan salat, menunaikan zakat, dan mereka yakin akan adanya akhirat._" (QS. An-Naml: 3)`,

  `وَأَقِمِ الصَّلَاةَ طَرَفَيِ النَّهَارِ وَزُلَفًا مِّنَ اللَّيْلِ ۚ إِنَّ الْحَسَنَاتِ يُذْهِبْنَ السَّيِّئَاتِ
— "_Dan dirikanlah salat pada kedua ujung siang dan pada bagian permulaan malam. Sesungguhnya perbuatan-perbuatan baik itu menghapuskan (dosa) perbuatan-perbuatan buruk._" (QS. Hud: 114)`,

  `يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ
— "_Hai orang-orang yang beriman, mintalah pertolongan (kepada Allah) dengan sabar dan salat. Sesungguhnya Allah bersama orang-orang yang sabar._" (QS. Al-Baqarah: 153)`,

  `مَا سَلَكَكُمْ فِي سَقَرَ * قَالُوا لَمْ نَكُ مِنَ الْمُصَلِّينَ
— "_Apakah yang memasukkan kamu ke dalam Saqar (neraka)? Mereka menjawab: Kami dahulu tidak termasuk orang-orang yang melaksanakan salat._" (QS. Al-Muddatstsir: 42–43)`,

  `وَأْمُرْ أَهْلَكَ بِالصَّلَاةِ وَاصْطَبِرْ عَلَيْهَا
— "_Dan perintahkanlah keluargamu untuk salat dan bersabarlah kamu dalam mengerjakannya._" (QS. Taha: 132)`,

  `فَصَلِّ لِرَبِّكَ وَانْحَرْ
— "_Maka dirikanlah salat karena Tuhanmu dan berkurbanlah._" (QS. Al-Kautsar: 2)`,

  `إِنَّ الْمُنَافِقِينَ يُخَادِعُونَ اللَّهَ وَهُوَ خَادِعُهُمْ ۖ وَإِذَا قَامُوا إِلَى الصَّلَاةِ قَامُوا كُسَالَىٰ
— "_Sesungguhnya orang-orang munafik itu menipu Allah, dan Allah akan membalas tipuan mereka. Apabila mereka berdiri untuk salat, mereka berdiri dengan malas._" (QS. An-Nisa: 142)`
];
async function sendPrayerReminder(conn, groups, solatName) {
 
    for (let id of groups) {
  try {
    // Tunggu pengiriman selesai sebelum melanjutkan
    await conn.sendMessage(id, {
                    text: `Saat ini telah memasuki waktu shalat *${solatName}*\nLepas gadget anda dan segera berwudhu!!.\n\n${prayerVerses[Math.floor(Math.random() * prayerVerses.length)]}`,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: global.namebot,
                            body: "Mephistod",
                            thumbnailUrl: 'https://files.catbox.moe/ry447r.jpg',
                            sourceUrl: "https://chat.whatsapp.com/H5gOlLTTYE1I2hNkHUuiSQ",
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: global.fkontak
                })   
    console.log(`Pengingat solat ${solatName} telah dikirim ke grup ${id}`);
    console.log(messageFlags)
  } catch (error) {
    console.log(`Gagal mengirim pesan untuk solat ${solatName} ke grup ${id}:`, error);
  }
 }
}

handler.before = async function (m, { conn, participants }) {
  let groups = Object.entries(conn.chats)
    .filter(
      ([jid, chat]) =>
        jid.endsWith("@g.us") &&
        chat.isChats &&
        !chat.metadata?.read_only &&
        !chat.metadata?.announce,
    )
    .map((v) => v[0]);
  Object.entries(prayerTimes).forEach(([solatName, time]) => {
    const [hour, minute] = time.split(":");
    cron.schedule(`${minute} ${hour} * * *`, async () => {
      if (!messageFlags[solatName]) {
      messageFlags[solatName] = true; 
      await sendPrayerReminder(conn, groups, solatName);
     }
    }, {
      scheduled: true,
      timezone: "Asia/Jakarta",
    });
  });
};

module.exports = handler;