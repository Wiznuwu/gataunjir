let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `example: ${usedPrefix}${command} elf woman`
m.reply(wait)
try {
	let url = `https://api.betabotz.eu.org/api/maker/text2img?text=${text}&apikey=${global.apibeta}`
	conn.sendFile(m.chat, url, null, 'nihh', m)
	} catch {
	m.reply("terjadi error")
    }	
}
handler.help = ['txt2img *[query]*']
handler.tags = ['ai']
handler.command = /^(txt2img)$/i
handler.premium = false
module.exports = handler