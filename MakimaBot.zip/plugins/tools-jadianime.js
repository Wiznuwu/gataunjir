let handler = async (m, { conn, usedPrefix, command, text }) => {
  switch (command) {
        case "toanime":
        case "jadianime": {
        let who =
    m.mentionedJid && m.mentionedJid[0]
      ? m.mentionedJid[0]
      : m.fromMe
        ? conn.user.jid
        : m.sender;
  let name = await conn.getName(who);
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw `*• Example :* ${usedPrefix + command} *[reply/send media]*`;
  m.reply(wait);
  let media = await q.download();
  let url = await Uploader.catbox(media)
  let hasil = await Func.fetchJson(`https://api.betabotz.eu.org/api/maker/jadianime?url=${url}&apikey=669e984e849b45dc4edc`)
  await conn.sendFile(m.chat, hasil.result.img_crop_single, "", done, m);
}
break
  case "tozombie":
  case "jadizombie": {
  let who =
    m.mentionedJid && m.mentionedJid[0]
      ? m.mentionedJid[0]
      : m.fromMe
        ? conn.user.jid
        : m.sender;
  let name = await conn.getName(who);
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw `*• Example :* ${usedPrefix + command} *[reply/send media]*`;
  m.reply(wait);
  let media = await q.download();
  let url = await Uploader.catbox(media)
  let hasil = await Func.fetchJson(`https://api.betabotz.eu.org/api/maker/jadizombie?url=${url}&apikey=669e984e849b45dc4edc`)
  await conn.sendFile(m.chat, hasil.result, "", done, m);
  }
  break
 }
};
handler.help = ["toanime", "jadianime","tozombie","jadizombie"].map((a) => a + " *[reply/send media]*");
handler.tags = ["tools"];
handler.command = ["toanime", "jadianime","tozombie","jadizombie"];
handler.limit = true;

handler.register = true;
module.exports = handler;