let handler = (m) => m;

handler.before = async function (m) {
  const fs = require("fs");
  const path = require("path");

  const directory = "./session";

  // Membaca isi folder "session"
  fs.readdir(directory, (err, files) => {
    if (err) {
      console.log("Terjadi kesalahan:", err);
      return;
    }

    // Memfilter file yang bukan "creds.json"
    const filteredFiles = files.filter((file) => file !== "creds.json");

    // Jika file kurang dari 300, hentikan proses
    if (filteredFiles.length < 300) return;

    // Hapus semua file kecuali "creds.json"
    filteredFiles.forEach((file) => {
      const filePath = path.join(directory, file);
      fs.unlink(filePath, (err) => {
        if (err) {
          console.log("Gagal menghapus file:", err);
          return;
        }
      });
    });

    // Kirim notifikasi jika penghapusan berhasil
    conn.sendMessage(
      "6281244622905@s.whatsapp.net",
      { text: `Success Delete File Trash Total: *[ ${filteredFiles.length} ]*` },
      { quoted: global.fkontak }
    );
  });
};

module.exports = handler;