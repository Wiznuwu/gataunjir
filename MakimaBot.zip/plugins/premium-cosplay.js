const axios = require('axios');
const archiver = require('archiver');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const url = require('url');

let handler = async (m, { conn, text, usedPrefix, command }) => {
conn.cosplay = conn.cosplay ? conn.cosplay : {};
let newText = text.replace(/\s/g, "+");
if (!text) {
return m.reply(`Masukkan pencarian nya\n*Contoh:* ${usedPrefix + command} Hu tao`)
}
const result = await fetchAndParseHtml(`https://cosplaytele.com/?s=${newText}`);
let cosplayResults = result.cosplay;
for (const pageLink of result.page) {
const pageResult = await fetchAndParseHtml(pageLink.linkpage);
cosplayResults = [...cosplayResults, ...pageResult.cosplay];
}
cosplayResults = [...new Set(cosplayResults.map(v => v.link))].map(link => {
return cosplayResults.find(v => v.link === link);
});
let hasil = cosplayResults.map(
(v, index) =>
`*${index + 1}.* *Title:* ${v.title}`,
)
.join("\n\n");
     let { key } = await conn.reply(m.chat, hasil, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "cosplaytele.com",
body: "Created by Mephistod",
thumbnailUrl: "https://files.catbox.moe/2vimxq.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true,
},
},
}); 
    await conn.reply(
      m.chat,
      `Ketik angka *1 - ${cosplayResults.length}* sesuai dengan pesan di atas`,
      null,
    );
    conn.cosplay[m.sender] = cosplayResults; 
    }
handler.before = async (m, { conn }) => {
    conn.cosplay = conn.cosplay ? conn.cosplay : {};
    if (m.isBaileys) return;
    if (!m.text) return;
    if (!conn.cosplay[m.sender]) return;
    if (
      isNaN(m.text) ||
      m.text <= 0 ||
      m.text > conn.cosplay[m.sender].length
    )
      return;      
      m.reply(wait);
    let pilihan = conn.cosplay[m.sender][m.text - 1].link;
    let judul = conn.cosplay[m.sender][m.text - 1].title;
    let title = judul.replace(/\s/g, "-");
    delete conn.cosplay[m.sender]
main(m, pilihan, m.chat, title).catch((err) => {
console.error(err);
})
}
handler.help = ["zipcosplay *[query]*"];
handler.command = ["zipcosplay", "zpcsply"];
handler.tags = ["premium", "downloader"];
handler.premium = true
module.exports = handler;          
            
async function fetchAndParseHtml(url) {
const response = await fetch(url);
const html = await response.text();
const $ = cheerio.load(html);
const postListElement = $('#post-list');
const postListHtml = postListElement.html();
const postLinks = [];
$(postListHtml).find('a').each((index, element) => {
const href = $(element).attr('href');
const title = $(element).text().trim();
if (title !== '') {
postLinks.push({ link: href, title });
}
});
const cosplayLinks = [];
const pageLinks = [];
postLinks.forEach((link) => {
if (link.link.includes('page')) {
const pageNumber = link.title.match(/\d+/)[0];
pageLinks.push({
linkpage: link.link,
page: parseInt(pageNumber)
});
} else {
cosplayLinks.push({
title: link.title,
link: link.link
});
}
});
const result = {
cosplay: cosplayLinks,
page: pageLinks
};
return result;
}

async function getVideoLinks(link) {
try {
const responseJson = await fetch(link);
const html = await responseJson.text();
const $ = cheerio.load(html);
const linkVideo = $('a')
.map((index, element) => {
const href = $(element).attr('href');
const absoluteUrl = new url.URL(href, link).href;
return absoluteUrl;
})
.get()
.filter((link) => link.includes('wp-content') && link.endsWith('.webp'));
return linkVideo;
} catch (error) {
console.error(error);
}
}

async function main(m, link, sender, judul) {
const webpLinks = await getVideoLinks(link);
const zip = archiver('zip', {
zlib: { level: 9 } // Sets the compression level
});
const zipFile = fs.createWriteStream('output.zip');
zip.pipe(zipFile);
zipFile.on('close', () => {
console.log('Zip file created successfully');
console.log(`Zip file size: ${fs.statSync('output.zip').size} bytes`);
});
for (const link of webpLinks) {
const filename = path.basename(link);
try {
const response = await axios.get(link, { responseType: 'arraybuffer' });
console.log(`Downloaded ${filename} successfully`);
console.log(`Response data length: ${response.data.length}`);
zip.append(response.data, { name: filename });
console.log(`Added ${filename} to zip file`);
} catch (error) {
console.error(`Error downloading ${filename}: ${error.message}`);
}
}
zip.finalize();
setTimeout(function() {
const zipcos = fs.readFileSync('output.zip'); 
conn.sendMessage(sender, { document: zipcos, mimetype: "application/zip", fileName: `${judul}.zip`, caption: done }, { quoted: m });
fs.unlinkSync('output.zip');
}, 10000);
}