const axios = require('axios');

async function fetchLumin(content, user, prompt, image) {
    try {
        const payload = {
            content: content,
            user: user,
            prompt: prompt,
            imageBuffer: image,            
        };
        const response = await axios.post('https://luminai.my.id/', payload);
        return response.data.result;
    } catch (error) {
        throw error;
    }
}

function generateRandomUserId() {
    return 'user-' + Math.floor(Math.random() * 10000);
}

let picture = [
    "https://files.catbox.moe/efswka.jpg", 
    "https://files.catbox.moe/micnho.jpg", 
    "https://files.catbox.moe/1zh821.jpg"
];

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Example: ${usedPrefix}${command} on/off`);
    
    const [commandName, ...args] = text.split(/\s+/);
    
    if (commandName.toLowerCase() === "on") {
        conn.luminAiGrub = conn.luminAiGrub || {};
        let userId = generateRandomUserId();
        conn.luminAiGrub[m.chat] = {  // Changed from m.sender to m.chat
            id: userId,
            pictM: picture[Math.floor(Math.random() * picture.length)]
        };
        m.reply(`Hai!, Makima ai siap di gunakan`);
    } else if (commandName.toLowerCase() === "off") {
        if (conn.luminAiGrub[m.chat]) {  // Changed from m.sender to m.chat
            clearTimeout(conn.luminAiGrub[m.chat].timeoutId);
            delete conn.luminAiGrub[m.chat];  // Changed from m.sender to m.chat
            m.reply("Sesi chat dengan LuminAI telah dihentikan.");
        } else {
            m.reply("Tidak ada sesi chat LuminAI yang aktif saat ini.");
        }
    } else {
        m.reply(`Example: ${usedPrefix}${command} on/off`);
    }
};

handler.before = async (m, { conn, usedPrefix }) => {
    conn.luminAiGrub = conn.luminAiGrub || {};
    if (!m.isGroup) return;
    if (m.isGroup && !m.quoted) return;
    if (m.quoted && !m.quoted.fromMe) return;
    if (!conn.luminAiGrub[m.chat]) return;  // Changed from m.sender to m.chat
    if (m.text.match(global.prefix)) return;
    if (m.text.startsWith("=") || m.text.startsWith(">") || m.text.startsWith("$")) return;
    if (m.quoted && m.quoted.mtype === "interactiveMessage") return;
    if (!m.text) return;

    let media;
    let teks;
    
    if (m.quoted.fromMe && m.mtype === 'imageMessage') {
        media = await m.download();
        teks = "jelaskan gambar ini";
    } else {
        media = undefined;
    }

    try {
        const data = await fetchLumin(m.text || teks, media == undefined ? conn.luminAiGrub[m.chat].id : generateRandomUserId(), `namamu adalah Makima, kamu adalah ai wanita feminim yang cantik dan cerdas, kamu dikembangkan oleh Wisnu, kamu feminim seperti wanita, kamu berpengetahuan luas, jawab menggunakan bahasa Indonesia, dan saat ini kamu sedang di dalam grub yang berisi beberapa orang yang ingin menanyaimu, kamu sedang berbicara dengan ${conn.getName(m.sender)}.`, media);  // Changed from m.sender to m.chat
        await conn.reply(m.chat, data, m, {
            contextInfo: {
                mentionedJid: [],
                groupMentions: [],
                externalAdReply: {
                    title: "Makima",
                    body: "Created by Mephistod",
                    thumbnailUrl: conn.luminAiGrub[m.chat].pictM,  // Changed from m.sender to m.chat
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: false,
                },
            },
        });
    } catch (error) {
        console.error(error);
        m.reply('An error occurred. Please try again later.');
    }
};

handler.help = ["autoai"].map((a) => a + " *[on/off]*");
handler.tags = ["ai", "cai"];
handler.command = ["autoai"];
handler.admin = true;
handler.group = true;
module.exports = handler;