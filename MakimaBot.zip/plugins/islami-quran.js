const fs = require('fs');
const didyoumean2 = require("didyoumean2").default;

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
if (!text) throw "Usage: .quran Al Fatihah"
const kataKapital = text.split(' ').map(kata => kata.charAt(0).toUpperCase() + kata.slice(1)).join(' ');
const surah = JSON.parse(fs.readFileSync(`lib/quran.json`))
const namaSurah = surah.map(s => s.nama);
        if (!namaSurah.includes(kataKapital)) {
            let maksud = await didyoumean2(kataKapital, namaSurah);
            let apala = maksud === null ? "Surah yang kamu cari tidak ada" : `apakah Surah yang kamu maksud adalah *${maksud}*?`;
            m.reply(apala);
        } else {
let data = await getSurah(JSON.parse(fs.readFileSync(`lib/quran.json`)), kataKapital)
let { namaSurah, ayatData, audioLink } = data
let { key } = await conn.sendMessage(m.chat, { text: ayatData }, { quoted: m })
conn.sendMessage(m.chat, { audio: { url: audioLink }, mimetype: "audio/mp4",
      fileName: "" }, { quoted: key })
 }
}
handler.help = ["quran *[surah]*"];
handler.tags = ["islami"];
handler.command = ["quran"];
module.exports = handler;


function getSurah(jsonData, surahName) {
const surah = jsonData.find((surah) => surah.nama === surahName);
if (surah) {
const namaSurah = surah.nama;
const ayatData = surah.ayat.map((ayat) => {
return `${ayat.ar}\n${ayat.id}`;
});
const audioLink = surah.audio;
return {
namaSurah,
ayatData: ayatData.join("\n\n"),
audioLink,
};
} else {
return null;
}
}