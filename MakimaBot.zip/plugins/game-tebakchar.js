let fetch = require("node-fetch");
let timeout = 120000;
let poin = 4999;
let handler = async (m, { conn, command, usedPrefix }) => {
  conn.tebakchara = conn.tebakchara ? conn.tebakchara : {};
  let id = m.chat;
  if (id in conn.tebakchara) {
    conn.reply(
      m.chat,
      "Masih ada yang belum terjawab di chat ini",
      conn.tebakchara[id][0],
    );
    throw false;
  }
  let res = await Func.fetchJson(`https://api.betabotz.eu.org/api/game/tebakchara?apikey=${apibeta}`);
  let Char = await res[Math.floor(Math.random() * res.length)];
  console.log(Char.result)
  let json = { hasil: Char };
  let caption = `*${command.toUpperCase()}*
Siapa apakah dia?

Timeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${usedPrefix}hime untuk hint
Bonus: ${poin} XP
    `.trim();
  conn.tebakchara[id] = [
    await conn.sendFile(m.chat, Char.result.image, "", caption, m),
    json,
    poin,
    setTimeout(() => {
      if (conn.tebakchara[id])
        conn.reply(
          m.chat,
          `Waktu habis!\nJawabannya adalah *${Char.result.name}*`,
          conn.tebakchara[id][0],
        );
      delete conn.tebakchara[id];
    }, timeout),
  ];
};
handler.help = ["tebakchar"];
handler.tags = ["game"];
handler.command = ["tebakchar"]

module.exports = handler;

const buttons = [
  ["Hint", "/hlog"],
  ["Nyerah", "menyerah"],
];