let handler = (m) => m;

let linkRegex = /(?:chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})|whatsapp\.com\/channel\/([0-9A-Za-z]{20,30}))/i; // regex untuk kedua jenis link
handler.before = async function (m, { user, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;
  let chat = db.data.chats[m.chat];
  let isGroupLink = linkRegex.exec(m.text); // memeriksa kedua jenis link
  if (isAdmin) return;
  if (!isBotAdmin) return;
  let linkGC =
      "https://chat.whatsapp.com/" + (await conn.groupInviteCode(m.chat));
    let isLinkconnGc = new RegExp(linkGC, "i");
    let isgclink = isLinkconnGc.test(m.text);
    if (isgclink) return;
  if (chat.antiLink && isGroupLink) {
   if (!global.db.data.chats[m.chat].users) {
  global.db.data.chats[m.chat].users = {}; 
     }
   if (! global.db.data.chats[m.chat].users[m.sender]) {
      global.db.data.chats[m.chat].users[m.sender] = { warning: 0 }; 
   }
   global.db.data.chats[m.chat].users[m.sender].warning += 1;
    if (global.db.data.chats[m.chat].users[m.sender].warning >= 3) {
      await conn.sendMessage(
        m.chat,
        {
          text: `*[ System Notice ]*\n\nUser @${m.sender.split("@")[0]} telah mendapatkan 3 peringatan dan akan dikeluarkan dari grup.`,
          mentions: [m.sender],
        },
        { quoted: global.fkontak }
      );

      setTimeout(async () => {
        await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove").catch((e) =>
          console.error(e)
        );
      }, 3000);
      global.db.data.chats[m.chat].users[m.sender].warning = 0
    } else {
    await conn.sendMessage(
        m.chat,
        {
          text: `*[ System Detected ]*\n\nUser @${m.sender.split("@")[0]}, Kamu telah di beri 1 peringatan karena terdeteksi mengirim link grub/channel lain\nJika Kamu mendapat 3 peringatan, Kamu akan langsung dikeluarkan dari grup ini!\n\nSaat ini kamu telah memiliki *${global.db.data.chats[m.chat].users[m.sender].warning}* peringatan`,
          mentions: [m.sender],
        },
        { quoted: global.fkontak }
      );
    await conn.sendMessage(m.chat, { delete: m.key });
    await this.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.key.id,
        participant: m.key.participant,
      },
    });
  }
 }
  return true;
};

module.exports = handler;