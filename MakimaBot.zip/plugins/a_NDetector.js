let handler = (m) => m;

handler.before = async (m, { conn, usedPrefix, isBotAdmin, isAdmin, command }) => {
  let isFoto = m.mtype;
  let mime = (m.msg || m).mimetype || "";

  // Abaikan jika bukan pesan gambar
  if (isFoto !== "imageMessage") return;
  if (/webp/.test(mime)) return; // Abaikan stiker
  if (!db.data.chats[m.chat]?.isNDetector) return; // Abaikan jika fitur NSFW Detector tidak diaktifkan
  if (m.text?.match(global.prefix)) return; // Abaikan jika pesan berupa perintah
  if (!/image/.test(mime)) return; // Abaikan jika bukan gambar
  if (!isBotAdmin) return; // Abaikan jika bot bukan admin
  if (isAdmin) return;
  if (!m.isGroup) return;

  try {
    // Unduh media dan deteksi NSFW
    let media = await m.download();
    let link = await Uploader.catbox(media).catch(async (_) => await Uploader.telegraPh(media));
    let data = await Func.fetchJson(`https://api.betabotz.eu.org/api/tools/nsfw-detect?url=${link}&apikey=${global.apibeta}`);
    console.log(data);

    if (data.result.labelName.includes("Porn")) {
      const sender = m.sender;
      if (!global.db.data.chats[m.chat].users) {
  global.db.data.chats[m.chat].users = {}; 
     }
   if (! global.db.data.chats[m.chat].users[sender]) {
      global.db.data.chats[m.chat].users[sender] = { warning: 0 }; 
   }
   global.db.data.chats[m.chat].users[sender].warning += 1;

      if (global.db.data.chats[m.chat].users[sender].warning >= 3) {
        await conn.sendMessage(
        m.chat,
        {
          text: `*[ System Notice ]*\n\nUser @${sender.split("@")[0]} telah mendapatkan 3 peringatan dan akan dikeluarkan dari grup.`,
          mentions: [sender],
        },
        { quoted: global.fkontak }
      );

        // Beri delay 3 detik sebelum mengeluarkan pengguna
        setTimeout(async () => {
          await conn.groupParticipantsUpdate(m.chat, [sender], "remove");
        }, 1000);
        global.db.data.chats[m.chat].users[sender].warning = 0
      } else {
        // Jika peringatan belum mencapai 3
        m.reply(
          `*[ NSFW DETECTED ]*\nKamu telah diberi 1 peringatan karena mengirim gambar tidak senonoh!\nJika Kamu mendapat 3 peringatan, Kamu akan langsung dikeluarkan dari grup ini.\n\nSaat ini kamu telah memiliki *${global.db.data.chats[m.chat].users[sender].warning}* peringatan`
        );
      }

      // Hapus pesan dari grup
      return conn.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.key.participant,
        },
      });
    }
  } catch (error) {
    console.error(error);
  }
};

module.exports = handler;




//pembatas
let handler = (m) => m;

async function before(m, { isAdmin, isBotAdmin }) {
  if (!m.message) return; // Abaikan jika pesan tidak valid
  if (!isBotAdmin) return; // Abaikan jika bot bukan admin
  if (isAdmin) return;
  if (!m.isGroup) return;

  this.spam ??= {}; // Inisialisasi objek spam jika belum ada

  const sender = m.sender; // Simpan pengirim
  const timestamp = m.messageTimestamp?.toNumber?.(); // Dapatkan timestamp sebagai angka

  if (!timestamp) return; // Abaikan jika timestamp tidak valid

  if (sender in this.spam) {
    const userSpam = this.spam[sender];
    userSpam.count++; // Tambahkan jumlah spam

    // Jika waktu sejak spam terakhir lebih dari 3 detik
    if (timestamp - userSpam.lastspam > 3) {
      if (userSpam.count > 3) {
      if (!global.db.data.chats[m.chat].users) {
  global.db.data.chats[m.chat].users = {}; 
     }
   if (! global.db.data.chats[m.chat].users[sender]) {
      global.db.data.chats[m.chat].users[sender] = { warning: 0 }; 
   }
   global.db.data.chats[m.chat].users[sender].warning += 1;
      if (global.db.data.chats[m.chat].users[sender].warning >= 3) {
        await conn.sendMessage(
        m.chat,
        {
          text: `*[ System Notice ]*\n\nUser @${sender.split("@")[0]} telah mendapatkan 3 peringatan dan akan dikeluarkan dari grup.`,
          mentions: [sender],
        },
        { quoted: global.fkontak }
      );
        global.db.data.chats[m.chat].users[sender].warning = 0
        // Beri delay 3 detik sebelum mengeluarkan pengguna
        setTimeout(async () => {
          await conn.groupParticipantsUpdate(m.chat, [sender], "remove");
        }, 1000);
      } else        
        m.reply(
          `*[ Spam Detect ]*\nKamu telah diberi 1 peringatan karena melakukan spam!\nJika Kamu mendapat 3 peringatan, Kamu akan langsung dikeluarkan dari grup ini!\n\nSaat ini kamu telah memiliki *${global.db.data.chats[m.chat].users[sender].warning}* peringatan`
        );
      }
      userSpam.count = 0; // Reset jumlah spam
      userSpam.lastspam = timestamp; // Perbarui waktu spam terakhir
    }
  } else {
    // Inisialisasi data spam untuk pengirim baru
    this.spam[sender] = {
      jid: sender,
      count: 1,
      lastspam: timestamp,
    };
  }
}

module.exports = {
  before,
}