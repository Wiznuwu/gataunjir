let handler = async (m, { conn, text }) => {
  if (!text) throw "Masukkan user yang ingin di unban\n\nExample: .unban 6289677216812";
  let who = m.quoted?.sender || m.mentionedJid?.[0];
  const keyword = text.split(" ")[0];
  let alasan = text.slice(keyword.length + 1) || "pesan owner: jangan bandel lagi";
  if (!who) throw "Tag salah satu lah";
  let users = global.db.data.users;
  users[who].banned = false;
  conn.reply(m.chat, `Berhasil unbanned User @${who.split("@")[0]}`, m);
  conn.sendMessage(who, { text: `selamat!, kamu tidak di banned lagi\n${alasan}` })
};
handler.help = ["unban `[@user]`"];
handler.tags = ["owner"];
handler.command = /^unban$/i;
handler.mods = true;
handler.owner = true;
module.exports = handler;