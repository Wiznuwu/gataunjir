let handler = async (m, { conn, text }) => {
try {
  if (!text) throw "Masukkan user yang ingin di ban\n\nExample: .ban 6289677216812";
  let who = m.quoted?.sender || m.mentionedJid?.[0];
  const keyword = text.split(" ")[0];
  let alasan = text.slice(keyword.length + 1) || "owner gabut";
  if (!who) throw "Tag salah satu lah";
  let users = global.db.data.users;
  users[who].banned = true;
  m.reply(`Berhasil Membanned User @${who.split("@")[0]}`)
  conn.sendMessage(who, { text: `kamu telah di banned karena\n${alasan}` })
} catch {
m.reply("_Pengguna Belum Terdaftar Di Database_")
 }
}
handler.help = ["ban `[@user]`"];
handler.tags = ["owner"];
handler.command = /^ban$/i;
handler.mods = true;
handler.owner = true;
module.exports = handler;