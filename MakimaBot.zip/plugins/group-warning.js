let handler = async (m, { conn, isOwner, isAdmin, args }) => {
  let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";

  if (m.quoted) {
    if (m.quoted.sender === ownerGroup || m.quoted.sender === conn.user.jid)
      return; // Abaikan jika pesan dari pemilik grup atau bot itu sendiri
   let usr = m.quoted.sender;
   if (!global.db.data.chats[m.chat].users) {
  global.db.data.chats[m.chat].users = {}; 
     }
   if (! global.db.data.chats[m.chat].users[usr]) {
      global.db.data.chats[m.chat].users[usr] = { warning: 0 }; 
   }
   global.db.data.chats[m.chat].users[usr].warning += 1;
    if (global.db.data.chats[m.chat].users[usr].warning >= 3) {
      await conn.sendMessage(
        m.chat,
        {
          text: `*[ System Notice ]*\n\nUser @${usr.split("@")[0]} telah mendapatkan 3 peringatan dan akan dikeluarkan dari grup.`,
          mentions: [usr],
        },
        { quoted: global.fkontak }
      );

      setTimeout(async () => {
        await conn.groupParticipantsUpdate(m.chat, [usr], "remove").catch((e) =>
          console.error(e)
        );
      }, 3000);
      global.db.data.chats[m.chat].users[usr].warning = 0
    } else {
    await conn.sendMessage(
      m.chat,
      {
       text: `*[ Warning ]*\n\nHai user @${usr.split("@")[0]}, Kamu telah diberi 1 peringatan oleh admin. Jika kamu mendapat 3 peringatan, kamu akan dikeluarkan dari grup.\n\nSaat ini kamu telah memiliki *${global.db.data.chats[m.chat].users[usr].warning}* peringatan`,
        mentions: [usr],
      },
      { quoted: global.fkontak }
    );
  }
    return;
  }
  if (!m.mentionedJid[0]) throw `*• Example :* .warn *[reply/tag user]*`;
  let users = m.mentionedJid.filter(
    (u) => !(u === ownerGroup || u.includes(conn.user.jid))
  );

  for (let user of users) {
    if (user.endsWith("@s.whatsapp.net")) {      
    
      if (!global.db.data.chats[m.chat].users) {
  global.db.data.chats[m.chat].users = {}; 
     }
   if (! global.db.data.chats[m.chat].users[user]) {
      global.db.data.chats[m.chat].users[user] = { warning: 0 }; 
   }
   global.db.data.chats[m.chat].users[user].warning += 1;
   
      if (global.db.data.chats[m.chat].users[user].warning >= 3) {
        await conn.sendMessage(
        m.chat,
        {
          text: `*[ System Notice ]*\n\nUser @${user.split("@")[0]} telah mendapatkan 3 peringatan dan akan dikeluarkan dari grup.`,
          mentions: [user],
        },
        { quoted: global.fkontak }
      );

        // Beri delay 3 detik sebelum mengeluarkan pengguna
        setTimeout(async () => {
          await conn.groupParticipantsUpdate(m.chat, [user], "remove").catch((e) =>
            console.error(e)
          );
        }, 3000);
        global.db.data.chats[m.chat].users[user].warning = 0
      } else {

      await conn.sendMessage(
        m.chat,
        {
          text: `*[ Warning ]*\n\nHai user @${user.split("@")[0]}, Kamu telah diberi 1 peringatan oleh admin. Jika kamu mendapat 3 peringatan, kamu akan dikeluarkan dari grup.\n\nSaat ini kamu telah memiliki *${global.db.data.chats[m.chat].users[user].warning}* peringatan`,
          mentions: [user],
        },
        { quoted: global.fkontak}
      );
     }
    }
  }
};

handler.help = ["warn", "warning"].map((a) => a + " *[reply/tag user]*");
handler.tags = ["group"];
handler.command = ["warn", "warning"];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

handler.register = true;
module.exports = handler;