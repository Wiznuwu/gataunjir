let fs = require("fs");

let handler = async (m, { conn, text, command }) => {
  let directory = "./database/list.json";
  if (!fs.existsSync(directory)) fs.writeFileSync(directory, JSON.stringify({})); // Buat file jika belum ada

  let jsonData = fs.readFileSync(directory);
  let existingData = JSON.parse(jsonData);
  let user = m.sender; // User ID pengirim pesan

  switch (command) {
    case "addlist": {
      // Cek apakah ada media atau teks yang direply
      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || "";
      let mtype = q.mtype;

      // Validasi input
      if (!mime && mtype !== "extendedTextMessage") return m.reply("*• Hanya mendukung sticker, image, atau text.*");
      if (!text) return m.reply("*• Example :* .addlist kuda [reply media/text]");

      // Buat entri baru jika belum ada untuk user
      if (!existingData[user]) existingData[user] = {};

      // Cek apakah teks sudah ada untuk user tersebut
      if (existingData[user][text]) {
        return m.reply(`*• '${text}' sudah ada dalam database Anda.*`);
      }

      let mediaData = null;
      if (mime) {
        // Download media
        let media = await q.download();
        let link = await Uploader.catbox(media);
        mediaData = {
          url: link,
          stiker: mtype === "stickerMessage",
        };
      } else if (mtype === "extendedTextMessage") {
        mediaData = q.text || ""; // Simpan teks yang direply
      }

      // Tambahkan entri untuk user
      existingData[user][text] = mediaData || "null";
      fs.writeFileSync(directory, JSON.stringify(existingData, null, 2));

      m.reply(`*• Berhasil menambahkan '${text}' ke database Anda.*`);
      break;
    }

    case "dellist": {
      if (!text) return m.reply("*• Example :* .dellist kuda");
      if (!existingData[user] || !existingData[user][text]) {
        return m.reply(`*• '${text}' tidak ditemukan dalam database Anda.*`);
      }

      // Hapus entri
      delete existingData[user][text];

      // Hapus user dari database jika sudah tidak ada entri
      if (Object.keys(existingData[user]).length === 0) {
        delete existingData[user];
      }

      fs.writeFileSync(directory, JSON.stringify(existingData, null, 2));
      m.reply(`*• Berhasil menghapus '${text}' dari database Anda.*`);
      break;
    }

    default:
      return m.reply("*• Command tidak dikenal.*");
  }
};

handler.help = ["addlist *[reply media/text]*", "dellist *[query]*"];
handler.tags = ["tools"];
handler.command = ["addlist", "dellist"];
handler.premium = true;

module.exports = handler;