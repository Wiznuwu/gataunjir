let fs = require("fs");
let uploadImage = require('../lib/uploadImage.js');

let handler = async (m,{ conn, text }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) return m.reply('Tidak ada media');
if (!text) throw "Input Nama File json"
  let directory = `./genshin/material/${text}.json`
  let media = await q.download();
  let link = await uploadImage(media);
  let array = []
 let hasil = array.push({ url: link });
  fs.writeFileSync(directory, JSON.stringify(array));

  m.reply(`Sukses Menambahkan Media Ke Dalam *[ ${directory} ]*`);
};

handler.help = ['addmaterial *`[Nama Karakter]`*'];
handler.tags = ['owner'];
handler.command = ["addmaterial"];

handler.owner = true

module.exports = handler;