let handler = async (m, { conn, command, isOwner, isAdmin, args }) => {
  // Pastikan chat ID ada di database
  let chat = global.db.data.chats[m.chat];
  if (!chat) global.db.data.chats[m.chat] = {};
  chat = global.db.data.chats[m.chat];

  // Pastikan listhitam ada, dengan default false
  if (typeof chat.listhitam === "undefined") chat.listhitam = false;

  // Cek apakah ada argumen on/off
  if (!args[0] || !["on", "off"].includes(args[0].toLowerCase())) {
    // Jika tidak ada argumen yang valid, kirim cara penggunaan
    return conn.sendMessage(
      m.chat,
      {
        text: `*[ Blacklist User Usage ]*\n\nGunakan perintah ini untuk mengaktifkan atau menonaktifkan fitur blacklist user di grup.\n\nCara penggunaan:\n- *${command} on*: Mengaktifkan blacklist user.\n- *${command} off*: Menonaktifkan blacklist user.\n\nFungsi:\nKetika fitur ini aktif, pengguna yang keluar grup akan dimasukkan ke dalam daftar hitam, dan jika mereka mencoba bergabung kembali, mereka akan otomatis dikeluarkan.`,
      },
      { quoted: m }
    );
  }

  // Aktifkan atau matikan listhitam berdasarkan input
  const state = args[0].toLowerCase() === "on";
  chat.listhitam = state;

  // Kirim pesan konfirmasi
  return conn.sendMessage(
    m.chat,
    {
      text: `*[ Blacklist User Update ]*\n\nFitur blacklist user berhasil ${
        state ? "diaktifkan" : "dinonaktifkan"
      } untuk grup ini.`,
    },
    { quoted: m }
  );
};

handler.help = ["blacklistuser"].map((a) => a + " *[on/off]*");
handler.tags = ["group"];
handler.command = ["blacklistuser"];
handler.botAdmin = true;
handler.admin = true;
handler.group = true
handler.register = true;

module.exports = handler;