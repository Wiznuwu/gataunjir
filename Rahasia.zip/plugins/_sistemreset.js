const cron = require("node-cron");
const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const axios = require("axios");
require("dotenv").config();

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const OWNER = process.env.OWNER;
const REPO = process.env.REPO;
const BRANCH = process.env.BRANCH;

let handler = (m) => m;
let messageSent = false; // Flag untuk menghindari multiple execution

handler.before = async function (m) {
  cron.schedule(
    "25 14 * * *",
    () => {
      if (messageSent) return;
      messageSent = true;

      const backupName = "LucyBot.zip";
      const backupFilePath = path.resolve(backupName);

      // **Langkah 1: Backup**
      const createBackup = () => {
        return new Promise((resolve, reject) => {
          const output = fs.createWriteStream(backupFilePath);
          const archive = archiver("zip", { zlib: { level: 9 } });

          output.on("close", () => {
            console.log(`Backup ${backupName} berhasil dibuat (${archive.pointer()} bytes).`);
            resolve();
          });

          archive.on("error", (err) => reject(err));
          archive.pipe(output);

          archive.glob("**/*", {
            cwd: path.resolve(__dirname, "../"),
            ignore: [
              "node_modules/**",
              "tmp/**",
              "**/flyaudio/**",
              "**.pm2/**",
              ".npm/**",
              "session/**",
              backupName,
            ],
          });
          archive.finalize();
        });
      };

      // **Upload Backup ke GitHub**
      const uploadToGitHub = async () => {
        const content = fs.readFileSync(backupFilePath);
        const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/Rahasia.zip`;

        let sha;
        try {
          const { data } = await axios.get(url, {
            headers: { Authorization: `Bearer ${GITHUB_TOKEN}` },
          });
          sha = data.sha;
        } catch (err) {
          if (err.response?.status !== 404) throw err;
        }

        await axios.put(
          url,
          {
            message: sha ? `Update Rahasia.zip` : `Add Rahasia.zip`,
            content: Buffer.from(content).toString("base64"),
            branch: BRANCH,
            sha,
          },
          {
            headers: { Authorization: `Bearer ${GITHUB_TOKEN}` },
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
          }
        );

        console.log("Backup berhasil diunggah ke GitHub.");
      };

      // **Langkah 2: Reset Limit dan Chat**
      const resetLimitAndChat = async () => {
        const users = Object.entries(db.data.users);
        for (const [user, data] of users) {
          if (typeof data.limit !== "number") data.limit = 25; // Pastikan limit valid
          if (typeof data.chat !== "number") data.chat = 0; // Pastikan chat valid
          if (data.limit < 24) {
          data.limit = 25; // Reset limit menjadi 100
          }
          data.chat = 0; // Reset chat menjadi 0
        }
        console.log("Limit dan total chat semua pengguna berhasil direset.");
      };

      // **Langkah 3: Hapus Session**
      const clearSessions = () => {
        return new Promise((resolve, reject) => {
          const directory = "./session";

          fs.readdir(directory, (err, files) => {
            if (err) {
              console.log("Terjadi kesalahan saat membaca folder:", err);
              reject(err);
              return;
            }

            files.forEach((file) => {
              if (file !== "creds.json") {
                fs.unlink(path.join(directory, file), (err) => {
                  if (err) {
                    console.log("Gagal menghapus file:", err);
                  } else {
                    console.log(`File ${file} berhasil dihapus.`);
                  }
                });
              }
            });
            resolve();
          });
        });
      };

      // **Langkah 4: Kirim Notifikasi**
      const sendNotification = () => {
        return new Promise((resolve) => {
          const q = {
            key: {
              remoteJid: "status@broadcast",
              participant: "0@s.whatsapp.net",
              fromMe: false,
              id: "",
            },
            message: { conversation: "Berhasil Mereset Sistem!" },
          };

          conn.sendMessage(
            `120363236413068628@g.us`,
            {
              text: "*[Server Notif]*\n\nBot baru saja di-reset. Silakan tunggu beberapa detik sebelum menggunakan bot lagi.",
            },
            { quoted: q }
          )
            .then(() => {
              console.log("Notifikasi berhasil dikirim.");
              resolve();
            })
            .catch((err) => {
              console.log("Gagal mengirim notifikasi:", err);
              resolve(); // Lanjutkan meskipun gagal
            });
        });
      };

      // **Jalankan Proses Asinkron**
      (async () => {
        try {
          await createBackup(); // Backup
          await uploadToGitHub(); // Upload ke GitHub
          await resetLimitAndChat(); // Reset Limit dan Chat
          await clearSessions(); // Hapus Session
          await sendNotification(); // Kirim Notifikasi          
        } catch (err) {
          console.log("Terjadi kesalahan dalam proses:", err);
        } finally {
          console.log("Proses reset selesai.");
        }
      })();
    },
    {
      scheduled: true,
      timezone: "Asia/Jakarta",
    }
  );
};

module.exports = handler;