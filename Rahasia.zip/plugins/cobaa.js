let { webp2png } = require("../lib/webp2mp4");
let handler = async (m, { conn, usedPrefix, command }) => {
  let mime = m.quoted.mimetype || "";
  if (!/webp/.test(mime))
    throw `balas stiker dengan caption *${usedPrefix + command}*`;
    m.reply(wait)
  let media = await m.quoted.download();
  if (/webp/.test(mime)) {
    out = await webp2png(media);
  }
  conn.sendMessage(m.chat, { image: out})
}
handler.command = /^(coba)$/i;

module.exports = handler;