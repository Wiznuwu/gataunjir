const { youtubedl, youtubedlv2 } = require("@bochilteam/scraper");
const ytdl = require("ytdl-core");
const yts = require("yt-search")
const fg = require("api-dylux");
const fetch = require("node-fetch");
const axios = require("axios")
let { toAudio } = require("../lib/converter.js");

let handler = async (m, { conn, text, usedPrefix, args, command }) => {
if (!text) throw `Contoh: .${command} https://\nlink yang support: tt, ig, yt, fb`
if (!Func.isUrl(text))
    throw `*• Example :* ${usedPrefix + command} Url`;
let platforms = {
instagram: /instagram</gi,
facebook: /facebook/gi,
tiktok: /tiktok/gi,
youtube: /youtu/gi
};
let platform = Object.keys(platforms).find(key => text.match(key)) || "twitter"
console.log(platform)
switch (platform) {
case "instagram": {
m.reply(wait);
try {
let hasil = []
    let response = await Scraper["Download"].aioDownload(text)
    response.mediaUrl.forEach(obj => {
  if (!hasil.includes(obj.url)) {
    unik.push(obj.url);
  }
});
    for (let i of hasil) {
    m.reply("*[ INSTAGRAM DOWNLOADER ]*", i)    
    }
   } catch {
  let rez = await axios.get(`https://api.betabotz.eu.org/api/download/igdowloader?url=${text}&apikey=${global.apibeta}`)
const unik = [];
rez.data.message.forEach(obj => {
  if (!unik.includes(obj._url)) {
    unik.push(obj._url);
  }
});
    for (let i of unik) {
      m.reply("*[ INSTAGRAM DOWNLOADER ]*", i);
   }  
 }
}
break
case "facebook": {
    m.reply(wait);
    try {
        let hasil = [];
        const unik = [];
        let response = await Scraper["Download"].aioDownload(text);
        console.log(response);
        response.forEach(obj => {
            if (!hasil.includes(obj.url)) {
                unik.push(obj.url);
            }
        });
        for (let i of unik) {
            m.reply("*[ FACEBOOK DOWNLOADER ]*", i);
        }
    } catch {
        let fb = await (
            await fetch("https://skizo.tech/api/fb", {
                method: "POST",
                body: JSON.stringify({
                    url: text,
                }),
                headers: {
                    "Content-Type": "application/json",
                    Authorization: "Akiraa",
                },
            })
        ).json();
        if (fb && fb.length > 0) {
            conn.sendMessage(
                m.chat,
                {
                    video: {
                        url: fb[0].url,
                    },
                    caption: "*[ FACEBOOK DOWNLOADER ]*",
                },
                { quoted: m },
            );
        } else {
            m.reply("No video found.");
        }
    }
}
break 
case "tiktok": {
m.reply(wait);
  try {
    let fetch = await Scraper["Download"].tiktok.v1(text);
    let { data } = fetch;
    let media = await conn.getBuffer(data.play)
    let mp4 = await toAudio(media, 'mp4')
    if (data.images) {
      for (let i of data.images) {
        await conn.sendMessage(
          m.chat,
          {
            image: {
              url: i,
            },
            caption: `*[ TIKTOK SLIDE DOWNLOADER ]*\n*• Title :* ${data.title}\n*• ID :* *[ ${data.id} ]*\n*• Views :* ${Func.formatNumber(data.play_count)}\n*• Likes :* ${Func.formatNumber(data.digg_count)}\n*• Comment :* ${Func.formatNumber(data.comment_count)}\n*• Author :* ${data.author.nickname}`,
          },
          { quoted: m },
        );
      }
    } else {
     const key = await conn.sendMessage(
        m.chat,
        {
          video: {
            url: data.play,
          },
          caption: `*[ TIKTOK VIDEO DOWNLOADER ]*\n*• Title :* ${data.title}\n*• ID :* *[ ${data.id} ]*\n*• Views :* ${Func.formatNumber(data.play_count)}\n*• Likes :* ${Func.formatNumber(data.digg_count)}\n*• Comment :* ${Func.formatNumber(data.comment_count)}\n*• Author :* ${data.author.nickname}`,
        },
        { quoted: m },
      );
     await conn.sendMessage(m.chat, {
                    audio: mp4,
                    mimetype: 'audio/mpeg'
                }, {
                    quoted: key
                })                
    }
  } catch (e) {
    try {
      let tiktok = await Scraper["Download"].tiktok.v2(text);
      let cap = `*[ TIKTOK V2 DOWNLOADER ]*
*• Caption :* ${tiktok.caption}`;
      let key = await conn.sendFile(m.chat, tiktok.server1.url, null, cap, m);
      await conn.sendFile(m.chat, tiktok.audio, null, null, key);
    } catch (e) {
      throw eror;
    }
  }
}
break 
case "youtube": {
m.reply(wait)
if (!args || !args[0])
    throw `Example :\n${usedPrefix + command} https://youtu.be/YzkTFFwxtXI`;
  let q = args[1] || "360p";
  let v = args[0];

  try {
    let item = await ytmp4(args[0], q.split("p")[0]);
    //   if ((item.contentLength).split("MB")[0] >= limit) return m.reply(` ≡  *YT Downloader V1*\n\n*⚖️Size* : ${item.contentLength}\n*🎞️Quality* : ${item.quality}\n\n_The file exceeds the download limit_ *+${limit} MB*\n\n*Link:*\n${await shortUrl(item.videoUrl)}`)
    let captvid = ` *[ YOUTUBE DOWNLOADER ]*

 *Image URL:* ${item.thumb.url || "Tidak diketahui"}
 *Title:* ${item.title || "Tidak diketahui"}
 *Date:* ${item.date || "Tidak diketahui"}
 *Duration:* ${item.duration || "Tidak diketahui"}
 *Channel:* ${item.channel || "Tidak diketahui"}
 *Quality:* ${item.quality || "Tidak diketahui"}
 *Content Length:* ${item.contentLength || "Tidak diketahui"}
 *Description:* ${item.description || "Tidak diketahui"}
`.trim();
    let dls = "Downloading video succes";
    let doc = {
      video: {
        url: item.videoUrl,
      },
      mimetype: "video/mp4",
      caption: captvid,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: v,
          title: item.title,
          body: dls,
          sourceUrl: v,
          thumbnail: await (await conn.getFile(item.thumb.url)).data,
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
} catch {
try {
      let hs = await yts(args[0])
      let a = hs.videos[0]
      let { title, image, ago, timestamp, description } = a
      let respon = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/yt?url=${args[0]}&apikey=${global.apibeta}`)
      let captvid1 = ` *[ YOUTUBE DOWNLOADER ]*

 *Image URL:* ${image || "Tidak diketahui"}
 *Title:* ${title || "Tidak diketahui"}
 *Release Time:* ${ago || "Tidak diketahui"}
 *Duration:* ${timestamp || "Tidak diketahui"}
 *Description:* ${description || "Tidak diketahui"}
`.trim();
       let doc = {
      video: {
        url: respon.result.mp4,
      },
      mimetype: "video/mp4",
      caption: captvid1,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: args[0],
          title: title,
          body: "Sukses",
          sourceUrl: args[0],
          thumbnail: await (await conn.getFile(image)).data,
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
  } catch {
  try {
  let response = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/yt?url=${args[0]}&apikey=${global.apibeta}`)
  let captvid2 = `*[ YOUTUBE DOWNLOADER SUCCESS ]*`
       let doc = {
      video: {
        url: response.result.mp4,
      },
      mimetype: "video/mp4",
      caption: captvid2,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: args[0],
          title: ``,
          body: "Sukses",
          sourceUrl: args[0],
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
    } catch {
  try {
let { data } = await require("axios")({
  "method": "GET",
  "url": "https://api.shannmoderz.xyz/downloader/yt-video?url=" + args[0]
})
let doc = {
      video: {
        url: data.result.download_url,
      },
      mimetype: "video/mp4",
      caption: `*[ YOUTUBE DOWNLOADER SUCCESS ]*`,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: args[0],
          title: ``,
          body: "Sukses",
          sourceUrl: args[0],
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
} catch {
return m.reply("Terjadi Error")
console.log(e)
}
 }
  }
   }
}
break
}
}
handler.help = ["dl *[all links]*", "download *[all links]*"]
handler.tags = ["downloader"]
handler.command = ["dl", "download"]
handler.limit = true;

module.exports = handler;

async function shortUrl(url) {
  let res = await fetch(`https://tinyurl.com/api-create.php?url=${url}`);
  return await res.text();
}

function formatDuration(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  const formattedDuration = [];

  if (hours > 0) {
    formattedDuration.push(`${hours} hour`);
  }

  if (minutes > 0) {
    formattedDuration.push(`${minutes} minute`);
  }

  if (remainingSeconds > 0) {
    formattedDuration.push(`${remainingSeconds} second`);
  }

  return formattedDuration.join(" ");
}

function formatBytes(bytes) {
  if (bytes === 0) {
    return "0 B";
  }
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / 1024 ** i).toFixed(2)} ${sizes[i]}`;
}

async function ytmp4(query, quality = 134) {
  try {
    const videoInfo = await ytdl.getInfo(query, {
      lang: "id",
    });
    const format = ytdl.chooseFormat(videoInfo.formats, {
      format: quality,
      filter: "videoandaudio",
    });
    let response = await fetch(format.url, {
      method: "HEAD",
    });
    let contentLength = response.headers.get("content-length");
    let fileSizeInBytes = parseInt(contentLength);
    return {
      title: videoInfo.videoDetails.title,
      thumb: videoInfo.videoDetails.thumbnails.slice(-1)[0],
      date: videoInfo.videoDetails.publishDate,
      duration: formatDuration(videoInfo.videoDetails.lengthSeconds),
      channel: videoInfo.videoDetails.ownerChannelName,
      quality: format.qualityLabel,
      contentLength: formatBytes(fileSizeInBytes),
      description: videoInfo.videoDetails.description,
      videoUrl: format.url,
    };
  } catch (error) {
    throw error;
  }
}