let handler = async (m, { conn, text, usedPrefix, command }) => {
function msToDate(ms) {
    temp = ms;
    days = Math.floor(ms / (24 * 60 * 60 * 1000));
    daysms = ms % (24 * 60 * 60 * 1000);
    hours = Math.floor(daysms / (60 * 60 * 1000));
    hoursms = ms % (60 * 60 * 1000);
    minutes = Math.floor(hoursms / (60 * 1000));
    minutesms = ms % (60 * 1000);
    sec = Math.floor(minutesms / 1000);
    return days + " Hari " + hours + " Jam " + minutes + " Menit";
    // +minutes+":"+sec;
  }
  const num = m.quoted?.sender || m.mentionedJid?.[0] || m.sender;
  const user = db.data.users[num];
    let pp = await conn
      .profilePictureUrl(num, "image")
      .catch((e) => "https://files.catbox.moe/ifx2y7.png");
    let pacar1= user.pasangan ? user.pasangan : "62819969055517@s.whatsapp.net"
    if (db.data.users[pacar1].pasangan == num) {                      
                        var pacar = `_@${pacar1.split("@")[0]}_`
                        } else if (db.data.users[pacar1].pasangan == "")  {
                        var pacar = `_Jomblo kasian_`
                        } else {
                        var pacar= ' - '
                        }
    let name = user.name;
    let umur = user.age;
    let register = user.created ? "_Sudah daftar _" : "_Belum Daftar_";
    let premium = user.premium ? "✅" : "❎";
    let online =
      user.online * 10 === Date.now()
        ? `_( Offline )${await HariIni(user.online)}_`
        : `_( Online ) Hari ini_`;
    let premiumDate = user.premium
      ? `${msToDate(user.premiumDate - new Date() * 1) || "Tidak ada waktu durasi"}`
      : "Bukan Premium"

    let caption = `*[ PROFILE USER ]*
*• name:* ${name}
*• Title:* *${user.role ? user.role : "_gada_"}*
*• Level:* _${user.level}_
*• Kekayaan:* ${global.convertMoney(user.money + user.bank)}
*• Pasangan:* ${pacar}
*• Tag Users* @${num.split("@")[0]}
*• Status user:* ${online}
*• Jumlah chat:* ${user.chat} *[ hari ini ]*
*• Status Premium:* ${premium}
*• Durasi Premium:* ${user.premiumDate === Infinity ? "Infinity" : premiumDate}`;
    m.reply(caption, pp);
};
handler.help = ["profile"];
handler.tags = ["info"];
handler.command = ["profile"];
handler.register = true

module.exports = handler;

function HariIni(ms) {
  const sekarang = ms;
  const date = new Date(sekarang).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
  });
  const hari = new Date(sekarang).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    hours: "long",
  });
  const jam = new Date(sekarang).getHours();
  const menit = new Date(sekarang).getMinutes();

  return `Terakhir terlihat: ${hari}`;
}