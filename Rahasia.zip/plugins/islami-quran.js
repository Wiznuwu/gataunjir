const fs = require('fs');
const didyoumean2 = require("didyoumean2").default;

let handler = async (m, { conn, text }) => {
  if (!text) throw "Usage: .quran Al Fatihah atau Al Fatihah 1 atau Al-Baqarah 10 15";

  const kataKapital = text.split(' ').map(kata => kata.charAt(0).toUpperCase() + kata.slice(1)).join(' ');
  const surahData = JSON.parse(fs.readFileSync(`lib/quran.json`));
  const namaSurah = surahData.map(s => s.nama);

  // Periksa apakah nama surah valid, jika tidak gunakan hasil koreksi
  let surahName = namaSurah.includes(kataKapital) ? kataKapital : didyoumean2(kataKapital, namaSurah);
  if (!surahName) throw "Surah yang kamu cari tidak ditemukan.";

  // Ambil data surah berdasarkan nama
  const surah = surahData.find((s) => s.nama === surahName);
  if (!surah) throw "Data surah tidak ditemukan.";

  const totalAyat = surah.ayat.length;
  const isSurahPanjang = totalAyat > 15; // Batasan untuk surah panjang (lebih dari 15 ayat)

  // Ambil nomor ayat atau rentang
  const ayatNumbers = text.match(/\d+/g); // Nomor ayat yang diminta (jika ada)
  let selectedAyat;

  if (ayatNumbers && ayatNumbers.length > 0) {
    if (ayatNumbers.length === 1) {
      // Jika hanya satu nomor ayat diberikan
      const ayatNumber = parseInt(ayatNumbers[0]);
      if (ayatNumber < 1 || ayatNumber > totalAyat) throw "Nomor ayat tidak valid.";
      selectedAyat = [surah.ayat[ayatNumber - 1]];
    } else if (ayatNumbers.length === 2) {
      // Jika rentang ayat diberikan
      const start = parseInt(ayatNumbers[0]);
      const end = parseInt(ayatNumbers[1]);
      if (start < 1 || end > totalAyat || start > end) throw "Rentang ayat tidak valid.";
      selectedAyat = surah.ayat.slice(start - 1, end);
    } else {
      throw "Format nomor ayat tidak valid.";
    }
  } else {
    // Jika nomor ayat tidak diberikan
    if (isSurahPanjang) {
      // Untuk surah panjang, kirim semua ayat
      selectedAyat = surah.ayat;
    } else {
      // Untuk surah pendek, kirim semua ayat
      selectedAyat = surah.ayat;
    }
  }

  // Format data ayat untuk pengiriman pesan
  const ayatData = selectedAyat.map(ayat => `${ayat.ar}\n${ayat.id}`).join("\n\n");

  // Kirim teks dan audio (jika surah pendek)
  if (!isSurahPanjang) {
    const audioLink = surah.audio;
    const a = {
      contextInfo: {
        mentionedJid: conn.parseMention("بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ"),
        groupMentions: [],
        isForwarded: true,
        externalAdReply: {
          title: `[ʙᴏᴛ] ᴍᴀᴋɪᴍᴀ マキマ`,
          body: "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ",
          thumbnailUrl: 'https://files.catbox.moe/ry447r.jpg',
          sourceUrl: "https://whatsapp.com/channel/0029VaVGWDa8V0teNLJGWF0e",
          mediaType: 1,
          renderLargerThumbnail: false,
        },
      },
    };
   let key = await conn.reply(m.chat, ayatData, m, a);
    await conn.sendMessage(m.chat, {
      audio: { url: audioLink },
      mimetype: "audio/mp4",
      fileName: `Surah_${surah.nama}.mp4`
    }, { quoted: key });
  } else {
    // Hanya kirim teks untuk surah panjang
  const a = {
      contextInfo: {
        mentionedJid: conn.parseMention("بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ"),
        groupMentions: [],
        isForwarded: true,
        externalAdReply: {
          title: `[ʙᴏᴛ] ᴍᴀᴋɪᴍᴀ マキマ`,
          body: "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ",
          thumbnailUrl: 'https://files.catbox.moe/ry447r.jpg',
          sourceUrl: "https://whatsapp.com/channel/0029VaVGWDa8V0teNLJGWF0e",
          mediaType: 1,
          renderLargerThumbnail: false,
        },
      },
    };
    conn.reply(m.chat, ayatData, m, a);
  }
};

handler.help = ["quran *[surah]*"];
handler.tags = ["islami"];
handler.command = ["quran"];
module.exports = handler;