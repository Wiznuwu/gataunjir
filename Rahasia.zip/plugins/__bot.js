let handler = async (m) => {
    m.reply('*🍁 Lucy Bot is Online [ ! ]*')
}
handler.customPrefix = /^(bot)$/i;
handler.command = new RegExp();

handler.register = false

module.exports = handler