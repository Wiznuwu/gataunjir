let handler = async (m) => {
    m.reply('*🍁 Makima Bot is Online [ ! ]*')
}
handler.customPrefix = /^(bot)$/i;
handler.command = new RegExp();

handler.register = false

module.exports = handler