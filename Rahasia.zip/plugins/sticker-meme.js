let handler = async (m, { conn, text, usedPrefix, command }) => {
    let [atas, bawah] = text.split`|`
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    
    if (!mime) throw `*• Example :* ${usedPrefix + command} MALAS|SEKALI`
    if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} not supported!`
    
    m.reply(wait)
    let img = await q.download()
    
    // Process the image to add text in meme style
    let meme = await addMemeText(img, atas || '', bawah || '')
    
    // Send the processed image as a sticker
    conn.sendImageAsSticker(m.chat, meme, m, { packname: packname, author: author })
}

// Function to add meme-style text to image
async function addMemeText(image, topText, bottomText) {
    const { createCanvas, loadImage } = require('canvas')
    
    // Load the image
    const img = await loadImage(image)
    
    // Create canvas with image dimensions
    const canvas = createCanvas(img.width, img.height)
    const ctx = canvas.getContext('2d')
    
    // Draw the original image
    ctx.drawImage(img, 0, 0, img.width, img.height)
    
    // Configure text style for meme format
    let fontSize = Math.floor(img.width / 8) // Larger text
    ctx.font = `bold ${fontSize}px Arial` // Use Arial if Impact isn't available
    ctx.textAlign = 'center'
    ctx.lineJoin = 'round' // Creates smoother corners for the stroke
    
    // Function to draw the outlined text
    const drawText = (text, y) => {
        // Set the text stroke (outline)
        ctx.strokeStyle = 'black'
        ctx.lineWidth = fontSize / 6
        ctx.strokeText(text.toUpperCase(), img.width / 2, y)
        
        // Set the text fill
        ctx.fillStyle = 'white'
        ctx.fillText(text.toUpperCase(), img.width / 2, y)
    }
    
    // Add top text
    if (topText) {
        drawText(topText, fontSize + 10)
    }
    
    // Add bottom text
    if (bottomText) {
        drawText(bottomText, img.height - 20)
    }
    
    // Return as buffer for sticker creation
    return canvas.toBuffer()
}

handler.help = ['stickermeme','smeme'].map(a => a + " *[atas|bawah]*")
handler.tags = ['sticker']
handler.command = ['stickermeme','smeme']
handler.limit = true
handler.register = true

module.exports = handler