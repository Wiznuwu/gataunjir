let handler = async (m, { conn, text, usedPrefix, command }) => {
    let [atas, bawah] = text.split`|`
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    if (!mime) throw `*• Example :* ${usedPrefix + command} *[upper|lower]*`
    m.reply(wait)
    let img = await q.download()
    let url = await Uploader.catbox(img).catch(async _ => await Uploader.telegraPh(img))
    let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas ? atas : '_')}/${encodeURIComponent(bawah ? bawah : '_')}.png?background=${url}`
    conn.sendImageAsSticker(m.chat, meme, m, { packname: packname, author: author })

}
handler.help = ['stickermeme','smeme'].map(a => a + " *[atas|bawah]*")
handler.tags = ['sticker']
handler.command = ['stickermeme','smeme']
handler.limit = true
handler.register = true
module.exports = handler