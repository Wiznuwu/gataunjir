const fetch = require('node-fetch');
const uploadImage = require('../lib/uploadImage');

let handler = async (m, { conn, usedPrefix, command }) => {
conn.hdr = conn.hdr ? conn.hdr : {};
if (m.sender in conn.hdr) throw "Masih Ada Proses Yang Belum Selesai Kak, Silahkan Tunggu Sampai Selesai Yah >//<";
  try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    
    if (/^image/.test(mime) && !/webp/.test(mime)) {
      const img = await q.download();
      const out = await Uploader.catbox(img)

      m.reply('⏱️ Tunggu sebentar...');

      let api, image, url;

      if (command === 'hd') {
      conn.hdr[m.sender] = true;
        api = await fetch(`https://api.betabotz.eu.org/api/tools/remini?url=${out}&apikey=${apibeta}`);
        image = await api.json();
        url = image.url;
        conn.sendFile(m.chat, url, null, wm, m);
        delete conn.hdr[m.sender];
      } else if (command === 'hd2') {
      conn.hdr[m.sender] = true;
        api = await fetch(`https://api.betabotz.eu.org/api/tools/remini-v2?url=${out}&apikey=${apibeta}`);
        const response = await api.text();
        try {
          image = JSON.parse(response);
          url = image.url;
          conn.sendFile(m.chat, url, null, wm, m);
          delete conn.hdr[m.sender];
        } catch (error) {
          console.error(`Parsing error: ${error}`);
          return m.reply('🚩 Terjadi kesalahan saat memproses gambar.');
          delete conn.hdr[m.sender];
        }
      } else if (command === 'hd3') {
      conn.hdr[m.sender] = true;
        api = await fetch(`https://api.betabotz.eu.org/api/tools/remini-v3?url=${out}&resolusi=4&apikey=${apibeta}`);
        image = await api.json();
        url = image.url;
        console.log(image.url)
        conn.sendFile(m.chat, url, null, wm, m);
        delete conn.hdr[m.sender];
       } else if (command === 'remini') {
       conn.hdr[m.sender] = true;
        api = await fetch(`https://api.betabotz.eu.org/api/tools/remini?url=${out}&apikey=${apibeta}`);
        image = await api.json();
        url = image.url;
        conn.sendFile(m.chat, url, null, wm, m);
        delete conn.hdr[m.sender];
      }
    } else {
      m.reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau tag gambar yang sudah dikirim.`);
      delete conn.hdr[m.sender];
    }
  } catch (error) {
    console.error(error);
    m.reply('🚩 Terjadi kesalahan pada server. Coba lagi nanti.');
    delete conn.hdr[m.sender];
  }
};
handler.limit = true;

module.exports = handler;
handler.help = [
  "hd",
  "hd2",
  "hd3",
  "remini",
].map((a) => a + " *[reply/send media]*");
handler.tags = ["tools"];
handler.premium = false;
handler.command = [
  "hd",
  "hd2",
  "hd3",
  "remini",
];
handler.register = true;
module.exports = handler;