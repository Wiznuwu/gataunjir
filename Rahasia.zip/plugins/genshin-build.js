const fs = require('fs');
const didyoumean2 = require("didyoumean2").default;

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    if (!args[0]) {
        return m.reply('Silakan berikan nama karakter');
    }

    let characterName = args[0].toLowerCase();
    let filePath = "lib/genshin.json";

    try {
        // Baca file JSON sekali saja
        let genshinData = JSON.parse(fs.readFileSync(filePath));
        let tersedia = Object.keys(genshinData);

        // Cek apakah karakter tersedia
        if (!tersedia.includes(characterName)) {
            let maksud = await didyoumean2(characterName, tersedia);
            if (!maksud) {
                return m.reply(`Karakter *${characterName}* tidak ditemukan.`);
            }
            characterName = maksud; // Gunakan hasil dari didyoumean2
        }

        // Ambil data karakter
        let characterData = genshinData[characterName];
        if (!characterData || !characterData.build || !characterData.material) {
            return m.reply(`Data build atau material untuk karakter *${characterName}* tidak ditemukan.`);
        }

        // Kirim file build
        await conn.sendFile(
            m.chat,
            characterData.build, // Asumsikan ini adalah jalur file
            'build.jpg',
            `*[ BUILD ]*\nMenampilkan Build *[ ${characterName} ]*`,
            m
        );

        // Kirim file material
        await conn.sendFile(
            m.chat,
            characterData.material, // Asumsikan ini adalah jalur file
            'material.jpg',
            `*[ MATERIAL ]*\nMenampilkan Material *[ ${characterName} ]*`,
            m
        );
    } catch (error) {
        console.error(error);
        m.reply('Error: ' + error.message);
    }
};

handler.help = ["buildgi *[nama karakter]*"];
handler.tags = ["hoyoverse"];
handler.command = ["buildgi"];
module.exports = handler;