let handler = async (m, { conn, args, usedPrefix, command }) => {
    let data = []
for (let key in global.plugins) {
    if (global.plugins.hasOwnProperty(key)) {
      let help = global.plugins[key].help;
      data.push(help)

    }
  }
const hasil = data.filter(element => element !== undefined)
  .map(element => element[0].replace(/\[|\]/g, ""));
const newArray = hasil.map(str => str.split(' ')[0]);
console.log(newArray)
}
handler.customPrefix = /^(pololo)$/i;
handler.command = new RegExp();

handler.register = false

module.exports = handler