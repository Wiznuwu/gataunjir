let handler = (m) => m;

handler.before = (m, { conn, command, isOwner }) => {
    // Initialize spam tracking object if not exists
    conn.spam = conn.spam || {};
    
    // If no command, just pass through
    if (!command) return;
    
    const spamInfo = conn.spam[m.sender] || {
        lastCommands: [],
        blockedUntil: 0
    };
    
    // Check if user is currently blocked
    const now = new Date().getTime();
    if (spamInfo.blockedUntil > now) {
        m.reply("Kamu terdeteksi melakukan spam, bot tidak akan meresponmu selama 30 detik");
        return true; // Return true to stop command execution
    }
    
    // Add current command timestamp
    spamInfo.lastCommands.push(now);
    
    // Only keep commands from last 6 seconds
    const sixSecondsAgo = now - 6000;
    spamInfo.lastCommands = spamInfo.lastCommands.filter(time => time > sixSecondsAgo);
    
    // Check if user has made 3 or more commands in 6 seconds
    if (spamInfo.lastCommands.length >= 3) {
        spamInfo.lastCommands = []; // Reset commands
        spamInfo.blockedUntil = now + 30000; // Block for 30 seconds
        m.reply("Kamu terdeteksi melakukan spam, bot tidak akan meresponmu selama 30 detik");
        return true; // Return true to stop command execution
    }
    
    // Update spam info in connection
    conn.spam[m.sender] = spamInfo;
};

module.exports = handler;