const toMs = require('ms')
let handler = (m) => m

const usedCommandRecently = new Set()

const isFiltered = (from) => {
    return !!usedCommandRecently.has(from)
}

const addFilter = (from) => {
    usedCommandRecently.add(from)
    setTimeout(() => {
        return usedCommandRecently.delete(from)
    }, 5000)
}

handler.before = async (m, { conn, command}) => {
    if (!conn.orang_spam) conn.orang_spam = []
    const orang_spam = conn.orang_spam
    
    const addSpam = (sender, _db) => {
        let position = false
        Object.keys(_db).forEach((i) => {
            if (_db[i].id === sender) {
                position = i
            }
        })
        if (position !== false) {
            _db[position].spam += 1
        } else {
            const bulin = ({
                id: sender,
                spam: 1,
                expired: Date.now() + toMs('10m')
            })
            _db.push(bulin)
        }
    }

    const ResetSpam = (_dir) => {
        setInterval(() => {
            let position = null
            Object.keys(_dir).forEach((i) => {
                if (Date.now() >= _dir[i].expired) {
                    position = i
                }
            })
            if (position !== null) {
                _dir.splice(position, 1)
            }
        }, 1000)
    }

    const isSpam = (sender, _db) => {
        let found = false
        for (let i of _db) {
            if (i.id === sender) {
                let spam = i.spam
                if (spam >= 3) {
                    found = true
                    return true
                } else {
                    found = true
                    return false
                }
            }
        }
    }

    ResetSpam(orang_spam)

    if (command && isFiltered(m.sender) && m.isGroup) {
        addSpam(m.sender, orang_spam)
        m.reply("Jangan spam! Mohon tunggu beberapa detik.")
        return false
    }

    if (command && isFiltered(m.sender) && !m.isGroup) {
        addSpam(m.sender, orang_spam)
        m.reply("Jangan spam! Mohon tunggu 10 detik.")
        return false
    }

    addFilter(m.sender)
}

module.exports = handler