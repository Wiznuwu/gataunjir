const cheerio = require('cheerio');
const axios = require("axios");
const { File } = require('megajs')
const fs = require('fs')
const { generateWAMessageContent, generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 

// Fungsi untuk mengambil informasi anime
async function getAnimeInfo(url) {
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const animeElements = $('li', '.chivsrc');
    const animeInfo = [];
    animeElements.each((index, element) => {
      const title = $(element).find('h2').text();
      const link = $(element).find('a').attr('href');
      const thumbnail = $(element).find('img').attr('src');
      animeInfo.push({ title, link, thumbnail });
    });
    return animeInfo;
  } catch (error) {
    console.error(error);
    return [];
  }
}

// Fungsi untuk mengambil semua link episode
async function fetchAllEps(url) {
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const episodeLinks = $('a[href*="episode"]');
    const links = [];
    episodeLinks.each((index, element) => {
      const link = $(element).attr('href');
      links.push(link);
    });
    return links.reverse();
  } catch (error) {
    console.error(error);
    return [];
  }
}

// Fungsi untuk mengambil link download
function fetchlink(html) {
  const $ = cheerio.load(html);
  const downloadDiv = $('div.download');
  const data = {
    mega: downloadDiv.find('ul li:contains("480p") a:contains("Mega")').attr('href'),
    pdrain: downloadDiv.find('ul li:contains("480p") a:contains("Pdrain")').attr('href') || downloadDiv.find('ul li:contains("480p") a:contains("PDrain")').attr('href')
  };
  return data;
}

// Fungsi untuk mengambil link movie
async function fetchLinkMovie(url) {
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const link480p = $('.yondarkness-title:contains("360p")').next('.yondarkness-item').find('a:contains("Mega")').attr('href');
    return link480p;
  } catch (error) {
    console.error(error);
    return null;
  }
}

// Fungsi untuk memeriksa URL valid
function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}

// Fungsi untuk membuat gambar
async function createImage(url) {
  const { imageMessage } = await generateWAMessageContent({
    image: {
      url
    }
  }, {
    upload: conn.waUploadToServer
  });
  return imageMessage;
}

// Fungsi utama
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) throw `> Contoh penggunaan\n.${command} Dr Stone`;
  try {
    const url = `https://otakudesu.cloud/?s=${text}+&post_type=anime`;
    let hasil = await getAnimeInfo(url);
    
    // Cek jika hasil kosong
    if (hasil.length === 0) {
      return m.reply(`> Anime yang kamu cari tidak ada.\nContoh penggunaan:\n.${command} Dr Stone`);
    }

    let all = await Promise.all(hasil.map(me => fetchAllEps(me.link)));

    // Cek jika all kosong
    if (all.length === 0) {
      return m.reply(`> Anime yang kamu cari tidak ada.\nContoh penggunaan:\n.${command} Dr Stone`);
    }

    let array = [];
    for (let i = 0; i < all.length; i++) {
      let subArray = all[i];
      let subArrayData = [];
      for (let j = 0; j < subArray.length; j++) {
        let w = j + 1; // Episode index (1-based)
        let linkeps = subArray[j]; // Mengambil link dari subArray        
        subArrayData.push({
          rows: [{
            headers: "Download Episode",
            title: `Episode ${w}`,
            body: ``,
            command: `${linkeps}@@b` // Menggunakan link episode
          }]
        });
      }
      array.push(subArrayData);
    }

    let listMessages = array.map((subArrayData) => {
      let transformedData = subArrayData.map(item => ({
        ...(item.headers ? { title: item.headers } : {}),
        rows: item.rows.map(row => ({
          header: row.headers,
          title: row.title,
          description: row.body,
          id: row.command
        }))
      }));

      return {
        title: "LIST EPISODE",
        sections: transformedData
      };
    });

    let push = await Promise.all(hasil.map(async (lucuy, i) => {
      let listMessage = listMessages[i];
      return {
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: `${lucuy.title}`
        }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
          text: "_Anime Downloader_"
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `Anime - ${i + 1}`,
          hasMediaAttachment: true,
          imageMessage: await createImage(lucuy.thumbnail)
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [{
            name: "single_select",
            buttonParamsJson: JSON.stringify(listMessage)
          }]
        })
      };
    }));

    const bot = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `*Pilih Anime Yang Ingin Kamu Tonton*`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: 'Created By Mephistod'
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: push
            })
          })
        }
      }
    }, { quoted: m });

    await conn.relayMessage(m.chat, bot.message, {
      messageId: bot.key.id
    });
  } catch (error) {
    console.log(error);
    m.reply("judul yang kamu cari tidak ditemukan");
  }
};
handler.before = async (m, { conn }) => {
  if (m.isBaileys || !m.text || !m.text.endsWith('@@b') || !m.quoted) return;
  let pilihan = m.text.replace(/@@b$/, '');
  console.log(pilihan);
  m.reply(wait);  
  let html = await Func.fetchJson(pilihan);
  const hasil = await fetchlink(html);
  let pdrainLink = hasil.pdrain;
  if (pdrainLink && isValidUrl(pdrainLink)) {
    try {
      let response = await axios.get(pdrainLink);
      let $ = cheerio.load(response.data);
      let ogVideoUrl = $('meta[property="og:video:url"]').attr('content');
      if (ogVideoUrl) {
        conn.sendMessage(m.chat, { video: { url: ogVideoUrl }, caption: `Anime Downloader Done!` }, { quoted: m });
        return;
      }
    } catch {
      console.log("Error in Pdrain link:");
    }
  }
  let result = hasil.mega || await fetchLinkMovie(pilihan);
  console.log(result);
  let kon = await axios.get(result);
  const responseUrl = kon.request.res.responseUrl;
  try {
    const file = File.fromURL(responseUrl);
    file.loadAttributes(error => {
      if (error) return m.reply("Gagal mengirim episode yang kamu minta, hal ini dapat terjadi karena link download pada web telah expired!"); 
      file.download((error, data) => {
        if (error) return m.reply("Gagal mengirim episode yang kamu minta, hal ini dapat terjadi karena link download pada web telah expired!"); 
        conn.sendMessage(m.chat, { video: data, caption: file.name }, { quoted: m });
      });
    });
  } catch {
    m.reply("Gagal mengirim episode yang kamu minta, hal ini dapat terjadi karena link download pada web telah expired!"); 
  }
};
handler.help = ["anime", "otakudesu"].map(a => a + " *[judul]*");
handler.tags = ["downloader", "premium"];
handler.command = ["anime", "otakudesu"];
handler.register = true;
handler.private = true;

module.exports = handler;