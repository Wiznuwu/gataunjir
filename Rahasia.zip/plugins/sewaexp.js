let handler = (m) => m;
handler.before = async function (m) {
const woi = m.chat
      let user = global.db.data.chats[m.chat];
  if (user.sewa && new Date() - user.expired > 0 ) {
  user.sewa = false;
    user.expired = 0;
  await conn.sendMessage(woi, { text: "*❏ SEWA BERAKHIR*\n> Bot akan keluar dari grub, silahkan hubungi owner jika ingin menyewa bot lagi." })
  await conn.groupLeave(woi);
 }
}

module.exports = handler;