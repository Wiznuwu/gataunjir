const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
  const [commandName, ...args] = text.split(/\s+/);
  if (commandName.toLowerCase() === "start") {
    conn.gemini = conn.gemini || {};
    conn.gemini[m.sender] = {
      userName: conn.getName(m.sender),
      pictM: 'https://files.catbox.moe/omg002.png',
      history: []
    };
    m.reply(`Hai!, Gemini ai siap di gunakan`);
  } else if (commandName.toLowerCase() === "stop") {
    if (conn.gemini[m.sender]) {
      clearTimeout(conn.gemini[m.sender].timeoutId);
      delete conn.gemini[m.sender];
      m.reply("Sesi chat dengan Gemini telah dihentikan.");
    } else {
      m.reply("Tidak ada sesi chat Gemini yang aktif saat ini.");
    }
  } else if (commandName.toLowerCase() === "reset") {
    if (conn.gemini[m.sender]) {
      conn.gemini[m.sender].history = [];
      m.reply("Sukses mereset sesi.");
    } else {
      m.reply("Tidak ada sesi chat Gemini yang aktif saat ini.");
    }
  } else {
    m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
  }
};

handler.before = async (m, { conn, usedPrefix }) => {
  conn.gemini = conn.gemini || {};

  const prefixes = [">", "=>", "$"];
  
  if (m.isGroup && !m.sender.includes(idOwner)) return;
  if (
    m.isGroup &&
    !(m.quoted?.fromMe === true) &&
    (!m.mentionedJid || !m.mentionedJid.includes(conn.user.jid))
  ) return;
  if (!conn.gemini[m.sender]) return;
  if (m.text.match(global.prefix)) return;
  if (prefixes.some(prefix => m.text.startsWith(prefix))) return;
  if (m?.quoted?.mtype === "interactiveMessage") return;
  if (!m.text) return;

  const botJid = conn.user.jid.split("@")[0];
  const regex = new RegExp(`@${botJid}\\b`, "gi");
  m.text = m.text.replace(regex, "").trim();
  if (!m.text) {
    m.text = "halo";
  }

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const genAI = new GoogleGenerativeAI(apiKey);

    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-thinking-exp-01-21",
      systemInstruction: `nama kamu adalah Gemini kamu adalah asisten yang tau segalanya, jawab dengan singkat, padat, jelas, gunakan bahasa gaul saat menjawab seperti (lu, gw, apasi), gunakan 1 emoji saja di akhir kalimat, gunakan emoji (😊☺️😌🙂‍↔️🤭🫢), dan saat ini Gemini sedang berbicara dengan ${conn.gemini[m.sender].userName}`
    });

    const generationConfig = {
      temperature: 2,
      topP: 0.95,
      topK: 40,
      maxOutputTokens: 8192,
      responseMimeType: "text/plain"
    };

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    let result;

    const chatSession = model.startChat({
      generationConfig,
      history: conn.gemini[m.sender].history || []
    });

    if (mime) {
      const buffer0 = await q.download();
      const base64Image = buffer0.toString('base64');
      const Buffer01 = Buffer.from(buffer0);
      const File = await uploadFile(Buffer01, mime, new Date());
      let prompt = m.text || "jelaskan gambar ini";
      
      const userMessage = {
        role: "user",
        parts: [
          {
            fileData: {
              mimeType: mime,
              fileUri: File.file.uri
            }
          },
          { text: `(@${m.sender.split("@")[0]}) ${conn.getName(m.sender)}: ${prompt}` }
        ]
      };

      const image = {
        inlineData: {
          data: base64Image,
          mimeType: mime
        }
      };

      result = await chatSession.sendMessage([prompt, image]);
      
      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.gemini[m.sender].history.push(userMessage, modelResponse);
    } else {
      const userMessage = {
        role: "user",
        parts: [{ text: m.text }]
      };

      result = await chatSession.sendMessage(m.text);

      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.gemini[m.sender].history.push(userMessage, modelResponse);
    }

    await conn.reply(m.chat, result.response.text(), m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: "Gemini",
          body: "by Wisnu",
          thumbnailUrl: conn.gemini[m.sender].pictM,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    });
  } catch (error) {
    console.log(error);
    m.reply('An error occurred. Please try again later.');
  }
};

handler.help = ["gemini3"].map((a) => a + " *[start/stop]*");
handler.tags = ["ai"];
handler.command = ["gemini3"];
handler.private = true;
module.exports = handler;

async function uploadFile(input, mimeType, displayName) {
  const fileManager = new GoogleAIFileManager(process.env.GEMINI_API_KEY);
  
  let buffer;
  if (Buffer.isBuffer(input)) {
    buffer = input;
  } else if (typeof input === 'string') {
    const fs = require("fs");
    buffer = await fs.readFileSync(input);
  } else {
    throw new Error('Input must be either a file path (string) or a Buffer');
  }
  
  const boundary = '----WebKitFormBoundary' + Math.random().toString(36).substring(2);
  
  let body = '';
  
  body += `--${boundary}\r\n`;
  body += 'Content-Type: application/json\r\n\r\n';
  body += JSON.stringify({
    file: {
      mimeType: mimeType,
      displayName: displayName || 'file'
    }
  });
  body += '\r\n';
  
  body += `--${boundary}\r\n`;
  body += `Content-Type: ${mimeType}\r\n`;
  body += `Content-Disposition: form-data; name="file"; filename="${displayName || 'file'}"\r\n\r\n`;
  
  const bodyStart = Buffer.from(body, 'utf8');
  const bodyEnd = Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8');
  const multipartBody = Buffer.concat([bodyStart, buffer, bodyEnd]);
  
  const response = await fetch(
    `https://generativelanguage.googleapis.com/upload/v1beta/files?uploadType=multipart&key=${fileManager.apiKey}`,
    {
      method: "POST",
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Accept': 'application/json'
      },
      body: multipartBody
    }
  );
  
  const uploadResponse = await response.json();
  
  if (!response.ok) {
    throw new Error(`Upload failed: ${JSON.stringify(uploadResponse)}`);
  }
  
  return uploadResponse;
}