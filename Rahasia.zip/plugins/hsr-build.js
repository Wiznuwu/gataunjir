const fs = require('fs');
const didyoumean2 = require("didyoumean2").default;

let handler = async (m, { conn, args }) => {
    if (!args[0]) {
        return m.reply('Silakan berikan nama karakter.');
    }

    let characterName = args[0].toLowerCase();
    let filePath = "lib/hsr.json";

    try {
        // Cek apakah file JSON ada
        if (!fs.existsSync(filePath)) {
            return m.reply('Data karakter tidak ditemukan.');
        }

        // Baca dan parse file JSON
        let jsonData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        let tersedia = Object.keys(jsonData);

        // Cek apakah karakter tersedia
        if (!tersedia.includes(characterName)) {
            let maksud = await didyoumean2(characterName, tersedia);
            if (!maksud) {
                return m.reply(`Karakter *${characterName}* tidak ditemukan.`);
            }
            characterName = maksud; // Langsung gunakan hasil dari maksud
        }

        // Pastikan data build ada
        if (!jsonData[characterName]?.build) {
            return m.reply(`Data build untuk karakter *${characterName}* tidak tersedia.`);
        }

        let buildData = jsonData[characterName].build;

        // Kirim data build
        await conn.sendFile(
            m.chat,
            buildData,
            'build.jpg',
            `*\`[ BUILD ]\`*\nMenampilkan Build untuk *${characterName}*`,
            m
        );
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan. Pastikan format data sudah benar atau periksa log untuk detailnya.');
    }
};

handler.help = ["buildhsr *[nama karakter]*"];
handler.tags = ["hoyoverse"];
handler.command = ["buildhsr"];
module.exports = handler;