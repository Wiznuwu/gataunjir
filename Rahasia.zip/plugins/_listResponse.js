let fs = require("fs");

let handler = (m) => m;

handler.before = async function (m, { conn, user, isBotAdmin, isAdmin }) {
  // Abaikan kondisi tertentu
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup || !m.text) return true;

  let directory = "./database/list.json";
  if (!fs.existsSync(directory)) return true; // Abaikan jika database tidak ada

  let jsonData = fs.readFileSync(directory);
  let existingData = JSON.parse(jsonData);

  let chat = m.chat; // Chat ID
  if (!existingData[chat]) return true; // Abaikan jika tidak ada data untuk chat ini

  // Ambil semua kata hanya untuk chat ini (dengan lowercase)
  let wordList = [];
  for (let userId in existingData[chat]) {
    wordList.push(...Object.keys(existingData[chat][userId]).map(word => word.toLowerCase())); // Semua kata diubah ke huruf kecil
  }

  // Periksa apakah m.text ada dalam wordList (case-insensitive)
  let inputText = m.text.toLowerCase(); // Ubah m.text menjadi huruf kecil
  if (!wordList.includes(inputText)) return true; // Abaikan jika tidak ada dalam daftar

  // Temukan entri yang sesuai di database untuk chat ini
  for (let userId in existingData[chat]) {
    let userData = existingData[chat][userId];
    if (userData[inputText]) { // Cari dengan key lowercase
      let response = userData[inputText];

      // Kirim respon sesuai jenis data
      if (typeof response === "string") {
        m.reply(response)
      } else if (response.url) {
        if (response.stiker) {
          conn.sendImageAsSticker(m.chat, response.url, m, { packname: "Custom Pack", author: "Custom Author" });
        } else {
          conn.sendMessage(m.chat, { image: { url: response.url } }, { quoted: m });
        }
      }
      break; // Respon ditemukan dan dikirim, tidak perlu cek lainnya
    }
  }

  return true; // Abaikan chat lain setelah proses selesai
};

module.exports = handler;