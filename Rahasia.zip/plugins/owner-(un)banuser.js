let handler = async (m, { conn, text, command}) => {
switch (command) {
case "ban":
case "banned": {
  if (m.quoted) {
    if (m.quoted.sender === conn.user.jid)
      return;
    let usr = m.quoted.sender;
    db.data.users[usr].banned = true;
    m.reply(`Berhasil Membanned User @${usr.split("@")[0]}`)
    return;
  }
  if (!m.mentionedJid[0]) throw "Masukkan user yang ingin di ban\n\nExample: .ban @tag";
  
  let users = m.mentionedJid.filter(
    (u) => !(u == u.includes(conn.user.jid)),
  );
  
  for (let user of users)
    if (user.endsWith("@s.whatsapp.net"))
      db.data.users[users].banned = true;
      m.reply(`Berhasil Membanned User @${users.split("@")[0]}`)
}
break 
case "unban":
case "unbanned": {
  if (m.quoted) {
    if (m.quoted.sender === conn.user.jid)
      return;
    let usr = m.quoted.sender;
    db.data.users[usr].banned = false;
    m.reply(`Berhasil unbanned User @${usr.split("@")[0]}`)
    return;
  }
  if (!m.mentionedJid[0]) throw "Masukkan user yang ingin di ban\n\nExample: .ban @tag";
  
  let users = m.mentionedJid.filter(
    (u) => !(u == u.includes(conn.user.jid)),
  );
  
  for (let user of users)
    if (user.endsWith("@s.whatsapp.net"))
      db.data.users[users].banned = true;
      m.reply(`Berhasil unbanned User @${users.split("@")[0]}`)
}
break 
}
}
handler.help = ["ban `[@user]`", "unban `[@user]`"];
handler.tags = ["owner"];
handler.command = ["ban", "banned", "unban", "banned"];
handler.mods = true;
handler.owner = true;
module.exports = handler;