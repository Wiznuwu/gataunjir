let handler = async (m, { conn }) => {
  const ytdl = require("@distube/ytdl-core");
const { getRandomIPv6 } = require("@distube/ytdl-core/lib/utils");

const agentForARandomIP = ytdl.createAgent(undefined, {
  localAddress: getRandomIPv6("0000:0000:0000:0000:0000:ffff:982a:d844"),
});

ytdl.getBasicInfo("http://www.youtube.com/watch?v=aqz-KE-bpKQ", { agent: agentForARandomIP });

const agentForAnotherRandomIP = ytdl.createAgent(undefined, {
  localAddress: getRandomIPv6("0000:0000:0000:0000:0000:ffff:982a:d844"),
});

ytdl.getInfo("http://www.youtube.com/watch?v=aqz-KE-bpKQ", { agent: agentForAnotherRandomIP });
};
handler.command = ["tes"]
module.exports = handler;