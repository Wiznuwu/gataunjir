let handler = async (m, { conn, text }) => {
  if (!text) throw `Masukan Text.`;
  try {
    await conn.updateProfileName(text).catch((_) => _);
    conn.reply(m.chat, "SUCCESS ✅️", m);
  } catch {
    throw "Error";
  }
};
handler.help = ["setnamebot `[teks?]`"];
handler.tags = ["owner"];
handler.command = ["setnamebot"];
handler.owner = true;

module.exports = handler;