const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");

const apiKey = process.env.GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(apiKey);

async function Gemini(pesan) {
const model = genAI.getGenerativeModel({
  model: "gemini-2.0-flash-thinking-exp-01-21",
});

const generationConfig = {
  temperature: 0.7,
  topP: 0.95,
  topK: 64,
  maxOutputTokens: 65536,
  responseMimeType: "text/plain",
};

  const chatSession = model.startChat({
    generationConfig,
    history: [],
      })

  const result = await chatSession.sendMessage(pesan);
  return result.response.text()
}

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
switch (command) {
case "ai":
case "openai": {
if (!text) return m.reply("contoh: .ai kamu siapa")
 const response = await Gemini(text)
    var teks = `*© AI - Asistent New Latest*\n\n${response}`
m.reply(teks)
  }
break;
case "gpt":
case "chatgpt": {
if (!text) return m.reply("contoh: .chatgpt kamu siapa")
const response = await Gemini(text)
    var teks = `*© AI - Gpt4*\n\n${response}`
m.reply(teks)
   }
break
case "gemini": {
if (!text) return m.reply("contoh: .gemini kamu siapa")
const response = await Gemini(text)
    var teks = `*© AI - Gemini*\n\n${response}`
m.reply(teks)
}
break
  }
 }
handler.help = ["chatgpt", "openai", "gemini"].map((a) => a + " *[question]*");
handler.tags = ["ai"];
handler.command = ["ai", "chatgpt", "openai", "gpt", "gemini"];

module.exports = handler;