const axios = require ("axios")

async function fetchWithModel(content, model) {
    try {
        const response = await axios.post('https://luminai.my.id/', {
            content,
            model
        });

        console.log(response.data);
        return response.data;
    } catch (error) {
        console.error(error);
        throw error;
    }
}
   
async function askGpt4(prompt) {
  const session_hash = Math.random().toString(36).substring(2).slice(1);
  const unique_id = Math.random().toString(36).substring(2).slice(1);
  
  const res = await axios({
    method: "POST",
    url: "https://finechatserver.erweima.ai/api/v1/gpt2/free-gpt2/chat",
    data: {
      prompt,
      sessionId: session_hash
    },
    headers: {
      "Uniqueid": unique_id,
      "User-Agent": "okhttp/4.9.0",
      "Referer": "https://www.yeschat.ai/",
      "Origin": "https://www.yeschat.ai",
      "Content-Type": "application/json"
    }
  });
 console.log(res)
  const messages = res.data.match(/"message":"(.*?)"/g) || []; 
  const response = messages.map(message => message.replace(/"message":"(.*?)"/, '$1')).join('');
  return response;
}

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
switch (command) {
case "ai":
case "openai": {
if (!text) return m.reply("contoh: .ai kamu siapa")
m.reply(wait)
 const response = await fetchWithModel(text, 'gemini-pro')
    var teks = `*© AI - Asistent New Latest*\n\n${response.result}`
m.reply(teks)
  }
break;
case "gpt":
case "chatgpt": {
if (!text) return m.reply("contoh: .chatgpt kamu siapa")
m.reply(wait)
const response = await fetchWithModel(text, 'gpt-4o')
    var teks = `*© AI - Gpt4*\n\n${response.result}`
m.reply(teks)
   }
break
  }
 }
handler.help = ["ai", "chatgpt", "openai", "gpt"].map((a) => a + " *[question]*");
handler.tags = ["ai"];
handler.command = ["ai", "chatgpt", "openai", "gpt"];

module.exports = handler;