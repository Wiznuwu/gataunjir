let { 
    sticker5 
} = require('../lib/sticker')
let fs = require('fs')
let fetch = require('node-fetch')
const https = require('https');
const path = require('path');

let handler = async (m, {
    conn, 
    args, 
    text, 
    usedPrefix, 
    command
}) => {
        
    text = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.quoted && m.quoted.caption ? m.quoted.caption : m.quoted && m.quoted.description ? m.quoted.description : ''
    if (!text) throw `Example : ${usedPrefix + command} Lagi Ruwet`
    
    let res; 
    try {
        if (command === 'bratvid') {
            res = `https://api.betabotz.eu.org/api/maker/brat-video?text=${text}&apikey=${apibeta}`
        } else if (command === 'attp') {
            res = `https://api.betabotz.eu.org/api/maker/attp?text=${text}&apikey=${apibeta}`;
        } else if (command === 'ttp') {
            res = `https://api.betabotz.eu.org/api/maker/ttp?text=${text}&apikey=${apibeta}`;
        } else if (command === 'brat') {
            res = `https://api.betabotz.eu.org/api/maker/brat?text=${text}&apikey=${apibeta}`;
        }
                
        if (res) {
        try {
           await conn.sendImageAsSticker(m.chat, res, m, {
      packname: global.packname,
      author: global.author,
    });
       } catch {
       try {
       const downloadedPath = await downloadMP4(res);
       conn.sendVideoAsSticker(m.chat, downloadedPath, m, {
      packname: kiri || global.packname,
      author: kanan || global.author,
    });
    await fs.unlinkSync(downloadedPath);
               console.log(`File tersimpan di: ${downloadedPath}`);
    } catch (error) {
        console.error('Terjadi kesalahan:', error.message);
    }
}
        } else {
            throw 'Pembuatan stiker gagal'
        }
        
    } catch (e) {
        console.log('Error:', e)
        throw "terjadi error"
    }
}

handler.command = ["attpp", "ttp", "brat", "bratvid"]
handler.help = ['attp *[text]*', 'ttp *[text]*', 'brat *[text]*', "bratvid *[text]*"]
handler.tags = ['sticker', 'tools']

handler.limit = true;

module.exports = handler;



function downloadMP4(url) {
    // Membuat nama file berdasarkan timestamp
    const fileName = `${new Date().toISOString().replace(/[:.]/g, '-')}.mp4`;
    
    // Membuat path lengkap untuk menyimpan file
    const filePath = path.join(__dirname, 'downloads', fileName);
    
    // Memastikan direktori downloads ada
    if (!fs.existsSync(path.join(__dirname, 'downloads'))) {
        fs.mkdirSync(path.join(__dirname, 'downloads'));
    }
    
    // Membuat write stream
    const fileStream = fs.createWriteStream(filePath);
    
    return new Promise((resolve, reject) => {
        https.get(url, (response) => {
            // Cek jika response adalah redirect
            if (response.statusCode === 302 || response.statusCode === 301) {
                downloadMP4(response.headers.location)
                    .then(resolve)
                    .catch(reject);
                return;
            }
            
            // Cek status code
            if (response.statusCode !== 200) {
                reject(new Error(`Failed to download: ${response.statusCode}`));
                return;
            }
            
            // Pipe response ke file
            response.pipe(fileStream);
            
            // Handle events
            fileStream.on('finish', () => {
                fileStream.close();
                console.log(`File berhasil didownload: ${fileName}`);
                resolve(filePath);
            });
            
            fileStream.on('error', (err) => {
                fs.unlink(filePath, () => {}); // Hapus file jika error
                reject(err);
            });
        }).on('error', (err) => {
            fs.unlink(filePath, () => {}); // Hapus file jika error
            reject(err);
        });
    });
}