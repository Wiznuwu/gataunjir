let { sticker5 } = require('../lib/sticker')
let fs = require('fs/promises')
let fetch = require('node-fetch')
const https = require('https')
const path = require('path')
const fsSync = require('fs')

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    text = text || m.quoted?.text || m.quoted?.caption || m.quoted?.description || ''
    if (!text) throw `Example : ${usedPrefix + command} Lagi Ruwet`
    
    try {
        const apiEndpoints = {
            'bratvid': 'brat-video',
            'attp': 'attp',
            'ttp': 'ttp',
            'brat': 'brat'
        }
        
        const endpoint = apiEndpoints[command]
        if (!endpoint) throw 'Invalid command'
        
        const res = `https://api.betabotz.eu.org/api/maker/${endpoint}?text=${text}&apikey=${apibeta}`
        
        try {
            await conn.sendImageAsSticker(m.chat, res, m, {
                packname: global.packname,
                author: global.author,
            })
        } catch {
            try {
                const downloadDir = path.join(__dirname, 'downloads')
                await fs.mkdir(downloadDir, { recursive: true })
                
                const downloadedPath = await downloadMP4(res, downloadDir)
                
                await conn.sendVideoAsSticker(m.chat, downloadedPath, m, {
                    packname: kiri || global.packname,
                    author: kanan || global.author,
                })
                
                // Clean up downloaded file
                await fs.unlink(downloadedPath)
                
                // Try to remove downloads directory if empty
                const files = await fs.readdir(downloadDir)
                if (files.length === 0) {
                    await fs.rmdir(downloadDir)
                }
                
            } catch (error) {
                console.error('Error processing video:', error)
                throw 'Failed to process video sticker'
            }
        }
    } catch (e) {
        console.error('Handler error:', e)
        throw 'An error occurred'
    }
}

handler.command = ["attpp", "ttp", "brat", "bratvid"]
handler.help = ['attp *[text]*', 'ttp *[text]*', 'brat *[text]*', "bratvid *[text]*"]
handler.tags = ['sticker', 'tools']
handler.limit = true

async function downloadMP4(url, downloadDir) {
    const fileName = `${Date.now()}.mp4`
    const filePath = path.join(downloadDir, fileName)
    
    return new Promise((resolve, reject) => {
        const fileStream = fsSync.createWriteStream(filePath)
        
        const handleError = async (err) => {
            fileStream.destroy()
            if (fsSync.existsSync(filePath)) {
                await fs.unlink(filePath)
            }
            reject(err)
        }
        
        https.get(url, (response) => {
            if (response.statusCode === 302 || response.statusCode === 301) {
                fileStream.destroy()
                downloadMP4(response.headers.location, downloadDir)
                    .then(resolve)
                    .catch(reject)
                return
            }
            
            if (response.statusCode !== 200) {
                handleError(new Error(`Download failed: ${response.statusCode}`))
                return
            }
            
            response.pipe(fileStream)
            
            fileStream.on('finish', () => {
                fileStream.close()
                resolve(filePath)
            })
            
            fileStream.on('error', handleError)
        }).on('error', handleError)
    })
}

module.exports = handler