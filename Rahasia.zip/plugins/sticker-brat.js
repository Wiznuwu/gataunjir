let { 
    sticker5 
} = require('../lib/sticker')
let fs = require('fs')
let fetch = require('node-fetch')

let handler = async (m, {
    conn, 
    args, 
    text, 
    usedPrefix, 
    command
}) => {
        
    text = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.quoted && m.quoted.caption ? m.quoted.caption : m.quoted && m.quoted.description ? m.quoted.description : ''
    if (!text) throw `Example : ${usedPrefix + command} Lagi Ruwet`
    m.reply(wait)
    let res; 
    try {
        if (command === 'attp') {
            res = `https://api.betabotz.eu.org/api/maker/attp?text=${text}&apikey=${apibeta}`;
        } else if (command === 'ttp') {
            res = `https://api.betabotz.eu.org/api/maker/ttp?text=${text}&apikey=${apibeta}`;
        } else if (command === 'brat') {
            res = `https://api.betabotz.eu.org/api/maker/brat?text=${text}&apikey=${apibeta}`;
        }
                
        if (res) {
           await conn.sendImageAsSticker(m.chat, res, m, {
      packname: global.packname,
      author: global.author,
    });
        } else {
            throw 'Pembuatan stiker gagal'
        }
        
    } catch (e) {
        console.log('Error:', e)
        throw "terjadi error"
    }
}

handler.command = ["attpp", "ttp", "brat"]
handler.help = ['attp *[text]*', 'ttp *[text]*', 'brat *[text]*']
handler.tags = ['sticker', 'tools']

module.exports = handler