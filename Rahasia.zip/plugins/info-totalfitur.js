let fs = require("fs");
let handler = async (m, { conn, args, command }) => {
  conn.listPlug = []
for (let key in global.plugins) {
    if (global.plugins.hasOwnProperty(key)) {
      let help = global.plugins[key].help;
      conn.listPlug.push(help)

    }
  }
const hasil = conn.listPlug.filter(element => element !== undefined)
  .map(element => element[0].replace(/\[|\]/g, ""));
const newArray = hasil.map(str => str.split(' ')[0]);
conn.listPlug = []
conn.listPlug.push(newArray)
  conn.sendButton(m.chat,[["BACK TO MENU",".menu"],["INFO SCRIPT",".sc"],["GROUP BOT",".gcbot"]], m, {
  footer: `akiraa has a total of features: *[ ${conn.listPlug[0].length} ]*`
  })
};
handler.help = ["totalfitur"].map((a) => a + " *[get total features]*");
handler.tags = ["info"];
handler.command = ["totalfitur"];
handler.register = true;
module.exports = handler;