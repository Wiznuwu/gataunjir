const similarity = require("similarity");
const threshold = 0.72;
let handler = (m) => m;
handler.before = async (m, { conn }) => {
  let id = m.chat;
  if (
    !m.quoted ||
    !m.quoted.fromMe ||
    !m.text ||
    !/Ketik.*hime/i.test(m.quoted.text) ||
    /.*hime/i.test(m.text)
  )
    return !0;
  conn.tebakchara = conn.tebakchara ? conn.tebakchara : {};
  if (!(id in conn.tebakchara))
    return conn.reply(m.chat, "Soal itu telah berakhir", m);
  if (m.quoted.id == conn.tebakchara[id][0].id) {
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text);
    if (isSurrender) {
      clearTimeout(conn.tebakchara[id][3]);
      delete conn.tebakchara[id];
      return conn.reply(m.chat, "*Yah Menyerah :( !*", m);
    }
    let json = JSON.parse(JSON.stringify(conn.tebakchara[id][1]));
    // m.reply(JSON.stringify(json, null, '\t'))
    if (m.text.toLowerCase() == json.hasil.result.name.toLowerCase().trim()) {
      global.db.data.users[m.sender].exp += conn.tebakchara[id][2];
      conn.reply(m.chat, `✅ *Benar!*\n+${conn.tebakchara[id][2]} XP`, m);
      clearTimeout(conn.tebakchara[id][3]);
      delete conn.tebakchara[id];
    } else if (
      similarity(
        m.text.toLowerCase(),
        json.hasil.result.name.toLowerCase().trim(),
      ) >= threshold
    )
      m.reply(`❗ *Dikit Lagi!*`);
    else conn.reply(m.chat, `❌ *Salah!*`, m);
  }
  return !0;
};
module.exports = handler;

const buttontebaklogo = [["tebaklogo", "/tebaklogo"]];