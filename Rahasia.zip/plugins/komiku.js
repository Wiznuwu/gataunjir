async function fetchAllComicTitles(url, maxPages) {
async function getComicTitles(html) {
const $ = require('cheerio').load(html);
const titles = [];
$('.bigor .tt').each((i, el) => {
titles.push($(el).text().trim());
});
return titles;
}
async function fetchComicTitles(judul, page, maxPages) {
const url = 'https://kiryuu.org/'
const html = await Func.fetchJson(url + `page/${page}/?s=${judul}`);
const titles = await getComicTitles(html);
if (titles.length === 0) {
return [];
}
return titles.concat(await fetchComicTitles(url, page + 1, maxPages));
}
const allTitles = await fetchComicTitles(url, 1, maxPages);
return allTitles; // <--- Add this line
}
const title = await fetchAllComicTitles("solo leveling", 20);
console.log(title);


const html = await Func.fetchJson("https://kiryuu.org/manga/solo-leveling/")
const $ = cheerio.load(html);
const chapterLinks = [];
$('#chapterlist ul li').each((index, element) => {
const chapterLink = $(element).find('a').attr('href');
chapterLinks.push(chapterLink);
});
console.log(chapterLinks);

const regex = /https?:\/\/cdn\.uqni\.net\/images\/[0-9]+\/[a-zA-Z-]+\/chapter-[0-9]+\/[0-9]+\.jpg/g;
const html = await Func.fetchJson("https://kiryuu.org/mercenary-enrollment-chapter-205/")
const links = html.match(regex);
console.log(links);

const fs = require('fs');
const PDFDocument = require('pdfkit');
const regex = /https?:\/\/cdn\.uqni\.net\/images\/[0-9]+\/[a-zA-Z-]+\/chapter-[0-9]+\/[0-9]+\.jpg/g;
const html = await Func.fetchJson("https://kiryuu.org/mercenary-enrollment-chapter-205/")
const images = html.match(regex);
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
Promise.all(images.map((link, index) => {
return conn.getBuffer(link).then((buffer) => {
const imgWidth = 800;
const imgHeight = 8760;
const pageWidth = 800; // keep page width the same
const pageHeight = imgHeight + 100; // increase page height to accommodate image
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(buffer, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Image ${index + 1}`, 250, 550);
});
})).then(() => {
pdf.pipe(fs.createWriteStream('output.pdf'));
pdf.end();
console.log('PDF berhasil dibuat!');
});


const fs = require('fs');
const PDFDocument = require('pdfkit');
const imageSize = require('image-size');
const regex = /https?:\/\/cdn\.uqni\.net\/images\/[0-9]+\/[a-zA-Z-]+\/chapter-[0-9]+\/[0-9]+\.jpg/g;
const html = await Func.fetchJson("https://kiryuu.org/mercenary-enrollment-chapter-205/")
const images = html.match(regex);
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
Promise.all(images.map((link, index) => {
return conn.getBuffer(link).then((buffer) => {
const dimensions = imageSize(buffer); // get image dimensions
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth; // set page width to match image width
const pageHeight = imgHeight + 100; // add some extra space for margins
pdf.addPage({ size: [pageWidth, pageHeight] }); // add new page with dynamic size
pdf.image(buffer, 0, 0, { width: imgWidth, height: imgHeight }); // add image to new page
pdf.fontSize(24).text(`Image ${index + 1}`, 250, 550);
});
})).then(() => {
pdf.pipe(fs.createWriteStream('output.pdf'));
pdf.end();
console.log('PDF berhasil dibuat!');
});