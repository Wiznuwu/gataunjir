let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text.startsWith("https://www.mediafire.com/")) return m.reply("masukan link MediaFire yang valid");
  try {
  m.reply(wait)
    let link = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/mediafire?url=${text}&apikey=${global.apibeta}`);
    const ext = link.result.ext.toLowerCase()
    conn.sendMessage(m.chat, {
      document: { url: link.result.url }, fileName: link.result.filename,
      mimetype: `application/${ext}`
    }, { quoted: m });
  } catch (error) {
    console.error(error);
    m.reply("Error: Gagal mengunduh atau mendeteksi tipe file.");
  }
};

handler.help = ["mediafire"].map((a) => a + " *[link]*");
handler.tags = ["tools"];
handler.command = ["mediafire"];
handler.limit = true;
handler.register = true;
module.exports = handler;