const potion = 20000;
const Spotion = 100;
const Bdiamond = 100000;
const Sdiamond = 1000;
const Bcommon = 100000;
const Scommon = 1000;
const Suncommon = 100;
const Buncommon = 100000;
const Bmythic = 100000;
const Smythic = 1000;
const Blegendary = 200000;
const Slegendary = 5000;
const Bsampah = 120;
const Ssampah = 5;
const Bkayu = 1000;
const Skayu = 400;
const Bbotol = 300;
const Sbotol = 50;
const Bkaleng = 400;
const Skaleng = 100;
const Bkardus = 400;
const Skardus = 50;
const Bpisang = 5500;
const Spisang = 100;
const Bmangga = 4600;
const Smangga = 150;
const Bjeruk = 6000;
const Sjeruk = 300;
const Banggur = 5500;
const Sanggur = 150;
const Bapel = 5500;
const Sapel = 400;
const Bbibitpisang = 550;
const Sbibitpisang = 50;
const Bbibitmangga = 550;
const Sbibitmangga = 50;
const Bbibitjeruk = 550;
const Sbibitjeruk = 50;
const Bbibitanggur = 550;
const Sbibitanggur = 50;
const Bbibitapel = 550;
const Sbibitapel = 50;
const Bgardenboxs = 65000;
const Sgardenboc = 350000;
const Bberlian = 150000;
const Sberlian = 10000;
const Bemasbatang = 250000;
const Semasbatang = 10000;
const Bemasbiasa = 150000;
const Semasbiasa = 15000;
const Bphonix = 1000000000;
const Sphonix = 1000000;
const Bgriffin = 100000000;
const Sgriffin = 100000;
const Bkyubi = 100000000;
const Skyubi = 100000;
const Bnaga = 100000000;
const Snaga = 100000;
const Bcentaur = 100000000;
const Scentaur = 100000;
const Bkuda = 50000000;
const Skuda = 100000;
const Brubah = 100000000;
const Srubah = 100000;
const Bkucing = 5000000;
const Skucing = 50000;
const Bserigala = 50000000;
const Sserigala = 500000;
const Bmakananpet = 50000;
const Smakananpet = 500;
const Bmakananphonix = 80000;
const Smakananphonix = 5000;
const Bmakanangriffin = 80000;
const Smakanangriffin = 5000;
const Bmakanannaga = 150000;
const Smakanannaga = 10000;
const Bmakanankyubi = 150000;
const Smakanankyubi = 10000;
const Bmakanancentaur = 150000;
const Smakanancentaur = 10000;
const Bhealtmonster = 20000;
const Bpet = 150000;
const Spet = 1000;
const Blimit = 25000;
const Slimit = 20000;
const Bexp = 550;
const Baqua = 5000;
const Saqua = 1000;
const Biron = 20000;
const Siron = 5000;
const Bstring = 50000;
const Sstring = 5000;
const Bsword = 150000;
const Ssword = 15000;
const Bumpan = 1500;
const Sumpan = 100;
const Bpancingan = 5000000;
const Spancingan = 500000;
const BBensin = 20000;
const BWeap = 150000;
const SWeap = 15000;
const SBensin = 10000;
const Bbatu = 500;
const Sbatu = 100;
const Bketake = 15;
const Btiketcoin = 500;
const Bkoinexpg = 500000;
const BObat = 15000;
const ObatStock = 500;
const Beleksirb = 500;
const BnStock = 9999;
const WeapStock = 50;
let handler = async (m, { conn, command, args, usedPrefix, owner }) => {
  const _armor = global.db.data.users[m.sender].armor;
  const armor =
    _armor == 0
      ? 20000
      : "" || _armor == 1
        ? 49999
        : "" || _armor == 2
          ? 99999
          : "" || _armor == 3
            ? 149999
            : "" || _armor == 4
              ? 299999
              : "";
  let type = (args[0] || "").toLowerCase();
  let _type = (args[1] || "").toLowerCase();
  let jualbeli = (args[0] || "").toLowerCase();
  let nomors = m.sender;
  const Kchat = `
Penggunaan ${usedPrefix}shop <Buy|sell> <item> <jumlah>
Contoh penggunaan: *${usedPrefix}shop buy potion 1*

============================
*Kebutuhan   |  Harga Beli*
Limit:     ${Blimit}
TiketM:     ${Bhealtmonster}
Cupon:     ${Btiketcoin}
KoinExpg:     ${Bkoinexpg}

*Kebutuhan   |  Harga Jual*
Limit:     ${Slimit}
============================
*Bibit Buah   |  Harga Beli*
BibitPisang:       ${Bbibitpisang}
BibitAnggur:       ${Bbibitanggur}
BibitMangga:       ${Bbibitmangga}
BibitJeruk:       ${Bbibitjeruk}
BibitApel:       ${Bbibitapel}
Gardenboxs:     ${Bgardenboxs}
============================
*Barang   |  Harga Beli*
Potion:       ${potion}
Diamond:     ${Bdiamond}
Common:     ${Bcommon}
Uncommon:  ${Buncommon}
Mythic:     ${Bmythic}
Legendary: ${Blegendary}
Sampah:     ${Bsampah}
Armor:       ${armor}
String:       ${Bstring}
Iron:       ${Biron}
Sword:       ${Bsword}
Batu:       ${Bbatu}
Botol:       ${Bbotol}
Kaleng:       ${Bkaleng}
Kardus:       ${Bkardus}
Kayu:       ${Bkayu}
Berlian:       ${Bberlian}
Emas:       ${Bemasbiasa}
Bensin: ${BBensin} | Stock: ${BnStock}
Weapon: ${BWeap} | Stock: ${WeapStock}
Obat: ${BObat} | Stock: ${ObatStock}

*Barang   | Harga Jual*
Potion:       ${Spotion}
Diamond:     ${Sdiamond}
Common:     ${Scommon}
Uncommon:  ${Suncommon}
Mythic:     ${Smythic}
Legendary: ${Slegendary}
Sampah:     ${Ssampah}
String:       ${Sstring}
Iron:       ${Siron}
Sword:       ${Ssword}
Batu:       ${Sbatu}
Botol:       ${Sbotol}
Kaleng:       ${Skaleng}
Kardus:       ${Skardus}
Kayu:       ${Skayu}
Berlian:       ${Sberlian}
Emas:       ${Semasbiasa}
Bensin: ${SBensin} | Stock: ${BnStock}
Weapon: ${SWeap} | Stock: ${WeapStock}
============================
*List Makanan:*

*Makanan | Harga Beli*
Pisang:       ${Bpisang}
Anggur:       ${Banggur}
Mangga:       ${Bmangga}
Jeruk:       ${Bjeruk}
Apel:       ${Bapel}
MakananPet:       ${Bmakananpet}
MakananNaga:       ${Bmakanannaga}
MakananKyubi:       ${Bmakanankyubi}
MakananGriffin:       ${Bmakanangriffin}
MakananPhonix:       ${Bmakananphonix}
MakananCentaur:       ${Bmakanancentaur}

*Makanan | Harga Jual*
Pisang:       ${Spisang}
Anggur:       ${Sanggur}
Mangga:       ${Smangga}
Jeruk:       ${Sjeruk}
Apel:       ${Sapel}
MakananPet:       ${Smakananpet}
MakananNaga       ${Smakanannaga}
MakananKyubi:       ${Smakanankyubi}
MakananGriffin:       ${Smakanangriffin}
MakananPhonix:       ${Smakananphonix}
MakananCentaur:       ${Smakanancentaur}
============================
*Minuman | Harga Beli*
Aqua:       ${Baqua}

*Minuman | Harga Jual*
Aqua:       ${Saqua}
============================
*Fishing | Harga Beli*
Pancingan:       ${Bpancingan}
Umpan:       ${Bumpan}
`.trim();
  try {
    if (/shop|toko/i.test(command)) {
      const count =
        args[2] && args[2].length > 0
          ? Math.min(999999999999999, Math.max(parseInt(args[2]), 1))
          : !args[2] || args.length < 4
            ? 1
            : Math.min(1, count);
      const sampah = global.db.data.users[m.sender].sampah;
      switch (jualbeli) {
        case "buy":
        case "beli":
          switch (_type) {
            case "potion":
              if (global.db.data.users[m.sender].money >= potion * count) {
                global.db.data.users[m.sender].money -= potion * count;
                global.db.data.users[m.sender].potion += count * 1;
                m.reply(`Succes membeli ${count} Potion dengan harga ${potion * count} money\n\nGunakan potion dengan ketik: *${usedPrefix}use potion <jumlah>*`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Potion dengan harga ${potion * count} money`,
                );
              break;
            case "diamond":
              if (global.db.data.users[m.sender].money >= Bdiamond * count) {
                global.db.data.users[m.sender].diamond += count * 1;
                global.db.data.users[m.sender].money -= Bdiamond * count;
                m.reply(`Succes membeli ${count} Diamond dengan harga ${Bdiamond * count} money`)
              } else m.reply(`Money anda tidak cukup`);

              break;
            case "common":
              if (global.db.data.users[m.sender].money >= Bcommon * count) {
                global.db.data.users[m.sender].common += count * 1;
                global.db.data.users[m.sender].money -= Bcommon * count;
                m.reply(`Succes membeli ${count} Common crate dengan harga ${Bcommon * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Common crate dengan harga ${Bcommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open common*`)

              break;
            case "uncommon":
              if (global.db.data.users[m.sender].money >= Buncommon * count) {
                global.db.data.users[m.sender].uncommon += count * 1;
                global.db.data.users[m.sender].money -= Buncommon * count;
                m.reply(`Succes membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open uncommon*`)

              break;
            case "mythic":
              if (global.db.data.users[m.sender].money >= Bmythic * count) {
                global.db.data.users[m.sender].mythic += count * 1;
                global.db.data.users[m.sender].money -= Bmythic * count;
                m.reply(`Succes membeli ${count} Mythic crate dengan harga ${Bmythic * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Mythic crate dengan harga ${Bmythic * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open mythic*`)

              break;
            case "legendary":
              if (global.db.data.users[m.sender].money >= Blegendary * count) {
                global.db.data.users[m.sender].legendary += count * 1;
                global.db.data.users[m.sender].money -= Blegendary * count;
                m.reply(`Succes membeli ${count} Legendary crate dengan harga ${Blegendary * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Legendary crate dengan harga ${Blegendary * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open legendary*`)

              break;
            case "sampah":
              if (global.db.data.users[m.sender].money >= Bsampah * count) {
                global.db.data.users[m.sender].sampah += count * 1;
                global.db.data.users[m.sender].money -= Bsampah * count;
                m.reply(`Succes membeli ${count} Sampah dengan harga ${Bsampah * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Sampah dengan harga ${Bsampah * count} money`.trim())

              break;
            case "kaleng":
              if (global.db.data.users[m.sender].money >= Bkaleng * count) {
                global.db.data.users[m.sender].kaleng += count * 1;
                global.db.data.users[m.sender].money -= Bkaleng * count;
                m.reply(`Succes membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`.trim())

              break;
            case "kardus":
              if (global.db.data.users[m.sender].money >= Bkardus * count) {
                global.db.data.users[m.sender].kardus += count * 1;
                global.db.data.users[m.sender].money -= Bkardus * count;
                m.reply(`Succes membeli ${count} Kardus dengan harga ${Bkardus * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Kardus dengan harga ${Bkardus * count} money`.trim())

              break;
            case "botol":
              if (global.db.data.users[m.sender].money >= Bbotol * count) {
                global.db.data.users[m.sender].botol += count * 1;
                global.db.data.users[m.sender].money -= Bbotol * count;
                m.reply(`Succes membeli ${count} Botol dengan harga ${Bbotol * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} botol dengan harga ${Bbotol * count} money`.trim())

              break;
            case "kayu":
              if (global.db.data.users[m.sender].money >= Bkayu * count) {
                global.db.data.users[m.sender].kayu += count * 1;
                global.db.data.users[m.sender].money -= Bkayu * count;
                m.reply(`Succes membeli ${count} Kayu dengan harga ${Bkayu * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} kayu dengan harga ${Bkayu * count} money`.trim())

              break;
            case "pisang":
              if (global.db.data.users[m.sender].money >= Bpisang * count) {
                global.db.data.users[m.sender].pisang += count * 1;
                global.db.data.users[m.sender].money -= Bpisang * count;
                m.reply(`Succes membeli ${count} Pisang dengan harga ${Bpisang * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} pisang dengan harga ${Bpisang * count} money`.trim())

              break;
            case "anggur":
              if (global.db.data.users[m.sender].money >= Banggur * count) {
                global.db.data.users[m.sender].anggur += count * 1;
                global.db.data.users[m.sender].money -= Banggur * count;
                m.reply(`Succes membeli ${count} Anggur dengan harga ${Banggur * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} anggur dengan harga ${Banggur * count} money`.trim())

              break;
            case "mangga":
              if (global.db.data.users[m.sender].money >= Bmangga * count) {
                global.db.data.users[m.sender].mangga += count * 1;
                global.db.data.users[m.sender].money -= Bmangga * count;
                m.reply(`Succes membeli ${count} Mangga dengan harga ${Bmangga * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} mangga dengan harga ${Bmangga * count} money`.trim())

              break;
            case "jeruk":
              if (global.db.data.users[m.sender].money >= Bjeruk * count) {
                global.db.data.users[m.sender].jeruk += count * 1;
                global.db.data.users[m.sender].money -= Bjeruk * count;
                m.reply(`Succes membeli ${count} Jeruk dengan harga ${Bjeruk * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} jeruk dengan harga ${Bjeruk * count} money`.trim())

              break;
            case "apel":
              if (global.db.data.users[m.sender].money >= Bapel * count) {
                global.db.data.users[m.sender].apel += count * 1;
                global.db.data.users[m.sender].money -= Bapel * count;
                m.reply(`Succes membeli ${count} Apel dengan harga ${Bapel * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} apel dengan harga ${Bapel * count} money`.trim())

              break;
            case "bibitpisang":
              if (
                global.db.data.users[m.sender].money >=
                Bbibitpisang * count
              ) {
                global.db.data.users[m.sender].bibitpisang += count * 1;
                global.db.data.users[m.sender].money -= Bbibitpisang * count;
                m.reply(`Succes membeli ${count} Bibit Pisang dengan harga ${Bbibitpisang * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit pisang dengan harga ${Bbibitpisang * count} money`.trim())

              break;
            case "bibitanggur":
              if (
                global.db.data.users[m.sender].money >=
                Bbibitanggur * count
              ) {
                global.db.data.users[m.sender].bibitanggur += count * 1;
                global.db.data.users[m.sender].money -= Bbibitanggur * count;
                m.reply(`Succes membeli ${count} Bibit Anggur dengan harga ${Bbibitanggur * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit anggur dengan harga ${Bbibitanggur * count} money`.trim())

              break;
            case "bibitmangga":
              if (
                global.db.data.users[m.sender].money >=
                Bbibitmangga * count
              ) {
                global.db.data.users[m.sender].bibitmangga += count * 1;
                global.db.data.users[m.sender].money -= Bbibitmangga * count;
                m.reply(`Succes membeli ${count} Bibit Mangga dengan harga ${Bbibitmangga * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit mangga dengan harga ${Bbibitmangga * count} money`.trim())

              break;
            case "bibitjeruk":
              if (global.db.data.users[m.sender].money >= Bbibitjeruk * count) {
                global.db.data.users[m.sender].bibitjeruk += count * 1;
                global.db.data.users[m.sender].money -= Bbibitjeruk * count;
                m.reply(`Succes membeli ${count} Bibit Jeruk dengan harga ${Bbibitjeruk * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit jeruk dengan harga ${Bbibitjeruk * count} money`.trim())

              break;
            case "bibitapel":
              if (global.db.data.users[m.sender].money >= Bbibitapel * count) {
                global.db.data.users[m.sender].bibitapel += count * 1;
                global.db.data.users[m.sender].money -= Bbibitapel * count;
                m.reply(`Succes membeli ${count} Bibit Apel dengan harga ${Bbibitapel * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit apel dengan harga ${Bbibitapel * count} money`.trim())

              break;
            case "gardenboxs":
              if (global.db.data.users[m.sender].money >= Bgardenboxs * count) {
                global.db.data.users[m.sender].gardenboxs += count * 1;
                global.db.data.users[m.sender].money -= Bgardenboxs * count;
                m.reply(`Succes membeli ${count} Gardenboxs dengan harga ${Bgardenboxs * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} gardenboxs dengan harga ${Bgardenboxs * count} money`.trim())

              break;
            case "berlian":
              if (global.db.data.users[m.sender].money >= Bberlian * count) {
                global.db.data.users[m.sender].berlian += count * 1;
                global.db.data.users[m.sender].money -= Bberlian * count;
                m.reply(`Succes membeli ${count} Berlian dengan harga ${Bberlian * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} berlian dengan harga ${Bberlian * count} money`.trim())

              break;
            case "bensin":
              if (global.db.data.users[m.sender].money >= BBensin * count) {
                global.db.data.users[m.sender].bensin += count * 1;
                global.db.data.users[m.sender].money -= BBensin * count;
                m.reply(`Succes membeli ${count}L Bensin dengan harga ${BBensin * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Bensin dengan harga ${BBensin * count} money`.trim())

              break;
            case "weapon":
              if (global.db.data.users[m.sender].money >= BWeap * count) {
                global.db.data.users[m.sender].weapon += count * 1;
                global.db.data.users[m.sender].money -= BWeap * count;
                m.reply(`Succes membeli ${count} Weapon dengan harga ${BWeap * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} Weapon dengan harga ${BWeap * count} money`.trim())

              break;
            case "obat":
              if (global.db.data.users[m.sender].money >= BObat * count) {
                global.db.data.users[m.sender].obat += count * 1;
                global.db.data.users[m.sender].money -= BObat * count;
                m.reply(`Succes membeli ${count} kapsul Obat dengan harga ${BObat * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} kapsul Obat dengan harga ${BObat * count} money`.trim())

              break;

            case "emas":
              if (global.db.data.users[m.sender].money >= Bemasbiasa * count) {
                global.db.data.users[m.sender].emas += count * 1;
                global.db.data.users[m.sender].money -= Bemasbiasa * count;
                m.reply(`Succes membeli ${count} Emas dengan harga ${Bemasbiasa * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} emas dengan harga ${Bemasbiasa * count} money`.trim())

              break;
            case "pet":
              if (global.db.data.users[m.sender].money >= Bpet * count) {
                global.db.data.users[m.sender].pet += count * 1;
                global.db.data.users[m.sender].money -= Bpet * count;
                m.reply(`Succes membeli ${count} Pet Random dengan harga ${Bpet * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} pet random dengan harga ${Bpet * count} money`.trim())

              break;
            case "limit":
              if (global.db.data.users[m.sender].money >= Blimit * count) {
                global.db.data.users[m.sender].limit += count * 1;
                global.db.data.users[m.sender].money -= Blimit * count;
                m.reply(`Succes membeli ${count} Limit dengan harga ${Blimit * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} limit dengan harga ${Blimit * count} money`.trim())

              break;
            /*case 'exp':
                            if (global.db.data.users[m.sender].money >= Bexp * count) {
                                global.db.data.users[m.sender].exp += count * 1
                                global.db.data.users[m.sender].money -= Bexp * count
                                m.reply(`Succes membeli ${count} Exp dengan harga ${Bexp * count} money`, m)
                            } else m.reply(`Uang anda tidak cukup untuk membeli ${count} exp dengan harga ${Bexp * count} money`.trim(), m)
                        
                        break
                     case 'eleksirb':
                            if (global.db.data.users[m.sender].money >= Beleksirb * count) {
                                global.db.data.users[m.sender].eleksirb += count * 1
                                global.db.data.users[m.sender].money -= Beleksirb * count
                                m.reply(`Succes membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`, m)
                            } else m.reply(`Uang anda tidak cukup untuk membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`.trim(), m)
                        
                        break
                        case 'koinexpg':
                            if (global.db.data.users[m.sender].money >= Bkoinexpg * count) {
                                global.db.data.users[m.sender].koinexpg += count * 1
                                global.db.data.users[m.sender].money -= Bkoinexpg * count
                                m.reply(`Succes membeli ${count} Koinexpg dengan harga ${Bkoinexpg * count} money`, m)
                            } else m.reply(`Uang anda tidak cukup untuk membeli ${count} koinexpg dengan harga ${Bkoinexpg * count} money`.trim(), m)
                        
                        break*/
            case "cupon":
              if (
                global.db.data.users[m.sender].tiketcoin >=
                Btiketcoin * count
              ) {
                global.db.data.users[m.sender].cupon += count * 1;
                global.db.data.users[m.sender].tiketcoin -= Btiketcoin * count;
                m.reply(`Succes membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin`)
              } else
                m.reply(`Tiketcoin anda tidak cukup untuk membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin\n\nCara mendapatkan tiketcoin, anda harus memainkan semua fitur game..`.trim())

              break;
            case "makananpet":
              if (global.db.data.users[m.sender].money >= Bmakananpet * count) {
                global.db.data.users[m.sender].makananpet += count * 1;
                global.db.data.users[m.sender].money -= Bmakananpet * count;
                m.reply(`Succes membeli ${count} Makanan Pet dengan harga ${Bmakananpet * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakananpet * count} money`.trim())

              break;
            case "makanannaga":
              if (
                global.db.data.users[m.sender].money >=
                Bmakanannaga * count
              ) {
                global.db.data.users[m.sender].makanannaga += count * 1;
                global.db.data.users[m.sender].money -= Bmakanannaga * count;
                m.reply(`Succes membeli ${count} Makanan Naga dengan harga ${Bmakanannaga * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan naga dengan harga ${Bmakanannaga * count} money`.trim())

              break;
            case "makananphonix":
              if (
                global.db.data.users[m.sender].money >=
                Bmakananphonix * count
              ) {
                global.db.data.users[m.sender].makananphonix += count * 1;
                global.db.data.users[m.sender].money -= Bmakananphonix * count;
                m.reply(`Succes membeli ${count} Makanan Phonix dengan harga ${Bmakananphonix * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan phonix dengan harga ${Bmakananphonix * count} money`.trim())

              break;
            case "makanankyubi":
              if (
                global.db.data.users[m.sender].money >=
                Bmakanankyubi * count
              ) {
                global.db.data.users[m.sender].makanankyubi += count * 1;
                global.db.data.users[m.sender].money -= Bmakanankyubi * count;
                m.reply(`Succes membeli ${count} Makanan Kyubi dengan harga ${Bmakanankyubi * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan kyubi dengan harga ${Bmakanankyubi * count} money`.trim())

              break;
            case "makanangriffin":
              if (
                global.db.data.users[m.sender].money >=
                Bmakanangriffin * count
              ) {
                global.db.data.users[m.sender].makanangriffin += count * 1;
                global.db.data.users[m.sender].money -= Bmakanangriffin * count;
                m.reply(`Succes membeli ${count} Makanan Griffin dengan harga ${Bmakanangriffin * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan griffin dengan harga ${Bmakanangriffin * count} money`.trim())

              break;
            case "makanancentaur":
              if (
                global.db.data.users[m.sender].money >=
                Bmakanancentaur * count
              ) {
                global.db.data.users[m.sender].makanancentaur += count * 1;
                global.db.data.users[m.sender].money -= Bmakanancentaur * count;
                m.reply(`Succes membeli ${count} Makanan Centaur dengan harga ${Bmakanancentaur * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan centaur dengan harga ${Bmakanancentaur * count} money`.trim())

              break;
            case "tiketm":
              if (
                global.db.data.users[m.sender].money >=
                Bhealtmonster * count
              ) {
                global.db.data.users[m.sender].healtmonster += count * 1;
                global.db.data.users[m.sender].money -= Bhealtmonster * count;
                m.reply(`Succes membeli ${count} TiketM dengan harga ${Bhealtmonster * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} tiketm dengan harga ${Bhealtmonster * count} money`.trim())

              break;
            case "aqua":
              if (global.db.data.users[m.sender].money >= Baqua * count) {
                global.db.data.users[m.sender].aqua += count * 1;
                global.db.data.users[m.sender].money -= Baqua * count;
                m.reply(`Succes membeli ${count} Aqua dengan harga ${Baqua * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} aqua dengan harga ${Baqua * count} money`.trim())

              break;
            case "iron":
              if (global.db.data.users[m.sender].money >= Biron * count) {
                global.db.data.users[m.sender].iron += count * 1;
                global.db.data.users[m.sender].money -= Biron * count;
                m.reply(`Succes membeli ${count} Iron dengan harga ${Biron * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} iron dengan harga ${Biron * count} money`.trim())

              break;
            case "string":
              if (global.db.data.users[m.sender].money >= Bstring * count) {
                global.db.data.users[m.sender].string += count * 1;
                global.db.data.users[m.sender].money -= Bstring * count;
                m.reply(`Succes membeli ${count} String dengan harga ${Bstring * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} string dengan harga ${Bstring * count} money`.trim())

              break;
            case "sword":
              if (global.db.data.users[m.sender].money >= Bsword * count) {
                global.db.data.users[m.sender].sword += count * 1;
                global.db.data.users[m.sender].money -= Bsword * count;
                m.reply(`Succes membeli ${count} Sword dengan harga ${Bsword * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} sword dengan harga ${Bsword * count} money`.trim())

              break;
            case "batu":
              if (global.db.data.users[m.sender].money >= Bbatu * count) {
                global.db.data.users[m.sender].batu += count * 1;
                global.db.data.users[m.sender].money -= Bbatu * count;
                m.reply(`Succes membeli ${count} Batu dengan harga ${Bbatu * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} batu dengan harga ${Bbatu * count} money`.trim())

              break;
            case "umpan":
              if (global.db.data.users[m.sender].money >= Bumpan * count) {
                global.db.data.users[m.sender].umpan += count * 1;
                global.db.data.users[m.sender].money -= Bumpan * count;
                m.reply(`Succes membeli ${count} Umpan dengan harga ${Bumpan * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} umpan dengan harga ${Bumpan * count} money`.trim())

              break;
            case "pancingan":
              if (global.db.data.users[m.sender].money >= Bpancingan * count) {
                global.db.data.users[m.sender].pancingan += count * 1;
                global.db.data.users[m.sender].money -= Bpancingan * count;
                m.reply(`Succes membeli ${count} Pancingan dengan harga ${Bpancingan * count} money`)
              } else
                m.reply(`Uang anda tidak cukup untuk membeli ${count} pancingan dengan harga ${Bpancingan * count} money`.trim())

              break;
            case "armor":
              if (global.db.data.users[m.sender].armor == 5)
                return m.reply("Armormu sudah *Level Max*");
              if (global.db.data.users[m.sender].money > armor) {
                global.db.data.users[m.sender].armor += 1;
                global.db.data.users[m.sender].money -= armor * 1;
                m.reply(`Succes membeli armor seharga ${armor} money`)
              } else
                m.reply(`uang mu tidak cukup untuk membeli armor seharga ${armor} money`)

              break;
            default:
              return m.reply(Kchat);
          }
          break;
        case "sell":
        case "jual":
          switch (_type) {
            case "potion":
              if (global.db.data.users[m.sender].potion >= count * 1) {
                global.db.data.users[m.sender].money += Spotion * count;
                global.db.data.users[m.sender].potion -= count * 1;
                m.reply(`Succes menjual ${count} Potion dengan harga ${Spotion * count} money`.trim())
              } else m.reply(`Potion kamu tidak cukup`.trim());
              break;
            case "common":
              if (global.db.data.users[m.sender].common >= count * 1) {
                global.db.data.users[m.sender].money += Scommon * count;
                global.db.data.users[m.sender].common -= count * 1;
                m.reply(`Succes menjual ${count} Common Crate dengan harga ${Scommon * count} money`.trim())
              } else
                m.reply(`Common Crate kamu tidak cukup`.trim());
              break;
            case "uncommon":
              if (global.db.data.users[m.sender].uncommon >= count * 1) {
                global.db.data.users[m.sender].money += Suncommon * count;
                global.db.data.users[m.sender].uncommon -= count * 1;
                m.reply(`Succes menjual ${count} Uncommon Crate dengan harga ${Suncommon * count} money`.trim())
              } else
                m.reply(`Uncommon Crate kamu tidak cukup`.trim());
              break;
            case "mythic":
              if (global.db.data.users[m.sender].mythic >= count * 1) {
                global.db.data.users[m.sender].money += Smythic * count;
                global.db.data.users[m.sender].mythic -= count * 1;
                m.reply(`Succes menjual ${count} Mythic Crate dengan harga ${Smythic * count} money`.trim())
              } else
                m.reply(`Mythic Crate kamu tidak cukup`.trim());
              break;
            case "legendary":
              if (global.db.data.users[m.sender].legendary >= count * 1) {
                global.db.data.users[m.sender].money += Slegendary * count;
                global.db.data.users[m.sender].legendary -= count * 1;
                m.reply(`Succes menjual ${count} Legendary Crate dengan harga ${Slegendary * count} money`.trim())
              } else
                m.reply(`Legendary Crate kamu tidak cukup`.trim())
              break;
            case "sampah":
              if (global.db.data.users[m.sender].sampah >= count * 1) {
                global.db.data.users[m.sender].sampah -= count * 1;
                global.db.data.users[m.sender].money += Ssampah * count;
                m.reply(`Succes menjual ${count} sampah, dan anda mendapatkan ${Ssampah * count} money`)
              } else m.reply(`Sampah anda tidak cukup`);
              break;
            case "kaleng":
              if (global.db.data.users[m.sender].kaleng >= count * 1) {
                global.db.data.users[m.sender].kaleng -= count * 1;
                global.db.data.users[m.sender].money += Skaleng * count;
                m.reply(`Succes menjual ${count} kaleng, dan anda mendapatkan ${Skaleng * count} money`)
              } else m.reply(`Kaleng anda tidak cukup`);
              break;
            case "kardus":
              if (global.db.data.users[m.sender].kardus >= count * 1) {
                global.db.data.users[m.sender].kardus -= count * 1;
                global.db.data.users[m.sender].money += Skardus * count;
                m.reply(`Succes menjual ${count} kardus, dan anda mendapatkan ${Skardus * count} money`)
              } else m.reply(`Kardus anda tidak cukup`);
              break;
            case "botol":
              if (global.db.data.users[m.sender].botol >= count * 1) {
                global.db.data.users[m.sender].botol -= count * 1;
                global.db.data.users[m.sender].money += Sbotol * count;
                m.reply(`Succes menjual ${count} botol, dan anda mendapatkan ${Sbotol * count} money`)
              } else m.reply(`Botol anda tidak cukup`);
              break;
            case "kayu":
              if (global.db.data.users[m.sender].kayu >= count * 1) {
                global.db.data.users[m.sender].kayu -= count * 1;
                global.db.data.users[m.sender].money += Skayu * count;
                m.reply(`Succes menjual ${count} kayu, dan anda mendapatkan ${Skayu * count} money`)
              } else m.reply(`Kayu anda tidak cukup`);
              break;
            case "pisang":
              if (global.db.data.users[m.sender].pisang >= count * 1) {
                global.db.data.users[m.sender].pisang -= count * 1;
                global.db.data.users[m.sender].money += Spisang * count;
                m.reply(`Succes menjual ${count} pisang, dan anda mendapatkan ${Spisang * count} money`)
              } else m.reply(`Pisang anda tidak cukup`);
              break;
            case "anggur":
              if (global.db.data.users[m.sender].anggur >= count * 1) {
                global.db.data.users[m.sender].anggur -= count * 1;
                global.db.data.users[m.sender].money += Sanggur * count;
                m.reply(`Succes menjual ${count} anggur, dan anda mendapatkan ${Sanggur * count} money`)
              } else m.reply(`Anggur anda tidak cukup`);
              break;
            case "mangga":
              if (global.db.data.users[m.sender].mangga >= count * 1) {
                global.db.data.users[m.sender].mangga -= count * 1;
                global.db.data.users[m.sender].money += Smangga * count;
                m.reply(`Succes menjual ${count} mangga, dan anda mendapatkan ${Smangga * count} money`)
              } else m.reply(`Mangga anda tidak cukup`);
              break;
            case "jeruk":
              if (global.db.data.users[m.sender].jeruk >= count * 1) {
                global.db.data.users[m.sender].jeruk -= count * 1;
                global.db.data.users[m.sender].money += Sjeruk * count;
                m.reply(`Succes menjual ${count} jeruk, dan anda mendapatkan ${Sjeruk * count} money`)
              } else m.reply(`Jeruk anda tidak cukup`);
              break;
            case "apel":
              if (global.db.data.users[m.sender].apel >= count * 1) {
                global.db.data.users[m.sender].apel -= count * 1;
                global.db.data.users[m.sender].money += Sapel * count;
                m.reply(`Succes menjual ${count} apel, dan anda mendapatkan ${Sapel * count} money`)
              } else m.reply(`Apel anda tidak cukup`);
              break;
            case "berlian":
              if (global.db.data.users[m.sender].berlian >= count * 1) {
                global.db.data.users[m.sender].berlian -= count * 1;
                global.db.data.users[m.sender].money += Sberlian * count;
                m.reply(`Succes menjual ${count} berlian, dan anda mendapatkan ${Sberlian * count} money`)
              } else m.reply(`Berlian anda tidak cukup`);
              break;
            case "emas":
              if (global.db.data.users[m.sender].emas >= count * 1) {
                global.db.data.users[m.sender].emas -= count * 1;
                global.db.data.users[m.sender].money += Semasbiasa * count;
                m.reply(`Succes menjual ${count} emas , dan anda mendapatkan ${Semasbiasa * count} money`)
              } else m.reply(`Emas anda tidak cukup`);
              break;
            case "bensin":
              if (global.db.data.users[m.sender].bensin >= count * 1) {
                global.db.data.users[m.sender].bensin -= count * 1;
                global.db.data.users[m.sender].money += SBensin * count;
                m.reply(`Succes menjual ${count} bensin , dan anda mendapatkan ${SBensin * count} money`)
              } else m.reply(`Bensin anda tidak cukup`);
              break;
            case "weapon":
              if (global.db.data.users[m.sender].weapon >= count * 1) {
                global.db.data.users[m.sender].weapon -= count * 1;
                global.db.data.users[m.sender].money += SWeap * count;
                m.reply(`Succes menjual ${count} Weapon , dan anda mendapatkan ${SWeap * count} money`)
              } else m.reply(`Weapon anda tidak cukup`);
              break;
            case "pet":
              if (global.db.data.users[m.sender].pet >= count * 1) {
                global.db.data.users[m.sender].pet -= count * 1;
                global.db.data.users[m.sender].money += Spet * count;
                m.reply(`Succes menjual ${count} pet random, dan anda mendapatkan ${Spet * count} money`)
              } else m.reply(`Pet Random anda tidak cukup`);
              break;
            case "makananpet":
              if (global.db.data.users[m.sender].makananpet >= count * 1) {
                global.db.data.users[m.sender].makananpet -= count * 1;
                global.db.data.users[m.sender].money += Smakananpet * count;
                m.reply(`Succes menjual ${count} makanan pet, dan anda mendapatkan ${Smakananpet * count} money`)
              } else m.reply(`Makanan pet anda tidak cukup`);
              break;
            case "makananphonix":
              if (global.db.data.users[m.sender].makananphonix >= count * 1) {
                global.db.data.users[m.sender].makananphonix -= count * 1;
                global.db.data.users[m.sender].money += Smakananphonix * count;
                m.reply(`Succes menjual ${count} makanan phonix, dan anda mendapatkan ${Smakananphonix * count} money`)
              } else m.reply(`Makanan phonix anda tidak cukup`);
              break;
            case "makanannaga":
              if (global.db.data.users[m.sender].makanannaga >= count * 1) {
                global.db.data.users[m.sender].makanannaga -= count * 1;
                global.db.data.users[m.sender].money += Smakanannaga * count;
                m.reply(`Succes menjual ${count} makanan naga, dan anda mendapatkan ${Smakanannaga * count} money`)
              } else m.reply(`Makanan naga anda tidak cukup`);
              break;
            case "makanankyubi":
              if (global.db.data.users[m.sender].makanankyuni >= count * 1) {
                global.db.data.users[m.sender].makanankyubi -= count * 1;
                global.db.data.users[m.sender].money += Smakanankyubi * count;
                m.reply(`Succes menjual ${count} makanan kyubi, dan anda mendapatkan ${Smakanankyubi * count} money`)
              } else m.reply(`Makanan kyubi anda tidak cukup`);
              break;
            case "makanangriffin":
              if (global.db.data.users[m.sender].makanangriffin >= count * 1) {
                global.db.data.users[m.sender].makanangriffin -= count * 1;
                global.db.data.users[m.sender].money += Smakanangriffin * count;
                m.reply(`Succes menjual ${count} makanan griffin, dan anda mendapatkan ${Smakanangriffin * count} money`)
              } else m.reply(`Makanan griffin anda tidak cukup`);
              break;
            case "makanancentaur":
              if (global.db.data.users[m.sender].makanancentaur >= count * 1) {
                global.db.data.users[m.sender].makanancentaur -= count * 1;
                global.db.data.users[m.sender].money += Smakanancentaur * count;
                m.reply(`Succes menjual ${count} makanan centaur, dan anda mendapatkan ${Smakanancentaur * count} money`)
              } else m.reply(`Makanan centaur anda tidak cukup`);
              break;
            case "aqua":
              if (global.db.data.users[m.sender].aqua >= count * 1) {
                global.db.data.users[m.sender].aqua -= count * 1;
                global.db.data.users[m.sender].money += Saqua * count;
                m.reply(`Succes menjual ${count} aqua, dan anda mendapatkan ${Saqua * count} money`)
              } else m.reply(`Aqua anda tidak cukup`);
              break;
            case "pancingan":
              if (global.db.data.users[m.sender].pancingan >= count * 1) {
                global.db.data.users[m.sender].pancingan -= count * 1;
                global.db.data.users[m.sender].money += Spancingan * count;
                m.reply(`Succes menjual ${count} pancingan, dan anda mendapatkan ${Spancingan * count} money`)
              } else m.reply(`Pancingan anda tidak cukup`);
              break;
            case "iron":
              if (global.db.data.users[m.sender].iron >= count * 1) {
                global.db.data.users[m.sender].iron -= count * 1;
                global.db.data.users[m.sender].money += Siron * count;
                m.reply(`Succes menjual ${count} pancingan, dan anda mendapatkan ${Siron * count} money`)
              } else m.reply(`Iron anda tidak cukup`);
              break;
            case "string":
              if (global.db.data.users[m.sender].string >= count * 1) {
                global.db.data.users[m.sender].string -= count * 1;
                global.db.data.users[m.sender].money += Sstring * count;
                m.reply(`Succes menjual ${count} string, dan anda mendapatkan ${Sstring * count} money`)
              } else m.reply(`String anda tidak cukup`);
              break;
            case "sword":
              if (global.db.data.users[m.sender].sword >= count * 1) {
                global.db.data.users[m.sender].sword -= count * 1;
                global.db.data.users[m.sender].money += Ssword * count;
                m.reply(`Succes menjual ${count} sword, dan anda mendapatkan ${Ssword * count} money`)
              } else m.reply(`Sword anda tidak cukup`);
              break;
            case "batu":
              if (global.db.data.users[m.sender].batu >= count * 1) {
                global.db.data.users[m.sender].batu -= count * 1;
                global.db.data.users[m.sender].money += Sbatu * count;
                m.reply(`Succes menjual ${count} batu, dan anda mendapatkan ${Sbatu * count} money`)
              } else m.reply(`Batu anda tidak cukup`);
              break;
            case "limit":
              if (global.db.data.users[m.sender].limit >= count * 1) {
                global.db.data.users[m.sender].limit -= count * 1;
                global.db.data.users[m.sender].money += Slimit * count;
                m.reply(`Succes menjual ${count} limit, dan anda mendapatkan ${Slimit * count} money`)
              } else m.reply(`Limit anda tidak cukup`);
              break;
            case "diamond":
              if (global.db.data.users[m.sender].diamond >= count * 1) {
                global.db.data.users[m.sender].diamond -= count * 1;
                global.db.data.users[m.sender].money += Sdiamond * count;
                m.reply(`Succes menjual ${count} Diamond, dan anda mendapatkan ${Sdiamond * count} money`)
              } else m.reply(`Diamond anda tidak cukup`);
              break;
            default:
              return m.reply(Kchat);
          }
          break;
        default:
          return m.reply(Kchat);
      }
    } else if (/beli|buy/i.test(command)) {
      const count =
        args[1] && args[1].length > 0
          ? Math.min(999999999999999, Math.max(parseInt(args[1]), 1))
          : !args[1] || args.length < 3
            ? 1
            : Math.min(1, count);
      switch (type) {
        case "potion":
          if (global.db.data.users[m.sender].money >= potion * count) {
            global.db.data.users[m.sender].money -= potion * count;
            global.db.data.users[m.sender].potion += count * 1;
            m.reply(`Succes membeli ${count} Potion dengan harga ${potion * count} money\n\nGunakan potion dengan ketik: *${usedPrefix}use potion <jumlah>*`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Potion dengan harga ${potion * count} money`)

          break;
        case "diamond":
          if (global.db.data.users[m.sender].money >= Bdiamond * count) {
            global.db.data.users[m.sender].diamond += count * 1;
            global.db.data.users[m.sender].money -= Bdiamond * count;
            m.reply(`Succes membeli ${count} Diamond dengan harga ${Bdiamond * count} money`)
          } else m.reply(`Money anda tidak cukup`);

          break;
        case "common":
          if (global.db.data.users[m.sender].money >= Bcommon * count) {
            global.db.data.users[m.sender].common += count * 1;
            global.db.data.users[m.sender].money -= Bcommon * count;
            m.reply(`Succes membeli ${count} Common crate dengan harga ${Bcommon * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Common crate dengan harga ${Bcommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open common*`)

          break;
        case "uncommon":
          if (global.db.data.users[m.sender].money >= Buncommon * count) {
            global.db.data.users[m.sender].uncommon += count * 1;
            global.db.data.users[m.sender].money -= Buncommon * count;
            m.reply(`Succes membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Uncommon crate dengan harga ${Buncommon * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open uncommon*`)

          break;
        case "mythic":
          if (global.db.data.users[m.sender].money >= Bmythic * count) {
            global.db.data.users[m.sender].mythic += count * 1;
            global.db.data.users[m.sender].money -= Bmythic * count;
            m.reply(`Succes membeli ${count} Mythic crate dengan harga ${Bmythic * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Mythic crate dengan harga ${Bmythic * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open mythic*`)

          break;
        case "legendary":
          if (global.db.data.users[m.sender].money >= Blegendary * count) {
            global.db.data.users[m.sender].legendary += count * 1;
            global.db.data.users[m.sender].money -= Blegendary * count;
            m.reply(`Succes membeli ${count} Legendary crate dengan harga ${Blegendary * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Legendary crate dengan harga ${Blegendary * count} money\n\nBuka crate dengan ketik: *${usedPrefix}open legendary*`)

          break;
        case "sampah":
          if (global.db.data.users[m.sender].money >= Bsampah * count) {
            global.db.data.users[m.sender].sampah += count * 1;
            global.db.data.users[m.sender].money -= Bsampah * count;
            m.reply(`Succes membeli ${count} Sampah dengan harga ${Bsampah * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Sampah dengan harga ${Bsampah * count} money`.trim())

          break;
        case "kaleng":
          if (global.db.data.users[m.sender].money >= Bkaleng * count) {
            global.db.data.users[m.sender].kaleng += count * 1;
            global.db.data.users[m.sender].money -= Bkaleng * count;
            m.reply(`Succes membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Kaleng dengan harga ${Bkaleng * count} money`.trim())

          break;
        case "kardus":
          if (global.db.data.users[m.sender].money >= Bkardus * count) {
            global.db.data.users[m.sender].kardus += count * 1;
            global.db.data.users[m.sender].money -= Bkardus * count;
            m.reply(`Succes membeli ${count} Kardus dengan harga ${Bkardus * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} Kardus dengan harga ${Bkardus * count} money`.trim())

          break;
        case "botol":
          if (global.db.data.users[m.sender].money >= Bbotol * count) {
            global.db.data.users[m.sender].botol += count * 1;
            global.db.data.users[m.sender].money -= Bbotol * count;
            m.reply(`Succes membeli ${count} Botol dengan harga ${Bbotol * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} botol dengan harga ${Bbotol * count} money`.trim())

          break;
        case "kayu":
          if (global.db.data.users[m.sender].money >= Bkayu * count) {
            global.db.data.users[m.sender].kayu += count * 1;
            global.db.data.users[m.sender].money -= Bkayu * count;
            m.reply(`Succes membeli ${count} Kayu dengan harga ${Bkayu * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} kayu dengan harga ${Bkayu * count} money`.trim())

          break;
        case "pisang":
          if (global.db.data.users[m.sender].money >= Bpisang * count) {
            global.db.data.users[m.sender].pisang += count * 1;
            global.db.data.users[m.sender].money -= Bpisang * count;
            m.reply(`Succes membeli ${count} Pisang dengan harga ${Bpisang * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} pisang dengan harga ${Bpisang * count} money`.trim())

          break;
        case "anggur":
          if (global.db.data.users[m.sender].money >= Banggur * count) {
            global.db.data.users[m.sender].anggur += count * 1;
            global.db.data.users[m.sender].money -= Banggur * count;
            m.reply(`Succes membeli ${count} Anggur dengan harga ${Banggur * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} anggur dengan harga ${Banggur * count} money`.trim())

          break;
        case "mangga":
          if (global.db.data.users[m.sender].money >= Bmangga * count) {
            global.db.data.users[m.sender].mangga += count * 1;
            global.db.data.users[m.sender].money -= Bmangga * count;
            m.reply(`Succes membeli ${count} Mangga dengan harga ${Bmangga * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} mangga dengan harga ${Bmangga * count} money`.trim())

          break;
        case "jeruk":
          if (global.db.data.users[m.sender].money >= Bjeruk * count) {
            global.db.data.users[m.sender].jeruk += count * 1;
            global.db.data.users[m.sender].money -= Bjeruk * count;
            m.reply(`Succes membeli ${count} Jeruk dengan harga ${Bjeruk * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} jeruk dengan harga ${Bjeruk * count} money`.trim())

          break;
        case "apel":
          if (global.db.data.users[m.sender].money >= Bapel * count) {
            global.db.data.users[m.sender].apel += count * 1;
            global.db.data.users[m.sender].money -= Bapel * count;
            m.reply(`Succes membeli ${count} Apel dengan harga ${Bapel * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} apel dengan harga ${Bapel * count} money`.trim())

          break;
        case "bibitpisang":
          if (global.db.data.users[m.sender].money >= Bbibitpisang * count) {
            global.db.data.users[m.sender].bibitpisang += count * 1;
            global.db.data.users[m.sender].money -= Bbibitpisang * count;
            m.reply(`Succes membeli ${count} Bibit Pisang dengan harga ${Bbibitpisang * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit pisang dengan harga ${Bbibitpisang * count} money`.trim())

          break;
        case "bibitanggur":
          if (global.db.data.users[m.sender].money >= Bbibitanggur * count) {
            global.db.data.users[m.sender].bibitanggur += count * 1;
            global.db.data.users[m.sender].money -= Bbibitanggur * count;
            m.reply(`Succes membeli ${count} Bibit Anggur dengan harga ${Bbibitanggur * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit anggur dengan harga ${Bbibitanggur * count} money`.trim())

          break;
        case "bibitmangga":
          if (global.db.data.users[m.sender].money >= Bbibitmangga * count) {
            global.db.data.users[m.sender].bibitmangga += count * 1;
            global.db.data.users[m.sender].money -= Bbibitmangga * count;
            m.reply(`Succes membeli ${count} Bibit Mangga dengan harga ${Bbibitmangga * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit mangga dengan harga ${Bbibitmangga * count} money`.trim())

          break;
        case "bibitjeruk":
          if (global.db.data.users[m.sender].money >= Bbibitjeruk * count) {
            global.db.data.users[m.sender].bibitjeruk += count * 1;
            global.db.data.users[m.sender].money -= Bbibitjeruk * count;
            m.reply(`Succes membeli ${count} Bibit Jeruk dengan harga ${Bbibitjeruk * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit jeruk dengan harga ${Bbibitjeruk * count} money`.trim())

          break;
        case "bibitapel":
          if (global.db.data.users[m.sender].money >= Bbibitapel * count) {
            global.db.data.users[m.sender].bibitapel += count * 1;
            global.db.data.users[m.sender].money -= Bbibitapel * count;
            m.reply(`Succes membeli ${count} Bibit Apel dengan harga ${Bbibitapel * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} bibit apel dengan harga ${Bbibitapel * count} money`.trim())

          break;
        case "gardenboxs":
          if (global.db.data.users[m.sender].money >= Bgardenboxs * count) {
            global.db.data.users[m.sender].gardenboxs += count * 1;
            global.db.data.users[m.sender].money -= Bgardenboxs * count;
            m.reply(`Succes membeli ${count} Gardenboxs dengan harga ${Bgardenboxs * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} gardenboxs dengan harga ${Bgardenboxs * count} money`.trim())

          break;
        case "berlian":
          if (global.db.data.users[m.sender].money >= Bberlian * count) {
            global.db.data.users[m.sender].berlian += count * 1;
            global.db.data.users[m.sender].money -= Bberlian * count;
            m.reply(`Succes membeli ${count} Apel dengan harga ${Bberlian * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} berlian dengan harga ${Bberlian * count} money`.trim())

          break;
        case "emas":
          if (global.db.data.users[m.sender].money >= Bemasbiasa * count) {
            global.db.data.users[m.sender].emas += count * 1;
            global.db.data.users[m.sender].money -= Bemasbiasa * count;
            m.reply(`Succes membeli ${count} Emas dengan harga ${Bemasbiasa * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} emas dengan harga ${Bemasbiasa * count} money`.trim())

          break;
        case "pet":
          if (global.db.data.users[m.sender].money >= Bpet * count) {
            global.db.data.users[m.sender].pet += count * 1;
            global.db.data.users[m.sender].money -= Bpet * count;
            m.reply(`Succes membeli ${count} Pet Random dengan harga ${Bpet * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} pet random dengan harga ${Bpet * count} money`.trim())

          break;
        case "limit":
          if (global.db.data.users[m.sender].money >= Blimit * count) {
            global.db.data.users[m.sender].limit += count * 1;
            global.db.data.users[m.sender].money -= Blimit * count;
            m.reply(`Succes membeli ${count} Limit dengan harga ${Blimit * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} limit dengan harga ${Blimit * count} money`.trim())

          break;
        /*case 'exp':
                            if (global.db.data.users[m.sender].money >= Bexp * count) {
                                global.db.data.users[m.sender].exp += count * 1
                                global.db.data.users[m.sender].money -= Bexp * count
                                m.reply(`Succes membeli ${count} Exp dengan harga ${Bexp * count} money`, m)
                            } else m.reply(`Uang anda tidak cukup untuk membeli ${count} exp dengan harga ${Bexp * count} money`.trim(), m)
                        
                        break
                     case 'eleksirb':
                            if (global.db.data.users[m.sender].money >= Beleksirb * count) {
                                global.db.data.users[m.sender].eleksirb += count * 1
                                global.db.data.users[m.sender].money -= Beleksirb * count
                                m.reply(`Succes membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`, m)
                            } else m.reply(`Uang anda tidak cukup untuk membeli ${count} Eleksir Biru dengan harga ${Beleksirb * count} money`.trim(), m)
                        
                        break
                        case 'koinexpg':
                            if (global.db.data.users[m.sender].money >= Bkoinexpg * count) {
                                global.db.data.users[m.sender].koinexpg += count * 1
                                global.db.data.users[m.sender].money -= Bkoinexpg * count
                                m.reply(`Succes membeli ${count} Koinexpg dengan harga ${Bkoinexpg * count} money`, m)
                            } else m.reply(`Uang anda tidak cukup untuk membeli ${count} koinexpg dengan harga ${Bkoinexpg * count} money`.trim(), m)
                        
                        break*/
        case "cupon":
          if (global.db.data.users[m.sender].tiketcoin >= Btiketcoin * count) {
            global.db.data.users[m.sender].cupon += count * 1;
            global.db.data.users[m.sender].tiketcoin -= Btiketcoin * count;
            m.reply(`Succes membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin`)
          } else
            m.reply(`Tiketcoin anda tidak cukup untuk membeli ${count} cupon dengan harga ${Btiketcoin * count} Tiketcoin\n\nCara mendapatkan tiketcoin, anda harus memainkan semua fitur game..`.trim())

          break;
        case "makananpet":
          if (global.db.data.users[m.sender].money >= Bmakananpet * count) {
            global.db.data.users[m.sender].makananpet += count * 1;
            global.db.data.users[m.sender].money -= Bmakananpet * count;
            m.reply(`Succes membeli ${count} Makanan Pet dengan harga ${Bmakananpet * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakananpet * count} money`.trim())

          break;
        case "makanannaga":
          if (global.db.data.users[m.sender].money >= Bmakanannaga * count) {
            global.db.data.users[m.sender].makanannaga += count * 1;
            global.db.data.users[m.sender].money -= Bmakanannaga * count;
            m.reply(`Succes membeli ${count} Makanan Naga dengan harga ${Bmakanannaga * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakanannaga * count} money`.trim())

          break;
        case "makananphonix":
          if (global.db.data.users[m.sender].money >= Bmakananphonix * count) {
            global.db.data.users[m.sender].makananphonix += count * 1;
            global.db.data.users[m.sender].money -= Bmakananphonix * count;
            m.reply(`Succes membeli ${count} Makanan Phonix dengan harga ${Bmakananphonix * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan pet dengan harga ${Bmakananphonix * count} money`.trim())

          break;
        case "makanankyubi":
          if (global.db.data.users[m.sender].money >= Bmakanankyubi * count) {
            global.db.data.users[m.sender].makanankyubi += count * 1;
            global.db.data.users[m.sender].money -= Bmakanankyubi * count;
            m.reply(`Succes membeli ${count} Makanan Kyubi dengan harga ${Bmakanankyubi * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan kyubi dengan harga ${Bmakanankyubi * count} money`.trim())

          break;
        case "makanangriffin":
          if (global.db.data.users[m.sender].money >= Bmakanangriffin * count) {
            global.db.data.users[m.sender].makanangriffin += count * 1;
            global.db.data.users[m.sender].money -= Bmakanangriffin * count;
            m.reply(`Succes membeli ${count} Makanan Griffin dengan harga ${Bmakanangriffin * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan griffin dengan harga ${Bmakanangriffin * count} money`.trim())

          break;
        case "makanancentaur":
          if (global.db.data.users[m.sender].money >= Bmakanancentaur * count) {
            global.db.data.users[m.sender].makanancentaur += count * 1;
            global.db.data.users[m.sender].money -= Bmakanancentaur * count;
            m.reply(`Succes membeli ${count} Makanan Centaur dengan harga ${Bmakanancentaur * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} makanan centaur dengan harga ${Bmakanancentaur * count} money`.trim())

          break;
        case "tiketm":
          if (global.db.data.users[m.sender].money >= Bhealtmonster * count) {
            global.db.data.users[m.sender].healtmonster += count * 1;
            global.db.data.users[m.sender].money -= Bhealtmonster * count;
            m.reply(`Succes membeli ${count} TiketM dengan harga ${Bhealtmonster * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} tiketm dengan harga ${Bhealtmonster * count} money`.trim())

          break;
        case "aqua":
          if (global.db.data.users[m.sender].money >= Baqua * count) {
            global.db.data.users[m.sender].aqua += count * 1;
            global.db.data.users[m.sender].money -= Baqua * count;
            m.reply(`Succes membeli ${count} Aqua dengan harga ${Baqua * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} aqua dengan harga ${Baqua * count} money`.trim())

          break;
        case "iron":
          if (global.db.data.users[m.sender].money >= Biron * count) {
            global.db.data.users[m.sender].iron += count * 1;
            global.db.data.users[m.sender].money -= Biron * count;
            m.reply(`Succes membeli ${count} Iron dengan harga ${Biron * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} iron dengan harga ${Biron * count} money`.trim())

          break;
        case "string":
          if (global.db.data.users[m.sender].money >= Bstring * count) {
            global.db.data.users[m.sender].string += count * 1;
            global.db.data.users[m.sender].money -= Bstring * count;
            m.reply(`Succes membeli ${count} String dengan harga ${Bstring * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} string dengan harga ${Bstring * count} money`.trim())

          break;
        case "sword":
          if (global.db.data.users[m.sender].money >= Bsword * count) {
            global.db.data.users[m.sender].sword += count * 1;
            global.db.data.users[m.sender].money -= Bsword * count;
            m.reply(`Succes membeli ${count} Sword dengan harga ${Bsword * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} sword dengan harga ${Bsword * count} money`.trim())

          break;
        case "batu":
          if (global.db.data.users[m.sender].money >= Bbatu * count) {
            global.db.data.users[m.sender].batu += count * 1;
            global.db.data.users[m.sender].money -= Bbatu * count;
            m.reply(`Succes membeli ${count} Batu dengan harga ${Bbatu * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} batu dengan harga ${Bbatu * count} money`.trim())

          break;
        case "umpan":
          if (global.db.data.users[m.sender].money >= Bumpan * count) {
            global.db.data.users[m.sender].umpan += count * 1;
            global.db.data.users[m.sender].money -= Bumpan * count;
            m.reply(`Succes membeli ${count} Umpan dengan harga ${Bumpan * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} umpan dengan harga ${Bumpan * count} money`.trim())

          break;
        case "pancingan":
          if (global.db.data.users[m.sender].money >= Bpancingan * count) {
            global.db.data.users[m.sender].pancingan += count * 1;
            global.db.data.users[m.sender].money -= Bpancingan * count;
            m.reply(`Succes membeli ${count} Pancingan dengan harga ${Bpancingan * count} money`)
          } else
            m.reply(`Uang anda tidak cukup untuk membeli ${count} pancingan dengan harga ${Bpancingan * count} money`.trim())

          break;
        case "armor":
          if (global.db.data.users[m.sender].armor == 5)
            return m.reply("Armormu sudah *Level Max*");
          if (global.db.data.users[m.sender].money > armor * 1) {
            global.db.data.users[m.sender].armor += 1;
            global.db.data.users[m.sender].money -= armor * 1;
            m.reply(`Succes membeli armor seharga ${armor} money`)
          } else
            m.reply(`uang mu tidak cukup untuk membeli armor seharga ${armor} money`)

          break;
        default:
          return m.reply(Kchat);
      }
    } else if (/sell|jual|/i.test(command)) {
      const count =
        args[1] && args[1].length > 0
          ? Math.min(999999999999999, Math.max(parseInt(args[1]), 1))
          : !args[1] || args.length < 3
            ? 1
            : Math.min(1, count);
      switch (type) {
        case "potion":
          if (global.db.data.users[m.sender].potion >= count * 1) {
            global.db.data.users[m.sender].money += Spotion * count;
            global.db.data.users[m.sender].potion -= count * 1;
            m.reply(`Succes menjual ${count} Potion dengan harga ${Spotion * count} money`.trim())
          } else m.reply(`Potion kamu tidak cukup`.trim());
          break;
        case "common":
          if (global.db.data.users[m.sender].common >= count * 1) {
            global.db.data.users[m.sender].money += Scommon * count;
            global.db.data.users[m.sender].common -= count * 1;
            m.reply(`Succes menjual ${count} Common Crate dengan harga ${Scommon * count} money`.trim())
          } else m.reply(`Common Crate kamu tidak cukup`.trim());
          break;
        case "uncommon":
          if (global.db.data.users[m.sender].uncommon >= count * 1) {
            global.db.data.users[m.sender].money += Suncommon * count;
            global.db.data.users[m.sender].uncommon -= count * 1;
            m.reply(`Succes menjual ${count} Uncommon Crate dengan harga ${Suncommon * count} money`.trim())
          } else
            m.reply(`Uncommon Crate kamu tidak cukup`.trim());
          break;
        case "mythic":
          if (global.db.data.users[m.sender].mythic >= count * 1) {
            global.db.data.users[m.sender].money += Smythic * count;
            global.db.data.users[m.sender].mythic -= count * 1;
            m.reply(`Succes menjual ${count} Mythic Crate dengan harga ${Smythic * count} money`.trim())
          } else m.reply(`Mythic Crate kamu tidak cukup`.trim());
          break;
        case "legendary":
          if (global.db.data.users[m.sender].legendary >= count * 1) {
            global.db.data.users[m.sender].money += Slegendary * count;
            global.db.data.users[m.sender].legendary -= count * 1;
            m.reply(`Succes menjual ${count} Legendary Crate dengan harga ${Slegendary * count} money`.trim())
          } else
            m.reply(`Legendary Crate kamu tidak cukup`.trim());
          break;
        case "sampah":
          if (global.db.data.users[m.sender].sampah >= count * 1) {
            global.db.data.users[m.sender].sampah -= count * 1;
            global.db.data.users[m.sender].money += Ssampah * count;
            m.reply(`Succes menjual ${count} sampah, dan anda mendapatkan ${Ssampah * count} money`.trim())
          } else m.reply(`Sampah anda tidak cukup`.trim());
          break;
        case "kaleng":
          if (global.db.data.users[m.sender].kaleng >= count * 1) {
            global.db.data.users[m.sender].kaleng -= count * 1;
            global.db.data.users[m.sender].money += Skaleng * count;
            m.reply(`Succes menjual ${count} kaleng, dan anda mendapatkan ${Skaleng * count} money`)
          } else m.reply(`Kaleng anda tidak cukup`);
          break;
        case "kardus":
          if (global.db.data.users[m.sender].kardus >= count * 1) {
            global.db.data.users[m.sender].kardus -= count * 1;
            global.db.data.users[m.sender].money += Skardus * count;
            m.reply(`Succes menjual ${count} kardus, dan anda mendapatkan ${Skardus * count} money`)
          } else m.reply(`Kardus anda tidak cukup`);
          break;
        case "botol":
          if (global.db.data.users[m.sender].botol >= count * 1) {
            global.db.data.users[m.sender].botol -= count * 1;
            global.db.data.users[m.sender].money += Sbotol * count;
            m.reply(`Succes menjual ${count} botol, dan anda mendapatkan ${Sbotol * count} money`)
          } else m.reply(`Botol anda tidak cukup`);
          break;
        case "kayu":
          if (global.db.data.users[m.sender].kayu >= count * 1) {
            global.db.data.users[m.sender].kayu -= count * 1;
            global.db.data.users[m.sender].money += Skayu * count;
            m.reply(`Succes menjual ${count} kayu, dan anda mendapatkan ${Skayu * count} money`)
          } else m.reply(`Kayu anda tidak cukup`);
          break;
        case "pisang":
          if (global.db.data.users[m.sender].pisang >= count * 1) {
            global.db.data.users[m.sender].pisang -= count * 1;
            global.db.data.users[m.sender].money += Spisang * count;
            m.reply(`Succes menjual ${count} pisang, dan anda mendapatkan ${Spisang * count} money`)
          } else m.reply(`Pisang anda tidak cukup`);
          break;
        case "anggur":
          if (global.db.data.users[m.sender].anggur >= count * 1) {
            global.db.data.users[m.sender].anggur -= count * 1;
            global.db.data.users[m.sender].money += Sanggur * count;
            m.reply(`Succes menjual ${count} anggur, dan anda mendapatkan ${Sanggur * count} money`)
          } else m.reply(`Anggur anda tidak cukup`);
          break;
        case "mangga":
          if (global.db.data.users[m.sender].mangga >= count * 1) {
            global.db.data.users[m.sender].mangga -= count * 1;
            global.db.data.users[m.sender].money += Smangga * count;
            m.reply(`Succes menjual ${count} mangga, dan anda mendapatkan ${Smangga * count} money`)
          } else m.reply(`Mangga anda tidak cukup`);
          break;
        case "jeruk":
          if (global.db.data.users[m.sender].jeruk >= count * 1) {
            global.db.data.users[m.sender].jeruk -= count * 1;
            global.db.data.users[m.sender].money += Sjeruk * count;
            m.reply(`Succes menjual ${count} jeruk, dan anda mendapatkan ${Sjeruk * count} money`)
          } else m.reply(`Jeruk anda tidak cukup`);
          break;
        case "apel":
          if (global.db.data.users[m.sender].apel >= count * 1) {
            global.db.data.users[m.sender].apel -= count * 1;
            global.db.data.users[m.sender].money += Sapel * count;
            m.reply(`Succes menjual ${count} apel, dan anda mendapatkan ${Sapel * count} money`)
          } else m.reply(`Apel anda tidak cukup`);
          break;
        case "berlian":
          if (global.db.data.users[m.sender].berlian >= count * 1) {
            global.db.data.users[m.sender].berlian -= count * 1;
            global.db.data.users[m.sender].money += Sberlian * count;
            m.reply(`Succes menjual ${count} berlian, dan anda mendapatkan ${Sberlian * count} money`)
          } else m.reply(`Berlian anda tidak cukup`);
          break;
        case "emas":
          if (global.db.data.users[m.sender].emas >= count * 1) {
            global.db.data.users[m.sender].emas -= count * 1;
            global.db.data.users[m.sender].money += Semasbiasa * count;
            m.reply(`Succes menjual ${count} emas, dan anda mendapatkan ${Semasbiasa * count} money`)
          } else m.reply(`Emas anda tidak cukup`);
          break;
        case "pet":
          if (global.db.data.users[m.sender].pet >= count * 1) {
            global.db.data.users[m.sender].pet -= count * 1;
            global.db.data.users[m.sender].money += Spet * count;
            m.reply(`Succes menjual ${count} pet random, dan anda mendapatkan ${Spet * count} money`)
          } else m.reply(`Pet Random anda tidak cukup`);
          break;
        case "makananpet":
          if (global.db.data.users[m.sender].makananpet >= count * 1) {
            global.db.data.users[m.sender].makananpet -= count * 1;
            global.db.data.users[m.sender].money += Smakananpet * count;
            m.reply(`Succes menjual ${count} makanan pet, dan anda mendapatkan ${Smakananpet * count} money`)
          } else m.reply(`Makanan pet anda tidak cukup`);
          break;
        case "makanannaga":
          if (global.db.data.users[m.sender].makanannaga >= count * 1) {
            global.db.data.users[m.sender].makanannaga -= count * 1;
            global.db.data.users[m.sender].money += Smakanannaga * count;
            m.reply(`Succes menjual ${count} makanan naga, dan anda mendapatkan ${Smakanannaga * count} money`)
          } else m.reply(`Makanan naga anda tidak cukup`);
          break;
        case "makananphonix":
          if (global.db.data.users[m.sender].makananphonix >= count * 1) {
            global.db.data.users[m.sender].makananphonix -= count * 1;
            global.db.data.users[m.sender].money += Smakananphonix * count;
            m.reply(`Succes menjual ${count} makanan phonix, dan anda mendapatkan ${Smakananphonix * count} money`)
          } else m.reply(`Makanan phonix anda tidak cukup`);
          break;
        case "makanankyubi":
          if (global.db.data.users[m.sender].makanankyuni >= count * 1) {
            global.db.data.users[m.sender].makanankyubi -= count * 1;
            global.db.data.users[m.sender].money += Smakanankyubi * count;
            m.reply(`Succes menjual ${count} makanan kyubi, dan anda mendapatkan ${Smakanankyubi * count} money`)
          } else m.reply(`Makanan kyubi anda tidak cukup`);
          break;
        case "makanangriffin":
          if (global.db.data.users[m.sender].makanangriffin >= count * 1) {
            global.db.data.users[m.sender].makanangriffin -= count * 1;
            global.db.data.users[m.sender].money += Smakanangriffin * count;
            m.reply(`Succes menjual ${count} makanan griffin, dan anda mendapatkan ${Smakanangriffin * count} money`)
          } else m.reply(`Makanan griffin anda tidak cukup`);
          break;
        case "makanancentaur":
          if (global.db.data.users[m.sender].makanancentaur >= count * 1) {
            global.db.data.users[m.sender].makanancentaur -= count * 1;
            global.db.data.users[m.sender].money += Smakanancentaur * count;
            m.reply(`Succes menjual ${count} makanan centaur, dan anda mendapatkan ${Smakanancentaur * count} money`)
          } else m.reply(`Makanan centaur anda tidak cukup`);
          break;
        case "aqua":
          if (global.db.data.users[m.sender].aqua >= count * 1) {
            global.db.data.users[m.sender].aqua -= count * 1;
            global.db.data.users[m.sender].money += Saqua * count;
            m.reply(`Succes menjual ${count} aqua, dan anda mendapatkan ${Saqua * count} money`)
          } else m.reply(`Aqua anda tidak cukup`);
          break;
        case "pancingan":
          if (global.db.data.users[m.sender].pancingan >= count * 1) {
            global.db.data.users[m.sender].pancingan -= count * 1;
            global.db.data.users[m.sender].money += Spancingan * count;
            m.reply(`Succes menjual ${count} pancingan, dan anda mendapatkan ${Spancingan * count} money`)
          } else m.reply(`Pancingan anda tidak cukup`);
          break;
        case "iron":
          if (global.db.data.users[m.sender].iron >= count * 1) {
            global.db.data.users[m.sender].iron -= count * 1;
            global.db.data.users[m.sender].money += Siron * count;
            m.reply(`Succes menjual ${count} pancingan, dan anda mendapatkan ${Siron * count} money`)
          } else m.reply(`Iron anda tidak cukup`);
          break;
        case "string":
          if (global.db.data.users[m.sender].string >= count * 1) {
            global.db.data.users[m.sender].string -= count * 1;
            global.db.data.users[m.sender].money += Sstring * count;
            m.reply(`Succes menjual ${count} string, dan anda mendapatkan ${Sstring * count} money`)
          } else m.reply(`String anda tidak cukup`);
          break;
        case "sword":
          if (global.db.data.users[m.sender].sword >= count * 1) {
            global.db.data.users[m.sender].sword -= count * 1;
            global.db.data.users[m.sender].money += Ssword * count;
            m.reply(`Succes menjual ${count} sword, dan anda mendapatkan ${Ssword * count} money`)
          } else m.reply(`Sword anda tidak cukup`);
          break;
        case "batu":
          if (global.db.data.users[m.sender].batu >= count * 1) {
            global.db.data.users[m.sender].batu -= count * 1;
            global.db.data.users[m.sender].money += Sbatu * count;
            m.reply(`Succes menjual ${count} batu, dan anda mendapatkan ${Sbatu * count} money`)
          } else m.reply(`Batu anda tidak cukup`);
          break;
        case "limit":
          if (global.db.data.users[m.sender].limit >= count * 1) {
            global.db.data.users[m.sender].limit -= count * 1;
            global.db.data.users[m.sender].money += Slimit * count;
            m.reply(`Succes menjual ${count} limit, dan anda mendapatkan ${Slimit * count} money`)
          } else m.reply(`Limit anda tidak cukup`);
          break;
        case "diamond":
          if (global.db.data.users[m.sender].diamond >= count * 1) {
            global.db.data.users[m.sender].diamond -= count * 1;
            global.db.data.users[m.sender].money += Sdiamond * count;
            m.reply(`Succes menjual ${count} Diamond, dan anda mendapatkan ${Sdiamond * count} money`)
          } else m.reply(`Diamond anda tidak cukup`);
          break;
        default:
          return m.reply(Kchat);
      }
    }
  } catch (e) {
    m.reply(Kchat);
    console.log(e);
  }
};

handler.command = handler.help = ["shop", "toko"];
handler.tags = ["rpg"];
handler.group = true;

handler.register = true;
module.exports = handler;
