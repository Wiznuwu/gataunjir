let handler = async (m, { conn, text, participants, usedPrefix, command }) => {
    let userMessages = participants.map(mem => ({
        id: mem.id,
        chat: db.data.users[mem.id]?.chat || 0
    }));

    // Urutkan berdasarkan jumlah pesan (chat) dari yang terbanyak ke yang paling sedikit
    userMessages.sort((a, b) => b.chat - a.chat);

    // Format teks
    let teks = `╚»˙·٠● Total Pesan Hari ini ●٠·˙«╝\n\n`;
    for (let user of userMessages) {
        teks += ` @${user.id.split('@')[0]}: ${user.chat}\n`;
    }

    // Kirim pesan
    conn.sendMessage(m.chat, {
        text: teks,
        mentions: userMessages.map(a => a.id)
    }, {
        quoted: m
    });
};

handler.help = ["listtotalpesan"];
handler.tags = ["info"];
handler.command = ["listtotalpesan"];
handler.admin = true;
handler.group = true;

module.exports = handler;