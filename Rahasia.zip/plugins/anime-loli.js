let handler = async (m, { conn, text, usedPrefix, command }) => {
const fetch = require("node-fetch")
switch (command) {
case 'loli': {
            let baseUrl = 'https://weeb-api.vercel.app/'
      const response = await fetch(baseUrl + command)     
      conn.sendMessage(m.chat, {image: { url: response.url }, caption: `Random ${command} for you!✨`}, {quoted: m})    
            }
            break
            case 'waifu': {
            let baseUrl = 'https://weeb-api.vercel.app/'
      const response = await fetch(baseUrl + command)     
      conn.sendMessage(m.chat, {image: { url: response.url }, caption: `Random ${command} for you!✨`}, {quoted: m})    
            }
     }
   }
handler.help = ["loli *[random image]*","waifu *[random image]*"];
handler.tags = ["anime"];
handler.command = ["loli","waifu"];
module.exports = handler;