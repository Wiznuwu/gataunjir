let handler = async (m, { teks, conn, isOwner, isAdmin, args, participants}) => {
  let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";
  
  // New 'kick all' functionality
  if (args[0] === 'all') {
    let kickedUsers = [];
    let failedUsers = [];

    for (let mem of db.data.chats[m.chat].member) {
      // Skip owner and bot
      if (mem === ownerGroup || mem === conn.user.jid || mem === m.sender) continue;

      let maxAttempts = 3;
      let attempts = 0;
      let kicked = false;

      while (attempts < maxAttempts && !kicked) {
        try {
          await conn.groupParticipantsUpdate(m.chat, [mem], "remove");
          kicked = true;
          kickedUsers.push(mem);
        } catch (error) {
          attempts++;
          if (attempts === maxAttempts) {
            failedUsers.push(mem);
          }
        }
      }
    }
  }

  // Existing kick functionality for quoted or tagged users
  if (m.quoted) {
    if (m.quoted.sender === ownerGroup || m.quoted.sender === conn.user.jid)
      return;
    let usr = m.quoted.sender;
    await conn.groupParticipantsUpdate(m.chat, [usr], "remove");
    return;
  }
  
  if (!m.mentionedJid[0]) throw `*• Example :* .kick *[reply/tag use]*`;
  
  let users = m.mentionedJid.filter(
    (u) => !(u == ownerGroup || u.includes(conn.user.jid)),
  );
  
  for (let user of users)
    if (user.endsWith("@s.whatsapp.net"))
      await conn.groupParticipantsUpdate(m.chat, [user], "remove");
};

handler.help = ["kick"].map((a) => a + " *[reply/tag user/all]*");
handler.tags = ["group"];
handler.command = ["kick"];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

handler.register = true;
module.exports = handler;