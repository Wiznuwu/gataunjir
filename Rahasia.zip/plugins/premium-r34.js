const axios = require('axios');
const cheerio = require('cheerio');
let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    conn.r34 = conn.r34 ? conn.r34 : {};
    let newText = text.replace(/\s/g, "-");
    if (!text) {
      return m.reply(`Masukkan pencarian nya\n*Contoh:* ${usedPrefix + command} Hu tao`)
}
    m.reply(wait);    
let response = await axios.get(`https://rule34video.com/search/${newText}/`)
const $ = cheerio.load(response.data);
const div = $('#custom_list_videos_videos_list_search_items');
const isiDiv = div.html();
const videos = [];
div.find('a').each((index, element) => {
const title = $(element).attr('title');
const href = $(element).attr('href');
if (title && href) { 
videos.push({
title,
href
});
}
});  
   let hasil = videos
      .map(
        (v, index) =>
          `*${index + 1}.* *Title:* ${v.title}`,
      )
      .join("\n\n");
    let { key } = await await conn.reply(m.chat, hasil, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "rule34.xxx",
body: "Created by Mephistod",
thumbnailUrl: "https://tmpfiles.org/dl/12918648/6a8b75633d.jpg",
sourceUrl: "https://rule34.xxx/",
mediaType: 1,
renderLargerThumbnail: true,
},
},
});
    await conn.reply(
      m.chat,
      `Ketik angka *1 - ${videos.length}* sesuai dengan pesan di atas`,
      null,
    );
    conn.r34[m.sender] = videos;
  } catch (error) {
    console.log(error);
    conn.reply(m.chat, "Terjadi kesalahan dalam menjalankan perintah", m);
  }
};

handler.before = async (m, { conn }) => {
  try {
    conn.r34 = conn.r34 ? conn.r34 : {};
    if (m.isBaileys) return;
    if (!m.text) return;
    if (!conn.r34[m.sender]) return;
    if (
      isNaN(m.text) ||
      m.text <= 0 ||
      m.text > conn.r34[m.sender].length
    )
      return;
      
    let pilihan = conn.r34[m.sender][m.text - 1].href;
    let response = await Func.fetchJson(pilihan)
let $ = cheerio.load(response)
let scriptTag = $('script[type="application/ld+json"]')
const json = JSON.parse(scriptTag.text())
const name = json.name
const contentUrl = json.contentUrl
let hasil = {
"name": json.name,
"url": json.contentUrl
}
    m.reply(wait);
    await conn.sendFile(m.chat, hasil.url, null, hasil.name, m);
    delete conn.r34[m.sender];
  } catch (error) {
    console.log(error);
    conn.reply(m.chat, "Terjadi kesalahan dalam menjalankan perintah", m);
  }
};
handler.help = ["r34 *[query]*"];
handler.command = ["r34"];
handler.tags = ["premium", "downloader"];
handler.premium = true
module.exports = handler;