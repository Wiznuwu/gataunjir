const cron = require('node-cron');

let handler = async (
  m,
  { conn, isAdmin, isOwner, args, usedPrefix, command },
) => {
  let isClose = {
    open: "not_announcement",
    buka: "not_announcement",
    on: "not_announcement",
    1: "not_announcement",
    close: "announcement",
    tutup: "announcement",
    off: "announcement",
    0: "announcement",
  }[args[0] || ""];
  
  if (isClose === undefined) {
    let caption = `*• Example :* ${usedPrefix + command} *[buka/tutup duration]*`;
    m.reply(caption);
    throw false;
  }

  // Convert hours to cron schedule
  let hours = parseInt(args[1]) || 0;
  if (hours <= 0) {
    await conn.groupSettingUpdate(m.chat, isClose);
    return m.reply(
      `Success ${isClose == "announcement" ? "close" : "open"} group`
    );
  }

  // Get current time
  let now = new Date();
  // Calculate target time
  let targetTime = new Date(now.getTime() + (hours * 60 * 60 * 1000));

  // Create cron schedule
  let cronSchedule = `${targetTime.getMinutes()} ${targetTime.getHours()} ${targetTime.getDate()} ${targetTime.getMonth() + 1} *`;

  // Initial group setting update
  await conn.groupSettingUpdate(m.chat, isClose).then(async (_) => {
    m.reply(
      `Success ${isClose == "announcement" ? "close" : "open"} group, will ${isClose == "announcement" ? "open" : "close"} after *${hours} hours*`
    );
  });

  // Schedule the reverse action
  cron.schedule(cronSchedule, async () => {
    try {
      await conn.groupSettingUpdate(
        m.chat,
        `${isClose == "announcement" ? "not_announcement" : "announcement"}`
      );
      
      conn.reply(
        m.chat,
        `Group has been ${isClose == "not_announcement" ? "closed, now only admins can send messages" : "opened, now all members can send messages"}!`
      );
    } catch (error) {
      console.error("Error in scheduled task:", error);
      conn.reply(m.chat, "Failed to update group settings automatically.");
    }
  }, {
    scheduled: true,
    timezone: "Asia/Jakarta" // Adjust timezone as needed
  });
};

handler.help = ["grouptime", "gctime"].map(
  (a) => a + " *[buka/tutup duration]*"
);
handler.tags = ["group"];
handler.command = ["gctime", "grouptime"];
handler.botAdmin = true;
handler.group = true;
handler.admin = true;
handler.register = true;

module.exports = handler;