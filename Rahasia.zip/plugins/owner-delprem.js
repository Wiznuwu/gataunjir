let handler = async function (m, { text, args, usedPrefix }) {
try {
  if (!args[0]) return m.reply("Siapa yang mau di delprem??");
  for (let i = 0; i < args.length; i++) {
    let who = m.mentionedJid[i];
    let user = global.db.data.users[who];
    if (!who) return m.reply(args[i] + " harus berupa tag");
    user.premiumDate = 0;
    user.premium = false;
  }
    m.reply(`Successfully removed premium access to that user`);
  } catch (e) {
    throw eror;
  }
};
handler.help = ["delprem", "unprem"].map((a) => a + " *[number]*");
handler.command = ["delprem", "unprem"];
handler.tags = ["owner"];
handler.rowner = true;

handler.register = true;
module.exports = handler;