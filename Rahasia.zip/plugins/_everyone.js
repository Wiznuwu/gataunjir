let handler = async (m, { conn, text, participants }) => {
  conn.sendMessage(
    m.chat,
    { text: `@everyone ${text}`, mentions: participants.map((a) => a.id) });
}
handler.customPrefix = /^(@everyone)$/i;
handler.command = new RegExp();

handler.register = false

module.exports = handler