let handler = async (m, { conn, text }) => {
    if (!text) throw "Masukan judul atau lirik lagu";
    m.reply(wait);
   try {
    let lirik = await Func.fetchJson(`https://api.betabotz.eu.org/api/search/lirik?lirik=${text}&apikey=${global.apibeta}`);
    
    if (!lirik.result || Object.keys(lirik.result).length === 0) {
        return m.reply("Maaf, lirik dari judul yang Anda cari tidak ditemukan. Jangan menginput lirik, Anda harus memasukan judul lagu.");
    }

    let { lyrics, title, artist, image } = lirik.result;
    let pesan = `Judul: ${title}\nArtist: ${artist}\n\nLyrics:\n${lyrics}`;

    await conn.sendMessage(m.chat, { image: { url: image }, caption: pesan }, { quoted: m });
    } catch {
    m.reply("lirik yang kamu cari tidak ada")
    }
};

handler.command = ["lirik", "lyrics"];
handler.help = ["lyrics *[judul lagu]*"];
handler.tags = ["tools"];
handler.limit = true;

module.exports = handler;