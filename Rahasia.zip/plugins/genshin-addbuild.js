let fs = require("fs");

let handler = async (m,{ conn, text, command }) => {
switch (command) {
case "addbuildgi": {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) return m.reply('Tidak ada media');
if (!text) throw "Input Nama Character"
  let directory = `lib/genshin.json`
  let media = await q.download();
  let link = await Uploader.catbox(media).catch(async _ => await Uploader.telegraPh(media))
const jsonData = fs.readFileSync(directory, 'utf8');
try {
  const data = JSON.parse(jsonData)
  const characterName = text.toLowerCase();
  if (!data[characterName]) {
    data[characterName] = {};
  }
  data[characterName].build = link;
  fs.writeFileSync(directory, JSON.stringify(data, null, 2));
  m.reply(`Sukses Up Media Build untuk ${characterName} ke *[ ${directory} ]*`);
} catch {
  m.reply('Kesalahan saat menambahkan media build. Periksa console untuk detailnya.');
}
}
break;
case "addmaterialgi": {
let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) return m.reply('Tidak ada media');
if (!text) throw "Input Nama Character"
  let directory = `lib/genshin.json`
  let media = await q.download();
  let link = await Uploader.catbox(media).catch(async _ => await Uploader.telegraPh(media))
const jsonData = fs.readFileSync(directory, 'utf8');
try {
  const data = JSON.parse(jsonData)
  const characterName = text.toLowerCase();
  if (!data[characterName]) {
    data[characterName] = {};
  }
  data[characterName].material = link;
  fs.writeFileSync(directory, JSON.stringify(data, null, 2));
  m.reply(`Sukses Up Media Material untuk ${characterName} ke *[ ${directory} ]*`);
} catch {
  m.reply('Kesalahan saat menambahkan media material. Periksa console untuk detailnya.');
}
}
break;
  }
}
handler.help = ['addbuildgi', "addmaterialgi"];
handler.tags = ['owner'];
handler.command = ["addbuildgi", "addmaterialgi"];
handler.owner = true;
module.exports = handler;