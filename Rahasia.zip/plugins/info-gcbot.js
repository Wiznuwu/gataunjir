let handler = async (m, { conn, text, usedPrefix, command }) => {
   conn.sendMessage(m.chat, {
                    text: `${sgc}`,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: global.namebot,
                            body: "Mephistod",
                            thumbnailUrl: 'https://files.catbox.moe/glsfl7.jpg',
                            sourceUrl: sgc,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: m
                })   
}
handler.help = ["gcbot"].map(a => a + " *[official group bot]*")
handler.tags = ["info"]
handler.command = ["gcbot"]
module.exports = handler