let handler = (m) => m;
handler.before = async function (m) {
const woi = m.sender
  let user = db.data.users[m.sender];
  if (user.premium && new Date() - user.premiumDate > 0 ) {
    user.premiumDate = 0;
    user.premium = false;
    user.limit = 25;
  conn.sendMessage(woi, { text: "*❏ PREMIUM EXPIRED*\n> Premium Anda Telah Expired Ketik .buyprem Atau Hubungi Owner Untuk Membeli Premium Lagi." })
 }
}

module.exports = handler;