let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Handler implementation if needed
}

handler.before = async (m, { conn, usedPrefix }) => {
    if (!m.sender) return; // Early return if no sender
    
    try {
        let user = global.db.data.users[m.sender];
        if (!user) return; // Early return if no user data
        
        // Get sender's name and convert to regular characters for comparison
        let senderName = await conn.getName(m.sender);
        // Normalize the comparison string
        let normalizedName = senderName.toLowerCase();
        let targetText = "𝐖𝐈𝐁𝐔𝐒𝐎𝐅𝐓".toLowerCase();
        
        // Debug log
        console.log('Checking name:', senderName, 'Contains WIBUSOFT:', normalizedName.includes(targetText));
        
        // Check if name contains WIBUSOFT (case insensitive) and bonus not received
        if (normalizedName.includes(targetText) && !user.wibusoftBonus) {
            console.log('Giving bonus to:', senderName);
            user.limit += 500;
            user.wibusoftBonus = true;
        }
        
        // Check if name doesn't contain WIBUSOFT but bonus was received
        if (!normalizedName.includes(targetText) && user.wibusoftBonus) {
            console.log('Removing bonus from:', senderName);
            user.limit = 0;
            user.wibusoftBonus = false;
            m.reply(`Limit direset karena nama tidak lagi mengandung WIBUSOFT`);
        }
        
    } catch (error) {
        console.error('Error in WibuSoft handler:', error);
        // Optional: Handle error appropriately
    }
};

module.exports = handler;