let handler = async (m, { conn, text, usedPrefix, command }) => {
  }
handler.before = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]; // Ambil data user
    let senderName = conn.getName(m.sender); // Ambil nama pengguna

    if (m.sender) {
        // Cek jika nama mengandung "𝐖𝐈𝐁𝐔𝐒𝐎𝐅𝐓" dan bonus belum diterima
        if (senderName.includes("𝐖𝐈𝐁𝐔𝐒𝐎𝐅𝐓") && !user.wibusoftBonus) {
            user.limit += 500; // Tambah limit 500
            user.wibusoftBonus = true; // Tandai bonus telah diterima
        }

        // Cek jika nama tidak mengandung "𝐖𝐈𝐁𝐔𝐒𝐎𝐅𝐓" tetapi bonus sudah diterima
        if (!senderName.includes("𝐖𝐈𝐁𝐔𝐒𝐎𝐅𝐓") && user.wibusoftBonus) {
            user.limit = 0; // Hapus limit
            user.wibusoftBonus = false; // Pastikan bonus tidak dapat diterima lagi
        }
    }
};

module.exports = handler;