const ffmpeg = require("fluent-ffmpeg");
const fs = require("fs");

let handler = async (m, { conn }) => {
  // Mencegah spam dengan menggunakan sistem kontrol
  conn.hdvid = conn.hdvid || {};
  if (m.sender in conn.hdvid) throw "Masih ada proses yang belum selesai, silakan tunggu hingga selesai.";

  try {
    conn.hdvid[m.sender] = true; // Tandai proses berjalan untuk pengguna ini

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    if (!mime) throw `Video tidak ditemukan`;
    m.reply("⏳ Sedang memproses, harap tunggu...");

    // Mendapatkan file video
    let videoData = await conn.downloadAndSaveMediaMessage(q, "video"); // Simpan file sementara

    ffmpeg.ffprobe(videoData, (err, metadata) => {
      if (err) {
        console.error(err);
        delete conn.hdvid[m.sender];
        return m.reply("Terjadi kesalahan saat membaca metadata video.");
      }

      let { width, height } = metadata.streams.find((stream) => stream.codec_type === "video") || {};
      if (!width || !height) {
        delete conn.hdvid[m.sender];
        return m.reply("Terjadi kesalahan: Tidak dapat mendeteksi resolusi video.");
      }

      // Tentukan resolusi target
      let targetWidth = 1280; // Resolusi target default
      let targetHeight = Math.round((height / width) * targetWidth); // Hitung tinggi berdasarkan rasio aspek

      // Validasi resolusi untuk memastikan nilai valid
      if (targetWidth % 2 !== 0) targetWidth++; // Lebar harus kelipatan 2
      if (targetHeight % 2 !== 0) targetHeight++; // Tinggi harus kelipatan 2

      let output = "./scrape/video_hd.mp4"; // Path file output
      ffmpeg(videoData)
        .outputOptions([
          "-vf", `scale=${targetWidth}:${targetHeight}`, // Skalakan video sesuai resolusi target
          "-preset", "fast", // Gunakan preset ringan
          "-crf", "28", // Tingkat kompresi untuk ukuran lebih kecil
        ])
        .videoCodec("libx264") // Codec untuk kompresi efisien
        .on("start", () => console.log("Proses peningkatan resolusi dimulai..."))
        .on("end", () => {
          conn.sendFile(m.chat, output, "", `🍟 Nih Kak`, m).then(() => {
            // Hapus file sementara
            fs.unlink(videoData, (err) => {
              if (err) console.error("Gagal menghapus file sementara:", err);
            });
            fs.unlink(output, (err) => {
              if (err) console.error("Gagal menghapus file output:", err);
            });
            delete conn.hdvid[m.sender]; // Hapus kontrol setelah selesai
          });
        })
        .on("error", (err) => {
          console.error(err);
          m.reply("Terjadi kesalahan saat meningkatkan resolusi video. " + err);

          // Hapus file sementara jika terjadi error
          fs.unlink(videoData, (err) => {
            if (err) console.error("Gagal menghapus file sementara:", err);
          });
          delete conn.hdvid[m.sender]; // Hapus kontrol jika terjadi kesalahan
        })
        .save(output);
    });
  } catch (error) {
    console.error(error);
    m.reply('🚩 Terjadi kesalahan pada server. Coba lagi nanti.');
    delete conn.hdvid[m.sender]; // Hapus kontrol jika terjadi kesalahan
  }
};

handler.command = handler.help = ["hdvid"];
handler.tags = ["tools"];
handler.limit = true;

module.exports = handler;