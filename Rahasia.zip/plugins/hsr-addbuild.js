let fs = require("fs");

let handler = async (m, { conn, text, command }) => {
  switch (command) {
    case "addbuildhsr": {
      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || '';
      if (!mime) return m.reply('Tidak ada media');
      if (!text) throw "Input Nama Character";

      let directory = `lib/hsr.json`;

      // Pastikan file ada, jika tidak buat file kosong
      if (!fs.existsSync(directory)) {
        fs.writeFileSync(directory, JSON.stringify({}));
      }

      let media;
      try {
        media = await q.download();
      } catch (err) {
        return m.reply('Gagal mengunduh media. Pastikan media valid.');
      }

      let link;
      try {
        link = await Uploader.catbox(media).catch(async _ => await Uploader.telegraPh(media));
      } catch (err) {
        return m.reply('Gagal mengunggah media.');
      }

      const jsonData = fs.readFileSync(directory, 'utf8');
      let data = {};
      try {
        data = JSON.parse(jsonData);
      } catch (err) {
        return m.reply('File JSON rusak. Reset file atau periksa isinya.');
      }

      const characterName = text.toLowerCase();
      if (!data[characterName]) {
        data[characterName] = {};
      }
      data[characterName].build = link;

      try {
        fs.writeFileSync(directory, JSON.stringify(data, null, 2));
        m.reply(`Sukses mengunggah media build untuk ${characterName} ke *[ ${directory} ]*`);
      } catch (err) {
        m.reply('Kesalahan saat menyimpan data ke file JSON.');
      }
      break;
    }
    default:
      m.reply('Perintah tidak dikenali.');
  }
};

handler.help = ['addbuildhsr'];
handler.tags = ['owner'];
handler.command = ["addbuildhsr"];
handler.owner = true;
module.exports = handler;