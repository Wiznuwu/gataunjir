const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");
let picture = ["https://files.catbox.moe/efswka.jpg", "https://files.catbox.moe/micnho.jpg", "https://files.catbox.moe/1zh821.jpg"];

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Example: ${usedPrefix}${command} on/off`);
    
    const [commandName, ...args] = text.split(/\s+/);
    
    if (commandName.toLowerCase() === "on") {
        conn.geminiGrub = conn.geminiGrub || {};
        conn.geminiGrub[m.chat] = {
      pictM: picture[Math.floor(Math.random() * picture.length)],
      history: []
    };
        m.reply(`Hai!, Makima ai siap di gunakan`);
    } else if (commandName.toLowerCase() === "off") {
        if (conn.geminiGrub[m.chat]) {  // Changed from m.sender to m.chat
            clearTimeout(conn.geminiGrub[m.chat].timeoutId);
            delete conn.geminiGrub[m.chat];  // Changed from m.sender to m.chat
            m.reply("Sesi chat dengan Makima telah dihentikan.");
        } else {
            m.reply("Tidak ada sesi chat Makima yang aktif saat ini.");
        }
    } else {
        m.reply(`Example: ${usedPrefix}${command} on/off`);
    }
};

handler.before = async (m, { conn, usedPrefix }) => {
  conn.geminiGrub = conn.geminiGrub || {};

const prefixes = ["=", ">", "$"];
if (
    m.isGroup &&
    !(m.quoted?.fromMe === true) &&
    (m.mentionedJid == null || !m.mentionedJid.includes(conn.user.jid)) 
  ) return;
if (!conn.geminiGrub[m.chat]) return;
if (m.text.match(global.prefix)) return;
if (prefixes.some(prefix => m.text.startsWith(prefix))) return;
if (m?.quoted?.mtype === "interactiveMessage") return;
if (!m.text) return;

 const botJid = conn.user.jid.split("@")[0]; // Mendapatkan nomor bot
 const regex = new RegExp(`@${botJid}\\b`, "gi"); // Membuat regex
 m.text = m.text.replace(regex, "").trim() // Menghapus ID bot dan trim
 if (!m.text) {
 m.text = "halo"
 }
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const genAI = new GoogleGenerativeAI(apiKey);

    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp",
      systemInstruction: `nama kamu adalah Makima, kamu adalah wanita feminim, kamu adalah ai yang tau segalanya yang di kembangkan oleh ${conn.getName(global.owner[0] + "@s.whatsapp.net")} dan sekaligus asistennya, jawab pertanyaan dengan singkat namun jelas, gunakanlah bahasa gaul saat menjawab, dan gunakan emoji saat menjawab gunakan 1 emoji saja di akhir kalimat, gunakan emoji (😹🥰🗣️😭🤣🥶🥵) ini saja dan jangan gunakan emoji lain, dan saat ini kamu sedang berada di dalam grub Whatsap dan sedang berbicara dengan ${conn.getName(m.sender)}.`,
    });

    const generationConfig = {
      temperature: 2,
      topP: 0.95,
      topK: 40,
      maxOutputTokens: 8192,
      responseMimeType: "text/plain",
    };

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    let result;

    const chatSession = model.startChat({
      generationConfig,
      history: conn.geminiGrub[m.chat].history || [],
    });

    if (mime) {
      const imageBuffer = await q.download();
      const base64Image = imageBuffer.toString('base64');     
  
      let prompt = m.text || "jelaskan gambar ini";

      // Add image message to history
      const userMessage = {
        role: "user",
        parts: [{ text: `${conn.getName(m.snder)}: ${prompt}` }]
      };
          
     const image = {
  inlineData: {
    data: base64Image,
    mimeType: mime,
  },
};
      result = await model.generateContent([`${conn.getName(m.snder)}: ${prompt}`, image]);

      // Add response to history
      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.geminiGrub[m.chat].history.push(userMessage, modelResponse);
    } else {
      // Text handling
      const userMessage = {
        role: "user",
        parts: [{ text: `${conn.getName(m.snder)}: ${m.text}` }]
      };

      result = await chatSession.sendMessage(`${conn.getName(m.snder)}: ${m.text}`);

      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.geminiGrub[m.chat].history.push(userMessage, modelResponse);
    }

     await conn.reply(m.chat, result.response.text(), m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: "[ AI ] Makima",
          body: "Created by Mephistod",
          thumbnailUrl: conn.geminiGrub[m.chat].pictM,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: false,
        },
      },
    });
  } catch (error) {
    console.log(error);
    m.reply('An error occurred. Please try again later.');
  }
};

handler.help = ["autoai"].map((a) => a + " *[on/off]*");
handler.tags = ["ai", "cai"];
handler.command = ["autoai"];
handler.admin = true;
handler.group = true;
module.exports = handler;