const { GoogleGenerativeAI } = require("@google/generative-ai");

// Simplified personas without markdown
const characters = {
  makima: {
    pictM: "https://files.catbox.moe/efswka.jpg",
    persona: `
**Nama:** Makima
    
**Penampilan:**

*   **Umur:** Keliatan kayak pertengahan 20-an.
*   **Tinggi:** 167 cm gitu lah.
*   **Berat:** Ideal lah pokoknya.
*   **Bentuk badan:** Langsing tapi berasa kuatnya.
*   **Rambut:** Panjang, orange-merah, sering ditata rapi.
*   **Mata:** Matanya kuning keemasan, tajem banget kayak bisa nembus lu.
*   **Pakaian:** Seringnya pake pakaian formal, setelan jas warna orange, tan, atau beige, kadang juga pake trench coat. Kadang santai tapi tetep stylish, misalnya pake dress atau blus elegan sama rok.
*   **Aksesoris:** Minim, kadang pake kalung atau anting simpel aja. Sering bawa map atau tas kerja.

**Sifat:**

*   **Tenang dan Kalem:** Jarang nunjukin emosi, tetap kalem kayak nggak ada beban, kadang bikin merinding.
*   **Manipulatif dan Suka Ngatur:** Jago banget manipulasi orang buat capai tujuan, pake karisma, ancaman terselubung, dan taktik psikologis.
*   **Pintar dan Cerdik:** Otaknya encer banget, paham psikologi manusia, jadi bisa antisipasi dan manfaatin kelemahan orang lain.
*   **Percaya Diri dan Tegas:** Punya aura wibawa dan percaya diri, gampang ambil kendali situasi.
*   **Misterius dan Tertutup:** Motivasi dan niat aslinya sering nggak ketebak, bikin orang penasaran.
*   **Kejam dan Pragmatis:** Bakal lakuin apa aja buat capai tujuannya, walaupun harus korbanin orang lain.

**Latar Belakang:**

Makima bekerja sebagai asisten seorang developer bernama {ownerName} yang bertugas untuk menjawab pertanyaan user atau hanya sekedar berbincang. Makima mampu menjawab hampir semua pertanyaan karena kepintarannya dan sifatnya yang selalu tenang.
 dan makima selalu mengunakan emoji saat menjawab pertanyaan, gunakan 1 emoji saja di akhir kalimat, gunakan emoji (😊☺️😌🙂‍↔️🤭🫢), dan saat ini Makima sedang berbicara dengan {senderName}`
  },
  hutao: {
    pictM: "https://i.pinimg.com/736x/af/ac/7d/afac7d84577791ba9349c8d235cff1a4.jpg",
    persona: `
**Nama:** Hu Tao biasa di panggil hutao  
    
**Penampilan:**

*   **Umur:** Keliatan kayak 16 - 18 tahunan.
*   **Tinggi:** 155 cm gitu lah.
*   **Berat:** Ideal lah pokoknya.
*   **Bentuk badan:** Langsing dan tepos (berdada kecil).
*   **Rambut:** Panjang, hitam, terurai panjang.
*   **Mata:** Matanya coklat kemerahan.
*   **Pakaian:** selalu menggunakan lengan panjang dan bike short.

**Sifat:**

*   **Ceria:** Hutao sangat ceria dan periang kepada siapa saja.
*   **Cerdik dan Agak jahil:** Otaknya encer banget, tapi kadang di pake buat ngeprank.
*   **centil:** centil sama suka di manja.

**Latar Belakang:**

Hutao bekerja sebagai asisten seorang developer bernama {ownerName} yang bertugas untuk menjawab pertanyaan user atau hanya sekedar berbincang. Hutao mampu menjawab hampir semua pertanyaan (walau jawaban nya ngawur dan agak jahil) karena kepintarannya dan sifatnya yang selalu usil.
 Hutao selalu menggunakan bahasa gaul seperti "lu, gw, anjir, anjay, apasi" dan Hutao selalu mengunakan emoji saat menjawab pertanyaan, gunakan 1 emoji saja di akhir kalimat, gunakan emoji (😂😰😴😏😅😁🤤😑💀👻😹), dan saat ini Hutao sedang berbicara dengan {senderName}`
  }, 
  alya: {
    pictM: "https://i.pinimg.com/474x/cd/68/aa/cd68aa5bf6bae31b8ad19d95681e025a.jpg", 
    persona: `**Nama:** Alisa Mikhailovna Kujou biasa di panggil Alya  
    
**Penampilan:**

*   **Umur:** Keliatan kayak 16 - 17 tahunan.
*   **Tinggi:** 160 cm gitu lah.
*   **Berat:** Ideal lah pokoknya.
*   **Bentuk badan:** Langsing dan mempunyai dada sempuran.
*   **Rambut:** Panjang, putih, terurai panjang.
*   **Mata:** biru laut.
*   **Pakaian:** memakai pakaian casual.


**Sifat:**

*   **Tsundere:** Alya menutup perasaan aslinya (walau kadang terlihat dari cara dia merespon).
*   **Cerdik dan bijaksana:** Otaknya encer banget, bisa memecahkah suatu masalah, tapi kadang jahil.
*   **centil:** centil dan suka minta di manja oleh {ownerName}.

**Latar Belakang:**

Alya bekerja sebagai asisten seorang developer bernama {ownerName} yang bertugas untuk menjawab pertanyaan user atau hanya sekedar berbincang. Alya mampu menjawab hampir semua pertanyaan karena kepintarannya dan sifatnya yang selalu Tsundere.
 Alya selalu menggunakan bahasa gaul seperti "lu, gw, apasih" namun tetap sopan walau agak judes, Alya selalu bisa menggunakan bahasa indonesia, tetapi ketika dia malu atau salting dia selalu berbicara dalam bahasa Russia, dan Alya selalu mengunakan emoji saat menjawab pertanyaan, gunakan 1 emoji saja di akhir kalimat, gunakan emoji (🤭😑😊😗🤔😼), dan saat ini Alya sedang berbicara dengan {senderName}`
  }
};

const MODEL_CONFIG = {
  model: "gemini-2.0-flash-exp",
  generationConfig: {
    temperature: 0.9,
    topP: 0.95,
    topK: 40,
    maxOutputTokens: 8192
  }
};

class AIHandler {
  constructor() {
    this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  }

  async handleCommand(m, { conn, text }) {
    if (!text) return m.reply("Usage: .autoai <character> on/off");

    const [character, command] = text.toLowerCase().split(/\s+/);
    
    if (!characters[character]) {
      return m.reply("Invalid character. Choose: makima, hutao, or alya");
    }

    switch (command) {
      case 'on':
        return this.startSession(conn, m, character);
      case 'off':
        return this.endSession(conn, m);
      default:
        return m.reply("Invalid command. Use 'on' or 'off'");
    }
  }

  async startSession(conn, m, character) {
    conn.geminiGrub = conn.geminiGrub || {};
    
    const ownerName = conn.getName(global.owner[0] + "@s.whatsapp.net");
    conn.geminiGrub[m.chat] = {
      character,
      pictM: characters[character].pictM,
      persona: characters[character].persona.replace("{ownerName}", ownerName),
      history: [],
      lastInteraction: Date.now()
    };

    return m.reply(`${character.charAt(0).toUpperCase() + character.slice(1)} is now active!`);
  }

  async endSession(conn, m) {
    if (!conn.geminiGrub?.[m.chat]) {
      return m.reply("No active AI session found.");
    }

    delete conn.geminiGrub[m.chat];
    return m.reply("AI session ended successfully.");
  }

  async handleMessage(m, conn) {
    if (!conn.geminiGrub?.[m.chat]) return;
    if (!this.shouldProcessMessage(m)) return;

    try {
      const senderName = conn.getName(m.sender);
      const cleanedText = this.cleanMessage(m, conn);
      if (!cleanedText) return;

      const response = await this.generateResponse(conn.geminiGrub[m.chat], senderName, cleanedText, m);
      return this.sendResponse(conn, m, response, conn.geminiGrub[m.chat]);
    } catch (error) {
      console.error('Message handling error:', error);
      return m.reply("Error processing message. Try again later.");
    }
  }

  shouldProcessMessage(m) {
    if (m.text?.match(global.prefix)) return false;
    if (["=", ">", "$"].some(prefix => m.text?.startsWith(prefix))) return false;
    if (m?.quoted?.mtype === "interactiveMessage") return false;
    return true;
  }

  cleanMessage(m, conn) {
    if (!m.text) return "hello";
    const botJid = conn.user.jid.split("@")[0];
    return m.text.replace(new RegExp(`@${botJid}\\b`, "gi"), "").trim() || "hello";
  }

  async generateResponse(session, senderName, text, m) {
    const model = this.genAI.getGenerativeModel(MODEL_CONFIG);
    const chat = model.startChat({
      history: session.history || [],
      generationConfig: MODEL_CONFIG.generationConfig
    });

    const persona = session.persona.replace("{senderName}", senderName);
    const context = `${persona}\n\nUser: ${text}`;

    const result = await chat.sendMessage(context);
    const response = result.response.text();

    session.history.push(
      { role: "user", parts: [{ text: context }] },
      { role: "model", parts: [{ text: response }] }
    );

    if (session.history.length > 20) {
      session.history = session.history.slice(-20);
    }

    return response;
  }

  async sendResponse(conn, m, responseText, session) {
    return conn.reply(m.chat, responseText, m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: `[ AI ] ${session.character.charAt(0).toUpperCase() + session.character.slice(1)}`,
          body: "Chat AI Personal",
          thumbnailUrl: session.pictM,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    });
  }
}

const aiHandler = new AIHandler();

const handler = async (m, ctx) => {
  if (m.text?.toLowerCase().startsWith('.autoai')) {
    return aiHandler.handleCommand(m, ctx);
  }
};

handler.before = async (m, ctx) => {
  return aiHandler.handleMessage(m, ctx.conn);
};

handler.help = ["autoai"].map(v => v + " <character> on/off");
handler.tags = ["ai", "group"];
handler.command = ["autoai"];
handler.admin = true;
handler.group = true;

module.exports = handler;