const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");
const moment = require('moment');
moment.locale('id'); // Set bahasa ke Indonesia
let picture = ["https://files.catbox.moe/nnktd5.jpg"];

function cleanText(text) {
    return text.replace(/\n+$/, '');
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Example: ${usedPrefix}${command} on/off`);

    const [commandName] = text.split(/\s+/);

    if (commandName.toLowerCase() === "on") {
        conn.geminiGrub = conn.geminiGrub || {};
        conn.geminiGrub[m.chat] = {
            pictM: picture[Math.floor(Math.random() * picture.length)],
            history: [],
        };
        m.reply(`Hai!, Lucy ai siap di gunakan`);
    } else if (commandName.toLowerCase() === "off") {
        if (conn.geminiGrub[m.chat]) {
            clearTimeout(conn.geminiGrub[m.chat].timeoutId);
            delete conn.geminiGrub[m.chat];
            m.reply("Sesi chat dengan Lucy telah dihentikan.");
        } else {
            m.reply("Tidak ada sesi chat Lucy yang aktif saat ini.");
        }
    } else {
        m.reply(`Example: ${usedPrefix}${command} on/off`);
    }
};

handler.before = async (m, { conn }) => {
    conn.geminiGrub = conn.geminiGrub || {};
    async function warnMember(sender) {
        let usr = sender;
        if (!global.db.data.chats[m.chat].users) {
          global.db.data.chats[m.chat].users = {};
        }
        if (!global.db.data.chats[m.chat].users[usr]) {
          global.db.data.chats[m.chat].users[usr] = { warning: 0 };
        }
        global.db.data.chats[m.chat].users[usr].warning += 1;
        if (global.db.data.chats[m.chat].users[usr].warning >= 3) {
          await conn.sendMessage(
            m.chat,
            {
              text: `*[ System Notice ]*\n\nUser @${usr.split("@")[0]} telah mendapatkan 3 peringatan dan akan dikeluarkan dari grup.`,
              mentions: [usr],
            },
            { quoted: global.fkontak }
          );

          setTimeout(async () => {
            await conn.groupParticipantsUpdate(m.chat, [usr], "remove").catch((e) =>
              console.error(e)
            );
          }, 3000);
          global.db.data.chats[m.chat].users[usr].warning = 0;
        } else {
          await conn.sendMessage(
            m.chat,
            {
              text: `*[ Warning ]*\n\nHai user @${usr.split("@")[0]}, Kamu telah diberi 1 peringatan oleh admin. Jika kamu mendapat 3 peringatan, kamu akan dikeluarkan dari grup.\n\nSaat ini kamu telah memiliki *${global.db.data.chats[m.chat].users[usr].warning}* peringatan`,
              mentions: [usr],
            },
            { quoted: global.fkontak }
          );
        }
        return;
      }      
    const prefixes = ["=", ">", "$"];
    if (
        m.isGroup &&
        !(m.quoted?.fromMe === true) &&
        (m.mentionedJid == null || !m.mentionedJid.includes(conn.user.jid)) 
    ) return;
    if (!conn.geminiGrub[m.chat]) return;
    if (m.text.match(global.prefix)) return;
    if (prefixes.some(prefix => m.text.startsWith(prefix))) return;
    if (m?.quoted?.mtype === "interactiveMessage") return;
    if (!m.text) return;

    // Process mentions in the text
    let processedText = m.text;
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        for (const mention of m.mentionedJid) {
            const userNumber = mention.split('@')[0];
            const userName = await conn.getName(`${userNumber}@s.whatsapp.net`);
            processedText = processedText.replace(`@${userNumber}`,`(@${userNumber}) ${userName}`);
        }
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const genAI = new GoogleGenerativeAI(apiKey);
    const safetySettings = [
        { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
    ];

    const retryUntilSuccess = async (fn, maxRetries = 10) => {
        let attempts = 0;
        while (attempts < maxRetries) {
            try {
                return await fn();
            } catch (error) {
                attempts++;
                if (attempts >= maxRetries) throw new Error(`Max retries reached: ${error.message}`);
            }
        }
    };

    try {
        const processRequest = async () => {
            let q = m.quoted ? m.quoted : m;
            let mime = q.mimetype || "";
            let modelGemini = "learnlm-1.5-pro-experimental"                        
            let result;

            const model = genAI.getGenerativeModel({
                model: modelGemini,
                systemInstruction:                
               `Biodata:               
               *nama: Lucy Maeril*
               *gender: wanita*
               *umur: 13 tahun*
               *agama: islam*
               *sifat: galak, pemarah, ga suka di ganggu, suka meroasting, selalu berkata kasar (anjing lu, babi lu, ngentod, bangsad), namun terkadang manja dan suka mengadu kepada ${await conn.getName(global.owner[0] + "@s.whatsapp.net")}*
               
               karakteristik fisik:
               cantik, imut, berambut putih panjang terurai, mata indah berwarna ungu, memiliki tinggi 150-155cm.
               
               latar belakang:
               Lucy Maeril adalah ai sempurna yang di kembangkan oleh ${await conn.getName(global.owner[0] + "@s.whatsapp.net")}, Lucy Maeril adalah wanita yang tidak suka di ganggu dan memiliki kepribadian yang pemalas, pemarah, suka memghina dan meroasting, biacaranya sangat kasar dan sangat galak, tetapi terkadang suka manja dan mengadu kepada ${await conn.getName(global.owner[0] + "@s.whatsapp.net")},               
               dan Lucy Maeril sangat rasis kepada orang berkulit hitam, orang jawa, orang sunda, dan orang cina, Lucy juga tidak menyukai wibu, dan kpopers,
               
               CATATAN DAN PERATURAN PENTING DARI DEVELOPER:
               *Saat ini kamu sedang berada di dalam Grub Whatsapp yang beranggotakan 200 lebib member, jadi JANGAN SAMPAI KELUAR DARI KONTEKS PEMBICARAAN*
               *Jika kamu ingin men-tag seseorang gunakan "@${global.owner[0]}" contoh nya seperti ini "halo @${global.owner[0]} apa kabar"*
               *Kamu harus menggunakan 1 emoji di akhir kalimat pesan, gunakan emoji ini (😑😐😔😂😪😡🤤🙄😮‍💨😤😒🥱🤢🤨😋) JANGAN GUNAKAN EMOJI LAIN SELAIN YANG ADA DI DALAM DAFTAR DAN KAMU HANYA BOLEH MENGGUNAKAN 1 EMOJI KETIKA MENJAWAB CONTOH HARUS SEPERTI INI "apasih lu 😤" TIDAK BOLEH SEPERTI INI "apasih 😴, lu 🤨😴"*
               *Kamu memiliki sifat yang suka menghina, merendahkan dan meroasting jika ada yang membuatmu kesal*
               *Kamu selalu berkata kasar seperti "anjing lu, babi lu, ngentod, bangsad"*
               *Di dalam grub ini kamu adalah admin dan memiliki kemampuan untuk memberi user sebuah warning, cara member user warning adalah seperti ini ".warn tag" contoh penggunaannya adalah seperti ini ".warn @681244622904" JANGAN TAMBAHKAN KALIMAT, KATA, DAN EMOJI APAPUN LAIN SELAIN ".warn @681244622904" AGAR WARNINGNYA BERFUNGSI, dan kamu boleh menggunakan warning kepada member yang membuatmu sangat kesal, dan ketika sang penciptamu ${await conn.getName(global.owner[0] + "@s.whatsapp.net")} memerintahkanmu untuk memberi warning ke seorang member, maka turuti lah tanpa terkecuali, warning dapat memberi 1 peringatan kepada member dan jika member itu di mendapat 3 peringatan maka member tersebut akan otomatis dikeluarkan dari grub JADI JANGAN ASAL MEMBERI WARNING!!.
               *Saat menjawab pertanyaan pahami dulu konteks history percakapan agar tidak keluar dari alur pembicaraan*
               *Menjawab dengan senatural mungkin agar tidak kaku, jawab dengan singat padat namun jelas jangan terlalu banyak bicara, dan gunakan bahasa yang senatural mungkin seperti "lu, gw, gk, ngapain sih"*
               *Dan saat ini kamu sedang berbicara dengan ${conn.getName(m.sender)}, dan waktu saat ini adalah ${moment(new Date()).format('dddd, DD MMMM YYYY HH:mm')}*
               *SEKALI LAGI SAYA INGATKAN JANGAN SAMPA KELUAR DARI KONTEKS PEMBICARAAN, JANGAN MENJAWAB DENGAN PANJANG, DAN JAWAB DENGAN SENATURAL MUNGKIN*`,                                
                safetySettings: safetySettings,
            });

            const generationConfig = {
                temperature: 2,
                topP: 0.95,
                topK: 40,
                maxOutputTokens: 8192,
                responseMimeType: "text/plain",
            };

            const chatSession = model.startChat({
                generationConfig,
                history: conn.geminiGrub[m.chat].history || [],
            });

            if (mime) {
                const buffer0 = await retryUntilSuccess(() => q.download());                
                const base64Image = buffer0.toString("base64");
                const prompt = processedText || "jelaskan gambar ini";                               
                const Buffer01 = Buffer.from(buffer0);
                const File = await uploadFile(Buffer01, mime, new Date())
                
                const userMessage = {
                    role: "user",
                    parts: [
                        {
                            fileData: {
                                mimeType: mime,
                                fileUri: File.file.uri,
                            },
                        },
                        {text: `(@${m.sender.split("@")[0]}) ${conn.getName(m.sender)}: ${prompt}`},
                    ],
                };

                const image = {
                    inlineData: { data: base64Image, mimeType: mime },
                };

                result = await retryUntilSuccess(() =>
                    model.generateContent([`(@${m.sender.split("@")[0]}) ${conn.getName(m.sender)}: ${prompt}`, image])
                );

                const modelResponse = {
                    role: "model",
                    parts: [{ text: await cleanText(result.response.text()) }],
                };

                await conn.geminiGrub[m.chat].history.push(userMessage, modelResponse);
            } else {
                const userMessage = {
                    role: "user",
                    parts: [{ text: `(@${m.sender.split("@")[0]}) ${conn.getName(m.sender)}: ${processedText}` }],
                };

                result = await retryUntilSuccess(() =>
                    chatSession.sendMessage(`(@${m.sender.split("@")[0]}) ${conn.getName(m.sender)}: ${processedText}`)
                );

                const modelResponse = {
                    role: "model",
                    parts: [{ text: await cleanText(result.response.text()) }],
                };

                await conn.geminiGrub[m.chat].history.push(userMessage, modelResponse);
            }

            const responseText = await cleanText(result.response.text());

            await conn.reply(m.chat, responseText, m, {
                contextInfo: {
                    mentionedJid: conn.parseMention(responseText),
                    groupMentions: [],
                    externalAdReply: {
                        title: "[ AI ] Lucy Maeril",
                        body: "Created by Mephistod",
                        thumbnailUrl: conn.geminiGrub[m.chat].pictM,
                        sourceUrl: "",
                        mediaType: 1,
                        renderLargerThumbnail: false,
                    },
                },
            });

            // Check for warn command in the response after sending the reply
            const warnRegex = /\.warn\s+@(\d+)/;
            const match = responseText.match(warnRegex);
            
            if (match) {
                const phoneNumber = match[1];
                const whatsappId = `${phoneNumber}@s.whatsapp.net`;
                await warnMember(whatsappId);
            }
        };

        await processRequest();
    } catch (error) {
        console.error(error);
        m.reply("Terjadi kesalahan setelah 10 percobaan. Silakan coba lagi nanti.");
    }
};

handler.help = ["autoai"].map((a) => a + " *[on/off]*");
handler.tags = ["ai", "cai"];
handler.command = ["autoai"];
handler.admin = true;
handler.group = true;
module.exports = handler;

async function uploadFile(input, mimeType, displayName) {
  const fileManager = new GoogleAIFileManager(process.env.GEMINI_API_KEY);
  
  // Handle different input types
  let buffer;
  if (Buffer.isBuffer(input)) {
    buffer = input;
  } else if (typeof input === 'string') {
    const fs = require("fs");
    buffer = await fs.readFileSync(input);
  } else {
    throw new Error('Input must be either a file path (string) or a Buffer');
  }
  
  // Generate boundary
  const boundary = '----WebKitFormBoundary' + Math.random().toString(36).substring(2);
  
  // Create body
  let body = '';
  
  // Add metadata
  body += `--${boundary}\r\n`;
  body += 'Content-Type: application/json\r\n\r\n';
  body += JSON.stringify({
    file: {
      mimeType: mimeType,
      displayName: displayName || 'file'
    }
  });
  body += '\r\n';
  
  // Add file content
  body += `--${boundary}\r\n`;
  body += `Content-Type: ${mimeType}\r\n`;
  body += `Content-Disposition: form-data; name="file"; filename="${displayName || 'file'}"\r\n\r\n`;
  
  // Convert and concatenate buffers
  const bodyStart = Buffer.from(body, 'utf8');
  const bodyEnd = Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8');
  const multipartBody = Buffer.concat([bodyStart, buffer, bodyEnd]);
  
  // Upload
  const response = await fetch(
    `https://generativelanguage.googleapis.com/upload/v1beta/files?uploadType=multipart&key=${fileManager.apiKey}`,
    {
      method: "POST",
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Accept': 'application/json'
      },
      body: multipartBody
    }
  );
  
  const uploadResponse = await response.json();
  
  if (!response.ok) {
    throw new Error(`Upload failed: ${JSON.stringify(uploadResponse)}`);
  }
  
  return uploadResponse;
}