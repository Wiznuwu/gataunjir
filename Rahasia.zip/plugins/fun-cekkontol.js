let handler = async (m, { conn, command, text }) => {
	
    if (!text) return  m.reply('Namanya Tolol!')
	const number = Math.floor(Math.random() * 50) + 1;
  conn.reply(m.chat, `
╭━━━━°「 *Kontol ${text}* 」°
┃
┊• Nama : ${text}
┃• Kontol : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• True : ${pickRandom(['perjaka','ga perjaka','udah pernah dimasukin','masih ori','jumbo'])}
┃• jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
┊• Ukuran : ${pickRandom([number])}cm
╰═┅═━––––––๑
`.trim(), m)
}
handler.help = ['cekkontol *[nama]*']
handler.tags = ['fun']
handler.command = ["cekkontol"]
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}