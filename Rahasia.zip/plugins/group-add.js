const {
  default: makeWASocket,
  BaileysEventMap,
  BinaryNode,
  DisconnectReason,
  downloadMediaMessage,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  generateWAMessageFromContent,
  getBinaryNodeChild,
  jidDecode,
  makeCacheableSignalKeyStore,
  MessageGenerationOptionsFromContent,
  proto,
  toBuffer,
  WAMediaUpload,
  WAMessageStubType
  } = require("@whiskeysockets/baileys");


let handler = async (m, { text, conn, isOwner, isAdmin, args }) => {
async function sendAcceptInviteV4(jid, node, participants, caption = "Invitation to join my WhatsApp group") {
    if (!jid.endsWith("g.us")) throw new TypeError("Invalid jid")
    const result = getBinaryNodeChild(node, "add_request")
    const inviteCode = result.attrs.code
    const inviteExpiration = result.attrs.expiration    
    const groupName = await conn.getName(jid)

    const content = proto.Message.fromObject({
      groupInviteMessage: proto.Message.GroupInviteMessage.fromObject({
        inviteCode,
        inviteExpiration,
        groupJid: jid,
        groupName: groupName,
        caption
      })
    })

    const waMessage = generateWAMessageFromContent(participants, content, {
      userJid: conn.decodeJid(conn.user.id),
      ephemeralExpiration: 3 * 24 * 60 * 60
    })

    process.nextTick(() => conn.upsertMessage(waMessage, "append"))
    await conn.relayMessage(participants, waMessage.message, {
      messageId: waMessage.key.id,
      cachedGroupMetadata: (jid) => database.getGroupMetadata(jid)
    })
    return waMessage
  }
let blockwwww = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

const members = await conn.onWhatsApp(blockwwww)
      const member = members[0]
      
      if (!members.length || !member.exists) throw "Masukan nomor WhatsApp yang valid!"

 const add = (await conn.groupParticipantsUpdate(m.chat, [blockwwww], 'add'))[0]
      if (add.status === "403") {
        await sendAcceptInviteV4(m.chat, add.content, blockwwww)
         m.reply("Berhasil mengirim undangan untuk bergabung ke grub")
      } else {
      m.reply("done")
      }
    };
    
handler.help = ["add"].map((a) => a + " *[reply/tag user]*");
handler.tags = ["group"];
handler.command = ["add"];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

handler.register = true;
module.exports = handler;