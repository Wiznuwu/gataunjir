let handler = async (m, { conn, isOwner, text, isAdmin }) => {
  let who;
  if (m.isGroup) {
    if (isOwner)
      who = m.mentionedJid[0]
        ? m.mentionedJid[0]
        : m.quoted
          ? m.quoted.sender
          : text
            ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
            : m.chat;
    else who = m.chat;
  } else {
    who = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : m.chat;
  }

  try {
    if (who.endsWith("g.us")) global.db.data.chats[who].isBanned = false;
    else global.db.data.users[who].banned = false;
    m.reply(
      `<Berhasil unban!>\n_Makima-Bot Aktif Dichat ${(await conn.getName(who)) == undefined ? "ini" : await conn.getName(who)}._`,
    );
  } catch (e) {
    throw `Gagal`;
  }
};
handler.help = ["unbanchat"];
handler.tags = ["owner"];
handler.command = /^(unbanchat)$/i;
handler.admin = false;
handler.rowner = true;
handler.register = true;
module.exports = handler;