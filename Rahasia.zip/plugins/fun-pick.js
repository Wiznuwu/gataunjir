let handler = async (m, { conn, command, usedPrefix, text }) => {
  	if (!text) return m.reply(`Pllih untuk apa?\nExample: .pick idiot`)
             const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat)
                 .catch((e) => {}) : ""
             const participants = m.isGroup ? await groupMetadata.participants : ""
             let member = participants.map((u) => u.id)
             let me = m.sender
             let xeonshimts = member[Math.floor(Math.random() * member.length)]
m.reply(`Yang paling *${text}* disini adalah *@${xeonshimts.split("@")[0]}*`)
};
handler.help = ["pick"];
handler.tags = ["fun"];
handler.command = ["pick"];
handler.register = true;
module.exports = handler;