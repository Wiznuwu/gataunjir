async function repcs(conn, m, pesan) {
  const a = {
    contextInfo: {
      mentionedJid: conn.parseMention(pesan),
      groupMentions: [],
      isForwarded: true,
      externalAdReply: {
        title: `[ CASINO ]`,
        body: "mari berjudi",
        thumbnailUrl: 'https://files.catbox.moe/6tl41s.jpg',
        sourceUrl: "https://whatsapp.com/channel/0029VaVGWDa8V0teNLJGWF0e",
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  };
  conn.reply(m.chat, pesan, m, a);
}

async function repcs1(conn, m, pesan) {
  const a = {
    contextInfo: {
      mentionedJid: conn.parseMention(pesan),
      groupMentions: [],
      isForwarded: true,
      externalAdReply: {
        title: `[ BANDAR ] Lonte Casino`,
        body: "mari berjudi",
        thumbnailUrl: 'https://files.catbox.moe/ubzo4t.jpg',
        sourceUrl: "https://whatsapp.com/channel/0029VaVGWDa8V0teNLJGWF0e",
        mediaType: 1,
        renderLargerThumbnail: false,
      },
    },
  };
  conn.reply(m.chat, pesan, m, a);
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  conn.casino = conn.casino || {}
  switch (args[0]?.toLowerCase()) {
    case 'create': {
      if (conn.casino[m.chat]) return repcs(conn, m, '🎲 Masih ada room casino yang berlangsung!')
      
      conn.casino[m.chat] = {
        roomId: Math.random().toString(36).substring(7),
        creator: m.sender,
        participants: [m.sender],
        bets: {},
        numbers: {},
        totalPot: 0,
        gameStarted: false,
        betPhase: false,
        roundCount: 0
      }
      
      return repcs(conn, m, `🎲 Room casino berhasil dibuat!\nID: ${conn.casino[m.chat].roomId}\nGunakan *${usedPrefix}cs join* untuk bergabung`)
    }
    
    case 'join': {
      if (!conn.casino[m.chat]) return repcs1(conn, m, '🎲 Tidak ada room casino yang tersedia!')
      if (conn.casino[m.chat].participants.includes(m.sender)) return repcs1(conn, m, '🎲 Kamu sudah bergabung di room ini!')
      if (conn.casino[m.chat].gameStarted) return repcs1(conn, m, '🎲 Permainan sudah dimulai!')
      if (conn.casino[m.chat].participants.length >= 10) return repcs1(conn, m, '🎲 Room sudah penuh!')
      
      const userMoney = db.data.users[m.sender].money || 0
      const userBank = db.data.users[m.sender].bank || 0
      
      if (userMoney + userBank < 100000000) return repcs1(conn, m, '🎲 Kamu harus memiliki minimal 100jt (kombinasi uang dan bank) untuk bergabung!')
      
      conn.casino[m.chat].participants.push(m.sender)
      return repcs(conn, m, `🎲 Berhasil bergabung ke room casino!\nJumlah player: ${conn.casino[m.chat].participants.length}`)
    }

    case 'out': {
      if (!conn.casino[m.chat]) return repcs1(conn, m, '🎲 Tidak ada room casino yang tersedia!')
      if (!conn.casino[m.chat].participants.includes(m.sender)) return repcs1(conn, m, '🎲 Kamu tidak terdaftar dalam permainan!')
      if (conn.casino[m.chat].gameStarted) return repcs1(conn, m, '🎲 Tidak bisa keluar saat permainan berlangsung!')
      
      conn.casino[m.chat].participants = conn.casino[m.chat].participants.filter(p => p !== m.sender)
      
      if (conn.casino[m.chat].participants.length === 0) {
        conn.casino[m.chat] = null
        return repcs(conn, m, '🎲 Room casino ditutup karena tidak ada pemain!')
      }
      
      if (m.sender === conn.casino[m.chat].creator && conn.casino[m.chat].participants.length > 0) {
        conn.casino[m.chat].creator = conn.casino[m.chat].participants[0]
      }
      
      return repcs(conn, m, `🎲 Berhasil keluar dari room casino!\nJumlah player: ${conn.casino[m.chat].participants.length}/5`)
    }
    
    case 'start': {
      if (!conn.casino[m.chat]) return repcs(conn, m, '🎲 Tidak ada room casino yang tersedia!')
      if (m.sender !== conn.casino[m.chat].creator) return repcs1(conn, m, '🎲 Hanya pembuat room yang dapat memulai permainan!')
      if (conn.casino[m.chat].gameStarted) return repcs1(conn, m, '🎲 Permainan sudah dimulai!')
      if (conn.casino[m.chat].participants.length < 2) return repcs1(conn, m, '🎲 Minimal 2 pemain untuk memulai permainan!')
      
      conn.casino[m.chat].gameStarted = true
      conn.casino[m.chat].betPhase = true
      conn.casino[m.chat].roundCount++
      
      const duration = conn.casino[m.chat].participants.length <= 7 ? 60000 : 90000 // 1 or 1.5 minutes
      
      repcs1(conn, m, `🎲 Permainan dimulai!\nRonde ke-${conn.casino[m.chat].roundCount}\nWaktu betting: ${duration/60000} menit\nGunakan *${usedPrefix}cs bet [jumlah] [angka]*\nAngka untuk taruhan: 1-20\nMinimal bet: 5.000.000`)
      
      setTimeout(() => endBettingPhase(conn, m), duration)
    }
    
    case 'bet': {
      if (!conn.casino[m.chat]) return repcs(conn, m, '🎲 Tidak ada room casino yang tersedia!')
      if (!conn.casino[m.chat].gameStarted) return repcs1(conn, m, '🎲 Permainan belum dimulai!')
      if (!conn.casino[m.chat].betPhase) return repcs1(conn, m, '🎲 Fase betting telah berakhir!')
      if (!conn.casino[m.chat].participants.includes(m.sender)) return repcs1(conn, m, '🎲 Kamu tidak terdaftar dalam permainan!')
      if (conn.casino[m.chat].bets[m.sender]) return repcs1(conn, m, '🎲 Kamu sudah melakukan betting!')
      
      const betAmount = parseInt(args[1])
      const betNumber = parseInt(args[2])
      
      if (!betAmount || !betNumber) return repcs1(conn, m, '🎲 Format: .cs bet [jumlah] [angka]')
      if (betNumber < 1 || betNumber > 20) return m.reply('🎲 Angka harus antara 1-20!')
      
      // Minimum bet requirement of 5jt
      const minBet = 5000000
      const previousBet = Object.values(conn.casino[m.chat].bets)[0]
      const requiredBet = previousBet ? Math.max(previousBet, minBet) : minBet
      
      if (betAmount < requiredBet) return repcs1(conn, m, `🎲 Bet minimal adalah ${requiredBet}!`)
      
      const userMoney = db.data.users[m.sender].money || 0
      if (betAmount > userMoney) return repcs1(conn, m, '🎲 Uang tidak cukup!')
      
      db.data.users[m.sender].money -= betAmount
      conn.casino[m.chat].bets[m.sender] = betAmount
      conn.casino[m.chat].numbers[m.sender] = betNumber
      conn.casino[m.chat].totalPot += betAmount
      
      return repcs1(conn, m, `🎲 Berhasil betting ${betAmount} pada angka ${betNumber}!`)
    }
    
    case 'delete': {
      if (!conn.casino[m.chat]) return repcs(conn, m, '🎲 Tidak ada room casino yang tersedia!')
      if (m.sender !== conn.casino[m.chat].creator) return repcs1(conn, m, '🎲 Hanya pembuat room yang dapat menghapus permainan!')
      if (conn.casino[m.chat].gameStarted) return repcs1(conn, m, '🎲 Permainan sudah dimulai!')
      delete conn.casino[m.chat]
      return repcs(conn, m, `🎲 Sukses menghapus room!`)
    }
      
    default:
      return repcs(conn, m, `🎲 Casino Game Commands:
• ${usedPrefix}cs create - Buat room
• ${usedPrefix}cs join - Bergabung ke room
• ${usedPrefix}cs start - Mulai permainan
• ${usedPrefix}cs bet [jumlah] [angka] - Pasang taruhan
• ${usedPrefix}cs out - Keluar dari room
• ${usedPrefix}cs delete - Menghapus room`)
  }
}

async function endBettingPhase(conn, m) {
  if (!conn.casino[m.chat] || !conn.casino[m.chat].betPhase) return
  
  conn.casino[m.chat].betPhase = false
  
  const winningNumber = Math.floor(Math.random() * 20) + 1
  
  const differences = Object.entries(conn.casino[m.chat].numbers).map(([sender, number]) => ({
    sender,
    diff: Math.abs(number - winningNumber)
  })).sort((a, b) => a.diff - b.diff)
  
  const winners = differences.filter(entry => entry.diff === differences[0].diff).slice(0, 3)
  const winAmount = Math.floor(conn.casino[m.chat].totalPot / winners.length)
  
  // Get non-betting players and calculate penalty
  const nonBettingPlayers = conn.casino[m.chat].participants.filter(player => !conn.casino[m.chat].bets[player])
  const firstBet = Object.values(conn.casino[m.chat].bets)[0] || 5000000 // Default to 5jt if no bets
  const penalty = Math.floor(firstBet / 2)
  
  // Calculate total penalty collection
  let totalPenaltyCollected = 0
  
  // Process penalties and collect them
  nonBettingPlayers.forEach(player => {
    const userMoney = db.data.users[player].money || 0
    
    // Apply penalty and allow negative balance
    db.data.users[player].money = userMoney - penalty
    totalPenaltyCollected += penalty
  })
  
  // Distribute collected penalties equally among all players
  const penaltyShare = Math.floor(totalPenaltyCollected / conn.casino[m.chat].participants.length)
  conn.casino[m.chat].participants.forEach(player => {
    db.data.users[player].money += penaltyShare
  })
  
  // Distribute winnings
  winners.forEach(({sender}) => {
    db.data.users[sender].money += winAmount
  })
  
  // Calculate losses for each player
  const losers = conn.casino[m.chat].participants.filter(player => 
    !winners.some(w => w.sender === player) && conn.casino[m.chat].bets[player]
  )
  
  // Prepare result text
  let resultText = `🎲 Casino Game Results - Ronde ${conn.casino[m.chat].roundCount}\nWinning number: ${winningNumber}\n\n`
  
  resultText += `Winners:`
  winners.forEach(({sender}, i) => {
    resultText += `\n${i+1}. @${sender.split('@')[0]} - Won ${winAmount}`
  })
  
  if (losers.length > 0) {
    resultText += `\n\nLosers:`
    losers.forEach((sender) => {
      resultText += `\n@${sender.split('@')[0]} - Lost ${conn.casino[m.chat].bets[sender]}`
    })
  }
  
  if (nonBettingPlayers.length > 0) {
    resultText += `\n\nNon-betting players (Penalty ${penalty}):`
    nonBettingPlayers.forEach((sender) => {
      resultText += `\n@${sender.split('@')[0]}`
    })
  }
  
  resultText += `\n\nPenalty terkumpul: ${totalPenaltyCollected}`
  resultText += `\nBagi hasil penalty: +${penaltyShare} per player`
  
  // Reset round data
  conn.casino[m.chat].bets = {}
  conn.casino[m.chat].numbers = {}
  conn.casino[m.chat].totalPot = 0
  conn.casino[m.chat].gameStarted = false
  conn.casino[m.chat].betPhase = false
  
  resultText += `\n\nPermainan selesai! Gunakan command .cs start untuk memulai ronde baru!`
  
  return m.reply(resultText)
}

handler.help = ["casino"].map((a) => a + " *[info]*")
handler.tags = ["rpg"]
handler.command = ["casino", "cs"]
handler.register = true

module.exports = handler