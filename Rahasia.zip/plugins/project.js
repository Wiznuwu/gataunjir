let handler = async (m, { text, usedPrefix, command }) => {
const PixivApi = require('pixiv-api-client');
const pixiv = new PixivApi();
pixiv.tokenRequest('code', 'codeVerfier')().then(() => {
  return pixiv.searchIllust("yuki").then(json => {
	console.log(json);
	return pixiv.requestUrl(json.next_url);
  }).then(json => {
	console.log(json); //next results
  });
});
};
handler.command = ["project"];
module.exports = handler;