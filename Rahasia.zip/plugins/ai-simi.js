const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    throw `*• Example:* ${usedPrefix + command} *[question]*`;
  }
  try {
    const simiResponse = await Func.fetchJson(
      `https://api.betabotz.eu.org/api/search/simisimi?query=${text}&apikey=${global.apibeta}`,
    );
    const simiData = await simiResponse.result
    let hasil = ` *[ 💬 ]* ${simiData}`;
    m.reply(hasil);
  } catch (e) {
    throw "Maaf, aku tidak mengerti";
  }
};

handler.help = ["simi", "chatbot"].map((a) => a + " *[question]*");
handler.tags = ["ai"];
handler.command = ["simi", "chatbot"];
handler.premium = false;

module.exports = handler;