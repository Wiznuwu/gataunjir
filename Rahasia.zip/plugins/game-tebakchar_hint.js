let handler = async (m, { conn }) => {
  conn.tebakchara = conn.tebakchara ? conn.tebakchara : {};
  let id = m.chat;
  if (!(id in conn.tebakchara)) throw false;
  let json = conn.tebakchara[id][1];
  conn.reply(
    m.chat,
    "```" + json.hasil.result.name.replace(/[AIUEOaiueo]/gi, "_") + "```",
    m,
  );
};
handler.command = ["hime"]

handler.limit = true;

module.exports = handler;