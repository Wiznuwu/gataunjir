let fs = require("fs");

let handler = async (m, { conn, text, command, isAdmin, isOwner }) => {
  let directory = "./database/list.json";
  if (!fs.existsSync(directory)) fs.writeFileSync(directory, JSON.stringify({})); // Buat file jika belum ada

  let jsonData = fs.readFileSync(directory);
  let existingData = JSON.parse(jsonData);
  let user = m.sender; // User ID pengirim pesan
  let chat = m.chat; // Chat ID (individu atau grup)

  switch (command) {
    case "addlist": {
      if (!isAdmin && !isOwner) throw "Fitur khusus admin";
      // Cek apakah ada media atau teks yang direply
      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || "";
      let mtype = q.mtype;

      // Validasi input
      if (!mime && mtype !== "extendedTextMessage") return m.reply("*• Hanya mendukung sticker, image, atau text.*");
      if (!text || !m.quoted) return m.reply("*• Example :* .addlist salam [reply media/text]");

      // Buat entri baru jika belum ada untuk chat tertentu
      if (!existingData[chat]) existingData[chat] = {};
      if (!existingData[chat][user]) existingData[chat][user] = {};

      // Cek apakah teks sudah ada untuk pengguna di chat tersebut
      if (existingData[chat][user][text.toLowerCase()]) {
        return m.reply(`*• '${text}' sudah ada dalam database untuk grup ini.*`);
      }

      let mediaData = null;
      if (mime) {
        // Download media
        let media = await q.download();
        let link = await Uploader.catbox(media);
        mediaData = {
          url: link,
          stiker: mtype === "stickerMessage",
        };
      } else if (mtype === "extendedTextMessage") {
        mediaData = q.text || ""; // Simpan teks yang direply
      }

      // Tambahkan entri untuk pengguna di chat tersebut
      existingData[chat][user][text.toLowerCase()] = mediaData || "null";
      fs.writeFileSync(directory, JSON.stringify(existingData, null, 2));

      m.reply(`*• Berhasil menambahkan '${text}' ke database untuk grup ini.*`);
      break;
    }

    case "dellist": {
      let owners = global.owner || [];
      let isGlobalOwner = owners.some(owner => m.sender.includes(owner));

      if (!isAdmin && !isGlobalOwner) throw "Fitur khusus admin";

      if (!text) return m.reply("*• Example :* .dellist salam");
      if (!existingData[chat]) return m.reply("*• Tidak ada data untuk grup ini.*");

      // Cari kata di database tanpa memperhatikan kapitalisasi
      let keyToDelete = null;
      for (let userId in existingData[chat]) {
        let userData = existingData[chat][userId];
        for (let key in userData) {
          if (key.toLowerCase() === text.toLowerCase()) {
            keyToDelete = { userId, key };
            break;
          }
        }
        if (keyToDelete) break;
      }

      if (!keyToDelete) {
        return m.reply(`*• '${text}' tidak ditemukan dalam database untuk grup ini.*`);
      }

      // Hapus entri
      delete existingData[chat][keyToDelete.userId][keyToDelete.key];

      // Hapus user dari chat jika sudah tidak ada entri
      if (Object.keys(existingData[chat][keyToDelete.userId]).length === 0) {
        delete existingData[chat][keyToDelete.userId];
      }

      // Hapus chat dari database jika sudah tidak ada user
      if (Object.keys(existingData[chat]).length === 0) {
        delete existingData[chat];
      }

      fs.writeFileSync(directory, JSON.stringify(existingData, null, 2));
      m.reply(`*• Berhasil menghapus '${text}' dari database untuk grup ini.*`);
      break;
    }

    case "list": {
      if (!existingData[chat]) return m.reply("*• Tidak ada data untuk grup ini.*");

      let chatData = existingData[chat];
      let listText = `*• List untuk grup ini:*`;

      for (let userId in chatData) {
        let userEntries = Object.keys(chatData[userId]); // Ambil semua kata yang disimpan
        if (userEntries.length) {
          listText += `\n\n*• Data milik @${userId.split("@")[0]}:*\n- ${userEntries.join("\n- ")}`;
        }
      }

      m.reply(listText);
      break;
    }

    default:
      return m.reply("*• Command tidak dikenal.*");
  }
};

handler.help = ["addlist *[reply media/text]*", "dellist *[query]*", "list"];
handler.tags = ["tools"];
handler.command = ["addlist", "dellist", "list"];
handler.group = true;

module.exports = handler;