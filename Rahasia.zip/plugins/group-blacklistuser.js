let handler = async (m, { text, command, conn, isOwner, isAdmin, args, participants}) => {
  let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";
  switch(command) {
  
  case 'blacklist': {
  
  if (args[0] === 'on' || args[0] === 'off') {
     let asli 
     if (args[0] === 'on') {
     asli = true
     }
     if (args[0] === 'off') {
     asli = false  
     }
     db.data.chats[m.chat].listhitam = asli
     m.reply(asli ? "Sukses mengaktifkan Blacklist di grub ini" : "Sukses mematikan Blacklist di grub ini")
     return 
  } else {  
  if (m.quoted) {
  if (!db.data.chats[m.chat].listhitam) throw "Aktifkan blacklist terlebih dahulu untuk grub ini!\n\nExample .blacklist on/off"
    if (m.quoted.sender === ownerGroup || m.quoted.sender === conn.user.jid)
      return;
    let usr = m.quoted.sender;
    if (!db.data.chats[m.chat].daftarhitam.includes(usr)) {
    db.data.chats[m.chat].daftarhitam.push(usr)
    await conn.groupParticipantsUpdate(m.chat, [usr], "remove");
    m.reply("Sukses menambahkan beliau di list hitam!")
    } else {
    await conn.groupParticipantsUpdate(m.chat, [usr], "remove");    
    m.reply("Sukses menambahkan beliau di list hitam!")
    }
    return;
  }
  
  if (!m.mentionedJid[0]) throw `*• Example :* .blacklist *[reply/tag use]*`;
  
  if (!db.data.chats[m.chat].listhitam) throw "Aktifkan blacklist terlebih dahulu untuk grub ini!\n\nExample .blacklist on/off"
  let users = m.mentionedJid.filter(
    (u) => !(u == ownerGroup || u.includes(conn.user.jid)),
  );
  
  for (let user of users) {
    if (user.endsWith("@s.whatsapp.net"))
    if (!db.data.chats[m.chat].daftarhitam.includes(user)) {
      db.data.chats[m.chat].daftarhitam.push(user)
      await conn.groupParticipantsUpdate(m.chat, [user], "remove");
      m.reply("Sukses menambahkan beliau di list hitam!")
      }
      await conn.groupParticipantsUpdate(m.chat, [user], "remove");
      m.reply("Sukses menambahkan beliau di list hitam!")
   } 
 }
}
   break;
   case "unblacklist": {
    let user = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (db.data.chats[m.chat].daftarhitam.includes(user)) {
    db.data.chats[m.chat].daftarhitam.splice(db.data.chats[m.chat].daftarhitam.indexOf(user), 1);
    m.reply("Sukses menghapus beliau dari list hitam!")
    } else {
    m.reply("beliau tidak ada di daftar hitam")
    }
   } 
   break;
   }
 }

handler.help = ["blacklist", "unblacklist"].map((a) => a + " *[reply/tag]*");
handler.tags = ["group"];
handler.command = ["blacklist", "unblacklist"];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

handler.register = true;
module.exports = handler;