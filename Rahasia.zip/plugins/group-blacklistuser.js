let handler = async (m, { conn, command, args, text }) => {
  // Initialize database
  let chat = global.db.data.chats[m.chat];
  if (!chat) global.db.data.chats[m.chat] = {};
  if (!chat.daftarhitam) chat.daftarhitam = [];
  if (typeof chat.listhitam === "undefined") chat.listhitam = false;

  // Helper function to add user to blacklist
  const addToBlacklist = async (jid) => {
    if (!chat.daftarhitam.includes(jid)) {
      chat.daftarhitam.push(jid);
      await conn.groupParticipantsUpdate(m.chat, [jid], "remove");
      return true;
    }
    return false;
  };

  // Helper function to remove user from blacklist
  const removeFromBlacklist = (number) => {
    const normalizedNumber = number.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
    const index = chat.daftarhitam.indexOf(normalizedNumber);
    if (index !== -1) {
      chat.daftarhitam.splice(index, 1);
      return true;
    }
    return false;
  };

  // Handle different command cases
  switch (true) {
    // Case 1: .blacklist on/off
    case args[0]?.toLowerCase() === "on" || args[0]?.toLowerCase() === "off": {
      const state = args[0].toLowerCase() === "on";
      chat.listhitam = state;
      return m.reply(`*[ Blacklist Feature ]*\n\nBlacklist feature has been ${
        state ? "enabled" : "disabled"
      } for this group.`);
    }

    // Case 2: .unblacklist <number>
    case command === "unblacklist": {
      if (!args[0]) return m.reply("*Please provide the phone number to remove from blacklist*\nExample: .unblacklist 6281234567890");
      
      const success = removeFromBlacklist(args[0]);
      return m.reply(success 
        ? "*Success!* User has been removed from blacklist."
        : "*Failed!* User was not found in blacklist.");
    }

    // Case 3: .blacklist (with reply)
    case command === "blacklist" && m.quoted: {
      if (!chat.listhitam) return m.reply("*Blacklist feature is currently disabled!*\nUse '.blacklist on' to enable it first.");
      
      const quotedUser = m.quoted.sender;
      if (quotedUser === global.owner[0] + "@s.whatsapp.net" || quotedUser === conn.user.jid) {
        return m.reply("*Cannot blacklist the group owner or bot!*");
      }

      const success = await addToBlacklist(quotedUser);
      return m.reply(success
        ? "*Success!* User has been added to blacklist and removed from group."
        : "*Note:* User is already in blacklist.");
    }

    // Case 4: .blacklist @tag
    case command === "blacklist" && m.mentionedJid?.length > 0: {
      if (!chat.listhitam) return m.reply("*Blacklist feature is currently disabled!*\nUse '.blacklist on' to enable it first.");
      
      const ownerJid = global.owner[0] + "@s.whatsapp.net";
      const results = [];

      for (const user of m.mentionedJid) {
        if (user === ownerJid || user === conn.user.jid) {
          results.push(`❌ @${user.split("@")[0]} (Cannot blacklist owner/bot)`);
          continue;
        }
        
        const success = await addToBlacklist(user);
        results.push(`${success ? "✅" : "⚠️"} @${user.split("@")[0]}`);
      }

      return m.reply(`*[ Blacklist Results ]*\n\n${results.join("\n")}`);
    }

    // Default case: Show usage
    default: {
      return m.reply(`*[ Blacklist Feature Usage ]*

1️⃣ Toggle blacklist feature:
*.blacklist on*
*.blacklist off*

2️⃣ Add user to blacklist:
*.blacklist* (reply to message)
*.blacklist @tag*

3️⃣ Remove from blacklist:
*.unblacklist <number>*
Example: .unblacklist 6281234567890

Note: Blacklisted users will be automatically removed if they try to rejoin the group.`);
    }
  }
};

handler.help = [
  "blacklist *on/off*",
  "blacklist *@tag*",
  "blacklist *(reply)*",
  "unblacklist *number*"
];
handler.tags = ["group", "admin"];
handler.command = ["blacklist", "unblacklist"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.register = true;

module.exports = handler;