const xppermoney = 1;
let handler = async (m, { conn, command, args }) => {
  let count = command.replace(/^narik|tarik/i, "");
  count = count
    ? /all/i.test(count)
      ? Math.floor(global.db.data.users[m.sender].bank / xppermoney)
      : parseInt(count)
    : args[0]
      ? parseInt(args[0])
      : 1;
  count = Math.max(1, count);
  if (global.db.data.users[m.sender].bank >= xppermoney * count) {
    global.db.data.users[m.sender].bank -= xppermoney * count;
    global.db.data.users[m.sender].money += count;
    m.reply(`-Rp.${xppermoney * count} 💳\n+Rp.${count} 💹\n\n[ ! ] Succes menarik uang !`);
  } else
    m.reply(`[❗] Uang anda tidak mencukupi untuk menarik ${count} !`);
};
handler.help = ["narik <jumlah>"];
handler.tags = ["rpg"];
handler.command = ["narik", "tarik"];

handler.admin = false;
handler.botAdmin = false;

handler.fail = null;
handler.exp = 0;


module.exports = handler;
