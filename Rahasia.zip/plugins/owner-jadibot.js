let baileys = require("@whiskeysockets/baileys");
let {
  useMultiFileAuthState,
  DisconnectReason,
  makeInMemoryStore,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  PHONENUMBER_MCC,
} = baileys;
let { Boom } = require("@hapi/boom");
let NodeCache = require("node-cache");
let Pino = require("pino");
let simple = require("../lib/simple");
let fs = require("fs");
let path = require("path");

// Store active connections in a persistent file
const CONNECTIONS_FILE = './database/jadibot/active_connections.json';

// Initialize or load active connections
let activeConnections = {};
if (fs.existsSync(CONNECTIONS_FILE)) {
  try {
    activeConnections = JSON.parse(fs.readFileSync(CONNECTIONS_FILE, 'utf8'));
  } catch (error) {
    console.error('Error loading active connections:', error);
    activeConnections = {};
  }
}

// Save active connections to file
const saveConnections = () => {
  fs.writeFileSync(CONNECTIONS_FILE, JSON.stringify(activeConnections, null, 2));
};

if (global.ak instanceof Array) console.log();
else global.ak = [];

let handler = async (m, { conn, args, usedPrefix, command, isOwner, text }) => {
  let ak = global.conn;
  let user = global.db.data.users[m.sender];

  // Create jadibot directory if it doesn't exist
  const jadibotDir = "./database/jadibot";
  if (!fs.existsSync(jadibotDir)) {
    fs.mkdirSync(jadibotDir, { recursive: true });
  }

  let authFile = path.join(jadibotDir, m.sender.split("@")[0]);
  let isInit = !fs.existsSync(authFile);

  // Check if connection already exists
  if (activeConnections[m.sender] && !isInit) {
    return ak.reply(m.chat, "You already have an active connection. Use .stopclone to disconnect first.");
  }

  let { state, saveCreds } = await useMultiFileAuthState(authFile);
  let msgRetryCounterCache = new NodeCache();

  const config = {
    logger: Pino({ level: "fatal" }).child({ level: "fatal" }),
    printQRInTerminal: false,
    mobile: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(
        state.keys,
        Pino({ level: "fatal" }).child({ level: "fatal" })
      ),
    },
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: true,
    msgRetryCounterCache,
    defaultQueryTimeoutMs: undefined,
  };

  conn = simple.makeWASocket(config);
  let ev = conn.ev;

  if (!conn.authState.creds.registered) {
    setTimeout(async () => {
      let phoneNumber = m.sender.split("@")[0];
      let code = await conn.requestPairingCode(phoneNumber);
      let hasilcode = code?.match(/.{1,4}/g)?.join("-") || code;
      let key = await ak.reply(
        m.chat,
        "*[ System Guide ]* You have received a notification from the device, copy the code below, press the notification button, then paste the code and you will become a temporary bot",
        m
      );
      await ak.reply(m.chat, hasilcode, key);
    }, 3000);
  }

  async function connectionUpdate(update) {
    const { connection, lastDisconnect } = update;
    console.log(update);

    if (connection == "connecting") {
      console.log(connection);
    } else if (connection == "open") {
      ak.reply(m.chat, `*[ System Notice ]* Success Connected To WhatsApp`);
      global.ak.push(conn);
      
      // Save connection state
      activeConnections[m.sender] = {
        authFile,
        timestamp: Date.now()
      };
      saveConnections();
    } else if (connection === "close") {
      let statusCode = new Boom(lastDisconnect?.error)?.output.statusCode;
      
      if (statusCode === DisconnectReason.loggedOut || 
          statusCode === DisconnectReason.badSession) {
        // Remove connection data on logout
        delete activeConnections[m.sender];
        saveConnections();
        if (fs.existsSync(authFile)) {
          fs.rmSync(authFile, { recursive: true, force: true });
        }
        ak.reply(m.chat, '*[ System Notice ]* Session ended. Please scan again.');
      } else {
        // For other disconnect reasons, attempt to reconnect
        console.log("Attempting to reconnect...");
        setTimeout(() => {
          reloadHandler(true);
        }, 3000);
      }
    }
  }

  reloadHandler = function (restatConn) {
    let Handler = require("../handler");
    let handler = require("../handler");
    if (Object.keys(Handler || {}).length) handler = Handler;
    
    if (restatConn) {
      try {
        conn.ws.close();
      } catch {}
      conn = {
        ...conn,
        ...simple.makeWASocket(config),
      };
    }

    if (!isInit) {
      conn.ev.off("messages.upsert", conn.handler);
      conn.ev.off("group-participants.update", conn.onParticipantsUpdate);
      conn.ev.off("connection.update", conn.connectionUpdate);
      conn.ev.off("creds.update", conn.credsUpdate);
    }

    conn.welcome = "Hi, @user!\nWelcome to *@subject* group\n\n@desc";
    conn.bye = "Goodbye @user!";
    conn.spromote = "@user is now admin!";
    conn.sdemote = "@user is no longer admin!";
    conn.handler = handler.handler.bind(conn);
    conn.onParticipantsUpdate = handler.participantsUpdate.bind(conn);
    conn.connectionUpdate = connectionUpdate.bind(conn);
    conn.credsUpdate = saveCreds.bind(conn);

    conn.ev.on("messages.upsert", conn.handler);
    conn.ev.on("group-participants.update", conn.onParticipantsUpdate);
    conn.ev.on("connection.update", conn.connectionUpdate);
    conn.ev.on("creds.update", conn.credsUpdate);
    isInit = false;
    return true;
  };

  reloadHandler();
};

// Add command to stop clone
handler.stopclone = async function(m, { conn }) {
  if (activeConnections[m.sender]) {
    delete activeConnections[m.sender];
    saveConnections();
    if (fs.existsSync(activeConnections[m.sender].authFile)) {
      fs.rmSync(activeConnections[m.sender].authFile, { recursive: true, force: true });
    }
    return conn.reply(m.chat, '*[ System Notice ]* Successfully disconnected your clone session.');
  }
  return conn.reply(m.chat, '*[ System Notice ]* You don\'t have any active clone sessions.');
};

// Function to restore connections on bot restart
handler.restoreConnections = async function() {
  for (const [sender, data] of Object.entries(activeConnections)) {
    if (fs.existsSync(data.authFile)) {
      try {
        // Create new connection with saved auth
        let { state, saveCreds } = await useMultiFileAuthState(data.authFile);
        let msgRetryCounterCache = new NodeCache();
        
        const config = {
          logger: Pino({ level: "fatal" }).child({ level: "fatal" }),
          printQRInTerminal: false,
          mobile: false,
          auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(
              state.keys,
              Pino({ level: "fatal" }).child({ level: "fatal" })
            ),
          },
          browser: ["Ubuntu", "Chrome", "20.0.04"],
          markOnlineOnConnect: true,
          generateHighQualityLinkPreview: true,
          msgRetryCounterCache,
          defaultQueryTimeoutMs: undefined,
        };

        let conn = simple.makeWASocket(config);
        reloadHandler.call(conn, true);
        global.ak.push(conn);
      } catch (error) {
        console.error(`Error restoring connection for ${sender}:`, error);
        delete activeConnections[sender];
        saveConnections();
      }
    } else {
      delete activeConnections[sender];
      saveConnections();
    }
  }
};

handler.command = ["clone", "stopclone"];
handler.premium = true;
handler.private = true;
module.exports = handler;