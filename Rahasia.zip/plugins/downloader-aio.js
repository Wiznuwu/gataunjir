const axios = require('axios');
const cheerio = require('cheerio');
let { downloadContentFromMessage } = require("@whiskeysockets/baileys");

async function getActualVideoUrl(downloadUrl) {
    try {
        const response = await axios.get(downloadUrl, {
            maxRedirects: 5,
            validateStatus: function (status) {
                return status >= 200 && status < 400;
            },
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            }
        });

        return response.request.res.responseUrl || downloadUrl;
    } catch (error) {
        console.error('Error getting actual URL:', error);
        throw error;
    }
}

async function downloadFromRetaTube(url) {
    try {
        const prefixResponse = await axios.get('https://retatube.com/api/v1/aio/index?s=retatube.com', {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': 'https://retatube.com/',
                'Origin': 'https://retatube.com'
            }
        });

        const $ = cheerio.load(prefixResponse.data);
        let prefix = $('input#aio-search-box[name="prefix"]').val();

        if (!prefix) {
            const prefixMatch = prefixResponse.data.match(/name="prefix"\s+value="([^"]+)"/);
            if (prefixMatch) {
                prefix = prefixMatch[1];
            } else {
                throw new Error('Prefix not found in response');
            }
        }

        const formData = new URLSearchParams();
        formData.append('prefix', prefix);
        formData.append('vid', url);

        const response = await axios.post(
            'https://retatube.com/api/v1/aio/search',
            formData.toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'text/html, */*; q=0.01',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'HX-Request': 'true',
                    'HX-Target': 'aio-parse-result',
                    'HX-Trigger': 'search-btn',
                    'Origin': 'https://retatube.com',
                    'Referer': 'https://retatube.com/'
                }
            }
        );

        const $result = cheerio.load(response.data);
        const result = {
            title: '',
            description: '',
            videoLinks: [],
            audioLinks: [],
            imageLinks: [] // Added image links array
        };

        $result('.col').each((_, element) => {
            if (!result.title) {
                const title = $result(element).find('strong').first().text();
                result.title = title.replace('Title：', '').trim();
            }

            if (!result.description) {
                const desc = $result(element).find('.description').text();
                result.description = desc.trim();
            }

            $result(element).find('a.button.primary').each((_, linkElement) => {
                const linkUrl = $result(linkElement).attr('href');
                const quality = $result(linkElement).find('span').text().trim();

                if (linkUrl && linkUrl !== 'javascript:void(0);') {
                    const cleanQuality = quality.replace(/\s+/g, ' ').trim();
                    
                    if (cleanQuality.toLowerCase().includes('audio') || cleanQuality.toLowerCase().includes('mp3')) {
                        result.audioLinks.push({ quality: cleanQuality, url: linkUrl });
                    } else if (cleanQuality.toLowerCase().includes('image')) {
                        result.imageLinks.push({ quality: cleanQuality, url: linkUrl });
                    } else {
                        result.videoLinks.push({ quality: cleanQuality, url: linkUrl });
                    }
                }
            });
        });

        // Get actual URLs
        for (let i = 0; i < result.videoLinks.length; i++) {
            const actualUrl = await getActualVideoUrl(result.videoLinks[i].url);
            result.videoLinks[i].url = actualUrl;
        }

        for (let i = 0; i < result.imageLinks.length; i++) {
            const actualUrl = await getActualVideoUrl(result.imageLinks[i].url);
            result.imageLinks[i].url = actualUrl;
        }

        return result;
    } catch (error) {
        console.error('Download error:', error);
        throw error;
    }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Usage: ${usedPrefix + command} [link]\nSupported platforms:\n- YouTube\n- Instagram\n- TikTok\n- Facebook\n- Twitter\n- And many more`;

    m.reply('Processing your request...');
    try {
        const result = await downloadFromRetaTube(text);
        let caption = `*Title*: ${result.title}\n*Description*: ${result.description}`;

        // Handle video content
        if (result.videoLinks.length > 0) {
            try {
                const video = result.videoLinks[0];
                const videoBuffer = await axios.get(video.url, {
                    responseType: 'arraybuffer',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });

                await conn.sendMessage(m.chat, { 
                    video: Buffer.from(videoBuffer.data), 
                    caption: caption 
                }, { quoted: m });
            } catch (videoError) {
                console.error('Video download error:', videoError);
                m.reply('Failed to download video. Trying alternative format...');
            }
        }

        // Handle image content
        if (result.imageLinks.length > 0) {
            try {
                const image = result.imageLinks[0];
                const imageBuffer = await axios.get(image.url, {
                    responseType: 'arraybuffer',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });

                await conn.sendMessage(m.chat, { 
                    image: Buffer.from(imageBuffer.data), 
                    caption: caption 
                }, { quoted: m });
            } catch (imageError) {
                console.error('Image download error:', imageError);
                m.reply('Failed to download image.');
            }
        }

        // If no media was found
        if (result.videoLinks.length === 0 && result.imageLinks.length === 0) {
            await conn.reply(m.chat, "No media found in the provided link.", m);
        }

    } catch (error) {
        console.error(error);
        await conn.reply(m.chat, `Error occurred: ${error.message}`, m);
    }
};

handler.help = ["aio *[all links]*"];
handler.tags = ["downloader"];
handler.command = ["aio"];
handler.limit = true;

module.exports = handler;