const cheerio = require('cheerio');
const PDFDocument = require('pdfkit');
const imageSize = require('image-size');
const fs = require("fs");
const didyoumean2 = require("didyoumean2").default;
const Jimp = require('jimp');
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
conn.doujin = conn.doujin ? conn.doujin : {};
if (!text) throw "> Contoh penggunaan\n.doujin search my landlady noona"
const keyword = text.split(" ")[0];
const data = text.slice(keyword.length + 1);
if (keyword === "search") {
if (!data) throw "masukan judul doujin!"
try {
const baseUrl = 'https://sektedoujin.cc/page/';
const query = `?s=${data}`;
const maxPages = 20;
let komikList = await fetchKomikPages(baseUrl, query, maxPages);
let title = komikList.map((v, index) => `*${index + 1}.* *Title:* ${v.title}`).join("\n\n");
let { key } = await conn.reply(m.chat, title, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "member cuabul",
body: "Created by Mephistod",
thumbnailUrl: "https://i3.wp.com/sektedoujin.cc/wp-content/uploads/2023/02/favicon.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true,
},
},
});
await conn.reply(
m.chat,
`Ketik angka *1 - ${komikList.length}* sesuai dengan pesan di atas`,
null,
);
let timer = setTimeout(() => {
      delete conn.doujin[m.sender];
    }, 100000)
conn.doujin[m.sender] = {
komik: komikList,
pilih: true,
timer
}
} catch {
m.reply("judul yang kamu cari tidak di temukan")
}
} else {
throw "> Contoh penggunaan\n.doujin search my landlady noona"
}
}
handler.before = async (m, { conn }) => {
conn.doujin = conn.doujin ? conn.doujin : {};
if (m.isBaileys) return;
if (!m.text) return;
if (!conn.doujin[m.sender]) return;
if (conn.doujin[m.sender].pilih) {
if (isNaN(m.text) || m.text <= 0 || m.text > conn.doujin[m.sender].komik.length) return;
let pilihan = conn.doujin[m.sender].komik[m.text - 1].link;
let judul = conn.doujin[m.sender].komik[m.text - 1].title;
let chapterLinks = await getChapterList(await Func.fetchJson(pilihan));
let terbalik = chapterLinks.reverse();
let hasil = terbalik.length;
await conn.reply(m.chat, `Anda memilih komik bokep berjudul\n*${judul}*\nSilahlan pilih chapter berapa yang ingin anda download,\nada *${hasil}* chapter yang tersedia.\nsilahkan ketik *1 - ${hasil}* untuk memilih chapter\n\nJika anda ingin membatch anda bisa memilih chapter yang ingin anda batch.\nContoh penggunaan:\nketik *10 20* untuk membtach chapter 10 - 20.\n\nketik *10* untuk memilih chapter 10`, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "member cuabul",
body: "Created by Mephistod",
thumbnailUrl: "https://i3.wp.com/sektedoujin.cc/wp-content/uploads/2023/02/favicon.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true,
},
},
});
conn.doujin[m.sender].pilih = false;
conn.doujin[m.sender].pilihan = terbalik;
conn.doujin[m.sender].judul = judul;
} else {
let range = m.text.split(' ');
if (range.length === 1) {
if (isNaN(range[0])) return;
let chapter = parseInt(range[0]);
if (chapter > conn.doujin[m.sender].pilihan.length) return;
let pilihan = conn.doujin[m.sender].pilihan[chapter - 1].link
let judul = conn.doujin[m.sender].judul;
console.log(pilihan);
let response = await axios.get(pilihan);
m.reply(wait)
try {
const $ = cheerio.load(response.data);
const script = $('script').filter((index, element) => {
return $(element).text().includes('ts_reader.run');
});
const images = [];
const data = script.text().match(/ts_reader\.run\((.*?)\)/)[1];
const jsonData = JSON.parse(data);
const sources = jsonData.sources;
sources.forEach((source) => {
const imagesArray = source.images;
imagesArray.forEach((image) => {
images.push(image);
});
})
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
for (let i = 0; i < images.length; i++) {
const link = images[i];
try {
const buffer = await conn.getBuffer(link);
const dimensions = imageSize(buffer);
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth;
const pageHeight = imgHeight + 100;
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(buffer, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Image ${i + 1}`, 250, 550);
} catch (error) {
console.log(`Error fetching image ${i + 1}: ${error.message}`);
continue;
}
}
const pdfStream = fs.createWriteStream('output.pdf');
pdf.pipe(pdfStream);
pdf.end();
pdfStream.on('finish', () => {
const hasilpdf = fs.readFileSync("output.pdf");
conn.sendMessage(m.chat, { document: hasilpdf, mimetype: "application/pdf", fileName: judul, caption: `chapter ${chapter}` }, { quoted: m });
fs.unlinkSync('output.pdf');
delete conn.doujin[m.sender];
});
} catch {
m.reply("Chapter tidak tersedia");
}
} else if (range.length === 2) {
if (isNaN(range[0]) || isNaN(range[1])) return;
if (range[1] < range[0]) return m.reply("masukan chapter yang valid!\ncontoh: 1 10")
let jumlahan = Math.abs(range[0] - range[1])
console.log(jumlahan)
if (jumlahan > 10) return m.reply("Jumlah tidak bisa lebih dari 10!\ncontoh: 5 15")
try {
m.reply(wait)
let start = parseInt(range[0]);
let end = parseInt(range[1]);
if (start > conn.doujin[m.sender].pilihan.length || end > conn.doujin[m.sender].pilihan.length) return;
let judul = conn.doujin[m.sender].judul;
let images = [];
for (let i = start - 1; i <= end - 1; i++) {
let pilihan = conn.doujin[m.sender].pilihan[i].link;
let response = await axios.get(pilihan)
const $ = cheerio.load(response.data);
const script = $('script').filter((index, element) => {
return $(element).text().includes('ts_reader.run');
});
const data = script.text().match(/ts_reader\.run\((.*?)\)/)[1];
const jsonData = JSON.parse(data);
const sources = jsonData.sources;
sources.forEach((source) => {
const imagesArray = source.images;
imagesArray.forEach((image) => {
images.push(image);
});
})
}
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
for (let i = 0; i < images.length; i++) {
const link = images[i];
try {
const buffer = await conn.getBuffer(link);
const kecilkan = await compressImage(buffer);
const dimensions = imageSize(kecilkan);
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth;
const pageHeight = imgHeight + 100;
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(kecilkan, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Image ${i + 1}`, 250, 550);
} catch (error) {
console.log(`Error fetching image ${i + 1}: ${error.message}`);
continue;
}
}
const pdfStream = fs.createWriteStream('output.pdf');
pdf.pipe(pdfStream);
pdf.end();
pdfStream.on('finish', () => {
const hasilpdf = fs.readFileSync("output.pdf");
conn.sendMessage(m.chat, { document: hasilpdf, mimetype: "application/pdf", fileName: judul, caption: `chapter ${start} - ${end}` }, { quoted: m });
fs.unlinkSync('output.pdf');
delete conn.doujin[m.sender]
})
} catch (error) {
console.log(error)
m.reply("Chapter tidak tersedia")
}
}
}
}
handler.help = ["doujin"].map((a) => a + " *[judul]*");
handler.tags = ["downloader", "premium"];
handler.command = ["doujin"];
handler.premium = true;
handler.register = true;
module.exports = handler;

function compressImage(buffer) {
return new Promise((resolve, reject) => {
Jimp.read(buffer)
.then(image => {
image.quality(15); // adjust the quality to reduce file size
return image.getBufferAsync(Jimp.MIME_JPEG);
})
.then(compressedBuffer => {
resolve(compressedBuffer);
})
.catch(err => {
reject(err);
});
});
}

async function fetchKomikPages(baseUrl, query, maxPages) {
const komikList = [];
for (let i = 1; i <= maxPages; i++) {
const url = `${baseUrl}${i}${query}`;
try {
const response = await axios.get(url);
const $ = cheerio.load(response.data);
const listupd = $('.listupd');
if (listupd.length === 0) {
console.log(`Tidak ditemukan listupd di page ${i}`);
break;
}
let titleFound = false;
listupd.each((index, element) => {
const bsx = $(element).find('.bsx');
bsx.each((index, bsxElement) => {
const title = $(bsxElement).find('.tt').text().trim();
if (title) {
titleFound = true;
const link = $(bsxElement).find('a').attr('href');
komikList.push({
title,
link
});
}
});
});
if (!titleFound) {
console.log(`Tidak ditemukan title di page ${i}`);
break;
}
console.log(`Page ${i} selesai di fetch`);
} catch (error) {
console.error(`Error di page ${i}: ${error}`);
break;
}
}
console.log('Semua page selesai di fetch');
return komikList;
}


function getChapterList(html) {
const $ = cheerio.load(html);
const chapterList = [];
$('.epcheck .eplister ul li').each((index, element) => {
const chapterLink = $(element).find('a').attr('href');
const chapterTitle = $(element).find('a').text().trim();
chapterList.push({
title: chapterTitle,
link: chapterLink,
})
})
return chapterList;
}