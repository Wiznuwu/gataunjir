const { toAudio } = require("../lib/converter.js");

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q || q.msg).mimetype || q.mediaType || "";
  switch (command) {
              case 'toaud':
            case 'toaudio': {
                if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`Send/Reply Video/Audio that you want to make into audio with captions ${prefix + command}`)
                await m.reply(wait)
                let media = await q.download()
                let audio = await toAudio(media, 'mp4')
                conn.sendMessage(m.chat, {
                    audio: audio,
                    mimetype: 'audio/mpeg'
                }, {
                    quoted: m
                })

            }
            break
            case 'tomp3': {
                if (!/video/.test(mime) && !/audio/.test(mime)) return m.reply(`Send/Reply Video/Audio that you want to make into MP3 with captions ${prefix + command}`)
                await m.reply(wait)
                let media = await q.download()
                let audio = await toAudio(media, 'mp4')
                conn.sendMessage(m.chat, {
                    document: audio,
                    mimetype: 'audio/mp3',
                    fileName: `audio.mp3`
                }, {
                    quoted: m
                })

            }
  }
};
handler.help = ["tomp3"];
handler.tags = ["tools"];
handler.alias = ["tomp3", "toaudio"];
handler.command = ["toaudio", "tomp3"];

handler.limit = true;

module.exports = handler;