const yts = require("yt-search")
const { youtube } = require('btch-downloader')   

let handler = async (
  m,
  { conn, args, isPrems, text, isOwner, usedPrefix, command },
) => {
  if (!args || !args[0])
    throw `Example :\n${usedPrefix + command} https://youtu.be/YzkTFFwxtXI`;
  if (!args[0].match(/youtu/gi)) throw `Verify that the YouTube link`;
const regex = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:(?:embed\/|v\/|shorts\/|watch\?v=|watch\?.+&v=))|youtu\.be\/)([^#&?]+)/;
const match = args[0].match(regex);
const idVideo = match[1]
console.log(idVideo)
if (!idVideo) throw "URL tidak valid";
let hasil;
try {
hasil = await yts({ videoId: idVideo });
} catch (error) {
console.log(`Error searching video: ${error}`);
throw "Video tidak ditemukan";
}
let { title, description, image, seconds } = hasil;
if (seconds > 1800) return m.reply("*[ DURATION TOO LONG ]*\ntidak bisa mendownload media dengan durasi lebih dari 30 menit!");
await m.reply(wait);
try {
let captvid2 = `*[ YOUTUBE DOWNLOADER SUCCESS ]*\n\n*Title:* ${title}\n*Description:* ${description}`
       let doc = {
      video: {
        url: `https://ytcdn.project-rian.my.id/download?url=${text}`,
      },
      mimetype: "video/mp4",
      caption: captvid2,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: args[0],
          title: title,
          body: title,
          sourceUrl: args[0],
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
} catch {
try {
 let respon = await youtube(args[0])
 let { mp4 } = respon
   let captvid2 = `*[ YOUTUBE DOWNLOADER SUCCESS ]*\n\n*Title:* ${title}\n*Description:* ${description}`
       let doc = {
      video: {
        url: mp4,
      },
      mimetype: "video/mp4",
      caption: captvid2,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: args[0],
          title: title,
          body: title,
          sourceUrl: args[0],
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
  } catch {
  try {
  let response = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/yt?url=${args[0]}&apikey=${global.apibeta}`)
  let captvid2 = `*[ YOUTUBE DOWNLOADER SUCCESS ]*\n\n*Title:* ${title}\n*Description:* ${description}`
       let doc = {
      video: {
        url: response.result.mp4,
      },
      mimetype: "video/mp4",
      caption: captvid2,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: args[0],
          title: title,
          body: "Sukses",
          sourceUrl: args[0],
        },
      },
    };

    await conn.sendMessage(m.chat, doc, {
      quoted: m,
    });
    } catch (error) {
  console.log(error)
  m.reply("terjadi kesalahan")
   }
  }
 }
}
handler.help = ["ytmp4", "ytv", "yt"].map((a) => a + ` *[url YouTube]*`);
handler.tags = ["downloader"];
handler.command = ["ytmp4", "ytv", "yt"];
handler.register = true;
handler.limit = true;

module.exports = handler;