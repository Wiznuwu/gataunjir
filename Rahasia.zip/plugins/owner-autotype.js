let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Example: ${usedPrefix}${command} on/off`);

    const [commandName] = text.split(/\s+/);

    if (commandName.toLowerCase() === "on") {
        db.data.settings.autotype = true
        m.reply(`Sukses`);
    } else if (commandName.toLowerCase() === "off") {
        db.data.settings.autotype = false
        m.reply(`Sukses`);
    } else {
        m.reply(`Example: ${usedPrefix}${command} on/off`);
    }
};

handler.help = ["autotype"].map((a) => a + " *[on/off]*");

handler.tags = ["owner"];
handler.command = ["autotype"];
handler.owner = true;

module.exports = handler;