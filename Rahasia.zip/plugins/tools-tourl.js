let handler = async (m, { usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;
  try {
    let media = await q.download();
    let link = await Uploader.catbox(media).catch(async _ => await Uploader.telegraPh(media))
    let hasil = `*[ MAKIMA UPLOADER ]*
> • *Link:* ${link}`;
    m.reply(hasil.trim());
  } catch (e) {
    throw eror;
  }
};
handler.help = ["tourl", "upload"].map((a) => a + " *[reply/send media]*");
handler.tags = ["tools"];
handler.command = ["tourl", "upload"];
handler.register = true;
handler.limit = true;

module.exports = handler;