/**
  * Made by MannR
  * don't forget to follow
  * https://whatsapp.com/channel/0029VaGqCO6I1rcjc9hisJ3U
**/


let handler = async (m ,{ conn, text }) => {
const { webcrack} = await import("webcrack");
let teks
if (m.quoted) {
 teks = m.quoted ? m.quoted.text : text
} else if (text) {
teks = text ? text : text
} else return m.reply(`Masukan query!`)
	try {
		let result = await webcrack(teks);
		m.reply(result.code)
	} catch (e) {
		console.log(e)
		throw "Error kak!"
	}
}
handler.command = handler.help = ["decrypt"]
handler.tags = ["tools"]
handler.limit = true;

module.exports = handler;