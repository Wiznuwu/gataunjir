const { youtube } = require('btch-downloader');
const yts = require('yt-search');
let handler = async (m, { conn, args }) => {
if (!args[0]) throw "[ Masukkan Url Youtube! ]";
const regex = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=)|youtu\.be\/)([^#&?]*)/;
const match = args[0].match(regex);
const idVideo = match[1]
console.log(idVideo)
if (!idVideo) throw "URL tidak valid";
let hasil;
try {
hasil = await yts({ videoId: idVideo });
} catch (error) {
console.log(`Error searching video: ${error}`);
throw "Video tidak ditemukan";
}
let { title, description, image, seconds } = hasil;
if (seconds > 1800) return m.reply("*[ DURATION TOO LONG ]*\nI tidak bisa mendownload media dengan durasi lebih dari 30 menit!");
await m.reply(wait);
try {
let response = await youtube(args[0]);
let { mp3 } = response;
let doc = {
audio: { url: mp3 },
mimetype: "audio/mp4",
fileName: title,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
mediaType: 2,
mediaUrl: args[0],
title: title,
sourceUrl: args[0],
thumbnail: (await conn.getFile(image)).data,
},
},
};
await conn.sendMessage(m.chat, doc, { quoted: m });
console.log(mp3);
} catch (error) {
console.log(`Error downloading audio: ${error}`);
try {
let respon = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/yt?url=${args[0]}&apikey=${global.apibeta}`);
let doc = {
audio: { url: respon.result.mp3 },
mimetype: "audio/mp4",
fileName: respon.result.title,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
mediaType: 2,
mediaUrl: args[0],
title: respon.result.title,
sourceUrl: args[0],
thumbnail: (await conn.getFile(respon.result.thumb)).data,
},
},
};
await conn.sendMessage(m.chat, doc, { quoted: m });
} catch (error) {
console.log(`Error fetching API: ${error}`);
m.reply("Terjadi kesalahan");
}
}
};
handler.help = ["mp3", "a"].map((v) => "yt" + v + ` *[url YouTube]*`);
handler.tags = ["downloader"];
handler.command = /^y((outube|tb)audio|(outube|tb?)mp3|utubaudio|taudio|ta)$/i;

handler.exp = 0;
handler.register = false;
handler.limit = true;

module.exports = handler;