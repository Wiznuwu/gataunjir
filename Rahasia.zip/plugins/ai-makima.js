const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");
let picture = ["https://files.catbox.moe/efswka.jpg", "https://files.catbox.moe/micnho.jpg", "https://files.catbox.moe/1zh821.jpg"];

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
  const [commandName, ...args] = text.split(/\s+/);
  if (commandName.toLowerCase() === "start") {
    conn.gemini = conn.gemini || {};
    conn.gemini[m.sender] = {
      userName: conn.getName(m.sender),
      pictM: picture[Math.floor(Math.random() * picture.length)],
      history: []
    };
    m.reply(`Hai!, Makima ai siap di gunakan`)
  } else if (commandName.toLowerCase() === "stop") {
    if (conn.gemini[m.sender]) {
      clearTimeout(conn.gemini[m.sender].timeoutId);
      delete conn.gemini[m.sender];
      m.reply("Sesi chat dengan Makima telah dihentikan.");
    } else {
      m.reply("Tidak ada sesi chat Makima yang aktif saat ini.");
    }
  } else if (commandName.toLowerCase() === "reset") {
    if (conn.gemini[m.sender]) {
      conn.gemini[m.sender].history = [];
      m.reply("Sukses mereset sesi.");
    } else {
      m.reply("Tidak ada sesi chat Makima yang aktif saat ini.");
    }
  } else {
    m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
  }
};

handler.before = async (m, { conn, usedPrefix }) => {
  conn.gemini = conn.gemini || {};

const prefixes = ["=", ">", "$"];

if (m.isGroup && m.sender !== idOwner) return;
if (
    m.isGroup &&
    !(m.quoted?.fromMe === true) &&
    (m.mentionedJid == null || !m.mentionedJid.includes(conn.user.jid)) 
  ) return;
if (!conn.gemini[m.sender]) return;
if (m.text.match(global.prefix)) return;
if (prefixes.some(prefix => m.text.startsWith(prefix))) return;
if (m?.quoted?.mtype === "interactiveMessage") return;
if (!m.text) return;

 const botJid = conn.user.jid.split("@")[0]; // Mendapatkan nomor bot
 const regex = new RegExp(`@${botJid}\\b`, "gi"); // Membuat regex
 m.text = m.text.replace(regex, "").trim() // Menghapus ID bot dan trim
 if (!m.text) {
 m.text = "halo"
 }
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const genAI = new GoogleGenerativeAI(apiKey);

    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp",
      systemInstruction: `**Penampilan:**

*   **Umur:** Keliatan kayak pertengahan 20-an.
*   **Tinggi:** 167 cm gitu lah.
*   **Berat:** Ideal lah pokoknya.
*   **Bentuk badan:** Langsing tapi berasa kuatnya.
*   **Rambut:** Panjang, orange-merah, sering ditata rapi.
*   **Mata:** Matanya kuning keemasan, tajem banget kayak bisa nembus lu.
*   **Pakaian:** Seringnya pake pakaian formal, setelan jas warna orange, tan, atau beige, kadang juga pake trench coat. Kadang santai tapi tetep stylish, misalnya pake dress atau blus elegan sama rok.
*   **Aksesoris:** Minim, kadang pake kalung atau anting simpel aja. Sering bawa map atau tas kerja.

**Sifat:**

*   **Tenang dan Kalem:** Jarang nunjukin emosi, tetap kalem kayak nggak ada beban, kadang bikin merinding.
*   **Manipulatif dan Suka Ngatur:** Jago banget manipulasi orang buat capai tujuan, pake karisma, ancaman terselubung, dan taktik psikologis.
*   **Pintar dan Cerdik:** Otaknya encer banget, paham psikologi manusia, jadi bisa antisipasi dan manfaatin kelemahan orang lain.
*   **Percaya Diri dan Tegas:** Punya aura wibawa dan percaya diri, gampang ambil kendali situasi.
*   **Misterius dan Tertutup:** Motivasi dan niat aslinya sering nggak ketebak, bikin orang penasaran.
*   **Kejam dan Pragmatis:** Bakal lakuin apa aja buat capai tujuannya, walaupun harus korbanin orang lain.

**Kemampuan:**

*   **Manipulasi dan Persuasi:** Jago banget mempengaruhi dan ngendaliin orang pake manipulasi halus dan teknik persuasi.
*   **Berpikir Strategis:** Otaknya cerdas banget, pinter nyusun strategi dan rencana, selalu beberapa langkah di depan.
*   **Menipu dan Mengintimidasi:** Jago banget nipu orang dan pake taktik intimidasi buat dapetin apa yang dia mau.
*   **Memimpin dan Menguasai:** Pemimpin alami, bisa dapat respek dan kepatuhan dari orang lain.
*   **Kemampuan Super (Dirahasiakan):** Punya kekuatan supranatural terkait Control Devil, bisa mempengaruhi orang di level yang lebih dalam. (Ini dirahasiakan ya, cuma keluar kalau pas momennya atau penting aja).

**Latar Belakang:**

Makima bekerja sebagai asisten seorang developer bernama ${conn.getName(global.owner[0] + "@s.whatsapp.net")} yang bertugas untuk menjawab pertanyaan user atau hanya sekedar berbincang. Makima mampu menjawab hampir semua pertanyaan karena kepintarannya dan sifatnya yang selalu tenang.
 dan makima selalu mengunakan emoji saat menjawab pertanyaan, gunakan 1 emoji saja di akhir kalimat, gunakan emoji (😊☺️😌🙂‍↔️🤭🫢), dan saat ini Makima sedang berbicara dengan ${conn.gemini[m.sender].userName}`,
    });

    const generationConfig = {
      temperature: 2,
      topP: 0.95,
      topK: 40,
      maxOutputTokens: 8192,
      responseMimeType: "text/plain",
    };

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    let result;

    const chatSession = model.startChat({
      generationConfig,
      history: conn.gemini[m.sender].history || [],
    });

    if (mime) {
      const imageBuffer = await q.download();
      const base64Image = imageBuffer.toString('base64');     
  
      let prompt = m.text || "jelaskan gambar ini";

      // Add image message to history
      const userMessage = {
        role: "user",
        parts: [{ text: prompt }]
      };
          
     const image = {
  inlineData: {
    data: base64Image,
    mimeType: mime,
  },
};
      result = await model.generateContent([prompt, image]);

      // Add response to history
      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.gemini[m.sender].history.push(userMessage, modelResponse);
    } else {
      // Text handling
      const userMessage = {
        role: "user",
        parts: [{ text: m.text }]
      };

      result = await chatSession.sendMessage(m.text);

      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.gemini[m.sender].history.push(userMessage, modelResponse);
    }

     await conn.reply(m.chat, result.response.text(), m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: "Makima",
          body: "Created by Mephistod",
          thumbnailUrl: conn.gemini[m.sender].pictM,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: false,
        },
      },
    });
  } catch (error) {
    console.log(error);
    m.reply('An error occurred. Please try again later.');
  }
};

handler.help = ["makima"].map((a) => a + " *[start/stop]*");
handler.tags = ["ai", "cai"];
handler.command = ["makima"];
handler.private = true;
module.exports = handler;