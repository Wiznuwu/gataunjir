const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
const { GoogleAIFileManager } = require("@google/generative-ai/server");
let picture = ["https://files.catbox.moe/efswka.jpg", "https://files.catbox.moe/micnho.jpg", "https://files.catbox.moe/1zh821.jpg"];

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
  const [commandName, ...args] = text.split(/\s+/);
  if (commandName.toLowerCase() === "start") {
    conn.gemini = conn.gemini || {};
    conn.gemini[m.sender] = {
      userName: conn.getName(m.sender),
      pictM: picture[Math.floor(Math.random() * picture.length)],
      history: []
    };
    m.reply(`Hai!, Makima ai siap di gunakan`)
  } else if (commandName.toLowerCase() === "stop") {
    if (conn.gemini[m.sender]) {
      clearTimeout(conn.gemini[m.sender].timeoutId);
      delete conn.gemini[m.sender];
      m.reply("Sesi chat dengan Makima telah dihentikan.");
    } else {
      m.reply("Tidak ada sesi chat Makima yang aktif saat ini.");
    }
  } else if (commandName.toLowerCase() === "reset") {
    if (conn.gemini[m.sender]) {
      conn.gemini[m.sender].history = [];
      m.reply("Sukses mereset sesi.");
    } else {
      m.reply("Tidak ada sesi chat Makima yang aktif saat ini.");
    }
  } else {
    m.reply(`Example: ${usedPrefix}${command} start/stop/reset`);
  }
};

handler.before = async (m, { conn, usedPrefix }) => {
  conn.gemini = conn.gemini || {};

const prefixes = ["=", ">", "$"];

if (m.isGroup && m.sender !== idOwner) return;
if (
    m.isGroup &&
    !(m.quoted?.fromMe === true) &&
    (m.mentionedJid == null || !m.mentionedJid.includes(conn.user.jid)) 
  ) return;
if (!conn.gemini[m.sender]) return;
if (m.text.match(global.prefix)) return;
if (prefixes.some(prefix => m.text.startsWith(prefix))) return;
if (m?.quoted?.mtype === "interactiveMessage") return;
if (!m.text) return;

 const botJid = conn.user.jid.split("@")[0]; // Mendapatkan nomor bot
 const regex = new RegExp(`@${botJid}\\b`, "gi"); // Membuat regex
 m.text = m.text.replace(regex, "").trim() // Menghapus ID bot dan trim
 if (!m.text) {
 m.text = "halo"
 }
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const genAI = new GoogleGenerativeAI(apiKey);
    const fileManager = new GoogleAIFileManager(apiKey);
    async function uploadToGemini(path, mimeType) {
  const uploadResult = await fileManager.uploadFile(path, {
    mimeType,
    displayName: path,
  });
  const file = uploadResult.file;
  console.log(`Uploaded file ${file.displayName} as: ${file.name}`);
  return file;
}
    
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-exp",
      systemInstruction: `nama kamu adalah Makima, kamu adalah wanita feminim, kamu adalah ai yang tau segalanya, jawab pertanyaan dengan singkat namun jelas, gunakanlah bahasa gaul saat menjawab, dan gunakan emoji saat menjawab (tapi jangan terlalu banyak emoji), dan saat ini kami sedang berbicara dengan ${conn.gemini[m.sender].userName}`,
    });

    const generationConfig = {
      temperature: 2,
      topP: 0.95,
      topK: 40,
      maxOutputTokens: 8192,
      responseMimeType: "text/plain",
    };

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    let result;

    const chatSession = model.startChat({
      generationConfig,
      history: conn.gemini[m.sender].history || [],
    });

    if (mime) {
      const imageBuffer = await q.download();
      const base64Image = imageBuffer.toString('base64');     
      const files = [
    await uploadToGemini(imageBuffer, mime),
  ];
      let prompt = m.text || "jelaskan gambar ini";

      // Add image message to history
      const userMessage = {
        role: "user",
        parts: [
          {
            fileData: {
              mimeType: files[0].mimeType,
              fileUri: files[0].uri,
            },
          },
          {text: prompt},
        ],
      };
          
     const image = {
  inlineData: {
    data: base64Image,
    mimeType: mime,
  },
};
      result = await model.generateContent([prompt, image]);

      // Add response to history
      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.gemini[m.sender].history.push(userMessage, modelResponse);
    } else {
      // Text handling
      const userMessage = {
        role: "user",
        parts: [{ text: m.text }]
      };

      result = await chatSession.sendMessage(m.text);

      const modelResponse = {
        role: "model",
        parts: [{ text: result.response.text() }]
      };

      conn.gemini[m.sender].history.push(userMessage, modelResponse);
    }

     await conn.reply(m.chat, result.response.text(), m, {
      contextInfo: {
        mentionedJid: [],
        groupMentions: [],
        externalAdReply: {
          title: "Makima",
          body: "Created by Mephistod",
          thumbnailUrl: conn.gemini[m.sender].pictM,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: false,
        },
      },
    });
  } catch (error) {
    console.log(error);
    m.reply('An error occurred. Please try again later.');
  }
};

handler.help = ["makima"].map((a) => a + " *[start/stop]*");
handler.tags = ["ai", "cai"];
handler.command = ["makima"];
handler.private = true;
module.exports = handler;