let levelling = require("../lib/levelling");
const canvafy = require("canvafy");
let fetch = require("node-fetch");
const canvacord = require("canvacord");

let handler = async (m, { conn, command }) => {
  let user = global.db.data.users[m.sender];
  let ppUrl = await conn
    .profilePictureUrl(m.sender, "image")
    .catch((_) => "https://telegra.ph/file/1a2ce69ce7445f80d1421.png");

  if (!levelling.canLevelUp(user.level, user.exp, global.multiplier)) {
    let { min, xp, max } = levelling.xpRange(user.level, global.multiplier);
    let pp = await (await fetch(ppUrl)).buffer();
    let curr = user.exp - min;
    let minxp = max - user.exp;
    let textInfo = `*❑ L E V E L - U P*

Level *➠ ${user.level}*
Less than *➠ ${max - user.exp}(XP) more!*`.trim();

    const rank = await new canvafy.Rank()
      .setAvatar(ppUrl)
      .setBackground(
        "image",
        "https://cdna.artstation.com/p/assets/images/images/044/907/498/large/gurkirat-singh-finaljan4-1-1.jpg?1641458624",
      )
      .setUsername(user.name)
      .setBorder("#FFDF00")
      .setLevel(user.level)
      .setRank(user.level)
      .setCurrentXp(curr)
      .setRequiredXp(xp)
      .build();

    m.reply(textInfo, rank);
  }

  let before = user.level * 1;
  while (levelling.canLevelUp(user.level, user.exp, global.multiplier))
    user.level++;
  if (before !== user.level) {
    const levelUp = await new canvafy.LevelUp()
      .setAvatar(ppUrl)
      .setBackground(
        "image",
        "https://telegra.ph/file/3f02ef79a183e515398c7.jpg",
      )
      .setUsername(user.name)
      .setBorder("#000000")
      .setAvatarBorder("#ff0000")
      .setOverlayOpacity(0.7)
      .setLevels(before, user.level)
      .build();

    let caption = `*[ LEVEL - UP ]*

From: *[ ${before} ]* ➠ *[ ${user.level} ]*
Congratulations, you have leveled up!🎉🎉`.trim();

    return m.reply(caption, levelUp);
  }
};

handler.help = ["levelup"];
handler.tags = ["xp"];
handler.command = ["levelup", "level"]

handler.limit = true;

module.exports = handler;