let handler = async (m, { conn, isOwner, text, isAdmin }) => {
  let who;
  if (m.isGroup) {
    if (!(isAdmin || isOwner)) {
      global.dfail("admin", m, conn);
      throw false;
    }
    if (isOwner)
      who = m.mentionedJid[0]
        ? m.mentionedJid[0]
        : m.quoted
          ? m.quoted.sender
          : text
            ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
            : m.chat;
    else who = m.chat;
  } else {
    if (!isOwner) {
      global.dfail("owner", m, conn);
      throw false;
    }
    who = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : m.chat;
  }

  try {
    if (!isOwner && isAdmin) return;
    if (who.endsWith("g.us")) global.db.data.chats[who].isBanned = true;

    m.reply(`<Berhasil Ban!>\n _Lucy-bot Tidak Aktif Dichat ${(await conn.getName(who)) == undefined ? "ini" : await conn.getName(who)}._`);
  } catch (e) {
    throw `Gagal`;
  }
};
handler.help = ["banchat"];
handler.tags = ["owner"];
handler.command = ["banchat"];
handler.rowner = true;
module.exports = handler;