const ytdl = require("@distube/ytdl-core");
const yts = require("yt-search");
const fs = require("fs");
const { pipeline } = require("stream");
const { promisify } = require("util");
const streamPipeline = promisify(pipeline);
const os = require("os");
const axios = require('axios');
const { youtube } = require("btch-downloader")
function levenshtein(str1, str2) {
  const dp = [];

  // Initialize rows and columns
  for (let i = 0; i <= str1.length; i++) {
    dp[i] = new Array(str2.length + 1).fill(i);
  }

  for (let i = 1; i <= str2.length; i++) {
    dp[0][i] = i;
  }

  // Calculate Levenshtein distance
  for (let i = 1; i <= str1.length; i++) {
    for (let j = 1; j <= str2.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, // Deletion
        dp[i][j - 1] + 1, // Insertion
        dp[i - 1][j - 1] + (str1[i - 1] !== str2[j - 1] ? 1 : 0) // Substitution
      );
    }
  }

  return dp[str1.length][str2.length];
}

function trimYouTubeUrl(url) {
  return url.split("?")[0];
}

const handler = async (m, { conn, command, text, usedPrefix }) => {
  conn.play = conn.play || {};
  if (!text) throw `*Example:* ${usedPrefix + command} Kaguya love is war`;
  
  let url;
    const trimmedUrl = trimYouTubeUrl(text + " song");
    const search = await yts(trimmedUrl);
    if (!search) throw "Not Found, Try Another Title";
    const videos = search.videos;

    // Simple String Matching
    const simpleMatchScores = videos.map((video) => {
      const titleTokens = video.title.toLowerCase().split(" ");
      const queryTokens = text.toLowerCase().split(" ");
      const matchCount = titleTokens.filter((token) => queryTokens.includes(token)).length;
      return matchCount;
    });

    // Levenshtein Distance
    const levenshteinDistances = videos.map((video) => {
      return levenshtein(text.toLowerCase(), video.title.toLowerCase());
    });

    // Combine Scores
    const combinedScores = videos.map((video, i) => {
      const simpleMatchScore = simpleMatchScores[i];
      const levenshteinDistance = levenshteinDistances[i];
      const normalizedDistance = levenshteinDistance / (video.title.length + 1); // Normalize distance based on title length
      const combinedScore = simpleMatchScore - normalizedDistance; // Prioritize simple matches while considering Levenshtein distance
      return { ...video, combinedScore };
    });
    // Select Most Similar Video
    const mostSimilarVideo = combinedScores.sort((a, b) => b.combinedScore - a.combinedScore)[0]; // Select video with the highest combined score
    // Filter Similar Titles with Highest Views
    const similarTitleVideos = videos.filter(
      (video) => video.title.toLowerCase().includes(text.toLowerCase())
    );
    const highestViewSimilarTitleVideo = similarTitleVideos.sort((a, b) => {
      return b.views - a.views; // Sort by views in descending order
    });
    const vid = videos[0]; // Select the video with the highest views        
    const finalVideo = vid || mostSimilarVideo; // Choose video with highest views among similar titles, or fallback to most similar video if no similar titles found
    const { title, thumbnail, views, ago, url: videoUrl, seconds } = finalVideo;
     if (seconds > 1800) return m.reply("*[ DURATION TOO LONG ]*\ntidak bisa mendownload media dengan durasi lebih dari 30 menit!");
     m.reply("*Wait, Processing Your Request...*");     
    const judul = title.replace(/\//g, "");
    const caption = `*[ YOUTUBE PLAY ]*\n*• Caption:* ${title}\n*• Views:* ${views}\n*• Ago:* ${ago}\n*• Duration:* ${seconds} seconds\n*• Thumbnail:* ${thumbnail}\n*• Source Yt:* ${videoUrl}\n\n\`Audio will be sent soon, so please wait a moment\``;
try {
  let response = await youtube(videoUrl)
  let { mp3 } = response
  let doc = {
      audio: { url: mp3 },
      mimetype: "audio/mp4",
      fileName: title,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: videoUrl,
          title: title,
          sourceUrl: videoUrl,
          thumbnail: (await conn.getFile(thumbnail)).data,
        },
      },
    };
    await conn.sendMessage(m.chat, doc, { quoted: m }); 
    console.log(mp3)  
    } catch {
  try {
const response = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/ytmp3?url=${videoUrl}&apikey=${global.apibeta}`)
console.log(response.result)
     let doc = {
      audio: { url: response.result.mp3 },
      mimetype: "audio/mp4",
      fileName: title,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: videoUrl,
          title: title,
          sourceUrl: videoUrl,
          thumbnail: (await conn.getFile(thumbnail)).data,
        },
      },
    };
    await conn.sendMessage(m.chat, doc, { quoted: m });
  } catch {
return m.reply("Terjadi Error")
console.log(e)
}
}
};
handler.help = ["lagu *[query]*", "musik *[query]*", "play *[query]*"];
handler.tags = ["downloader"];
handler.command = ["lagu", "musik", "play"]
handler.limit = true;

handler.register = true;
module.exports = handler;