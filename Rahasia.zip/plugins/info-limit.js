let handler = async (m) => {
  let who;
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
  else who = m.sender;
  let name = await conn.getName(m.sender);
  m.reply(`${global.db.data.users[who].limit} Limit Tersisa\n\n- Limit akan di reset menjadi 100 kembali saat tengah malam`)
};
handler.help = ["limit [@user]"];
handler.tags = ["info"];
handler.command = /^(limit)$/i;
module.exports = handler;