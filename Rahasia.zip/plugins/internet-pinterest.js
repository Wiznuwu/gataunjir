let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  if (!args || args.length < 1) {
    return m.reply(Func.example(usedPrefix, command, "shinomiya Kaguya"));
  }

  let response = args.join(" ").split(" --");
  let query = response[0];
  let count = parseInt(response[1]);
  m.reply(wait);
  if (!count) {
    try {
      var tio = await Scraper["Tools"].pinterest2(query);
      result = tio[Math.floor(Math.random() * tio.length)]
      m.reply(`*• Media:* ${result.images_url}\n*• Result Search from:* ${query}`, result.images_url)
    } catch (error) {
      console.log(error);
      conn.reply(m.chat, "Terjadi kesalahan saat menjalankan perintah.", m);
    }
  } else {
    if (count > 10) return m.reply("*Maximun 10 request*");

    try {
      let res = await Scraper["Tools"].pinterest2(query);

      for (let i = 0; i < count; i++) {
        let image = res[Math.floor(Math.random() * res.length)];
        setTimeout(() => {
           m.reply(`*• Media*: *(${i + 1}/${count})*\n*•Media url:* ${image.images_url}\n*• Result Search from:* ${query}`, image.images_url)
        }, i * 5000);
      }
    } catch (error) {
      console.log(error);
      m.reply(eror);
    }
  }
};

handler.help = ["pinterest"].map((a) => a + " *[query -- count]*");
handler.tags = ["tools", "internet"];
handler.command = ["pinterest", "pin"];

handler.register = true;
handler.limit = true;

module.exports = handler;