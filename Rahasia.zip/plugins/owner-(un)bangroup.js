let handler = async (m, { conn, isOwner, text, isAdmin, command }) => {
let who = m.chat      
switch (command) {         
  case "bangrub":
  case "bangroup": {
  if (who.endsWith("g.us")) global.db.data.chats[who].isBanned = true;
    m.reply(`*Berhasil Ban!*\n ${global.namebot} Tidak Aktif Dichat ${(await conn.getName(who)) == undefined ? "ini" : await conn.getName(who)}.`);
  }
  break
  case "unbangrub":
  case "unbangroup": {
  if (who.endsWith("g.us")) global.db.data.chats[who].isBanned = false;
  m.reply(`*Berhasil unBan!*\n ${global.namebot} Sekarang Aktif Dichat ${(await conn.getName(who)) == undefined ? "ini" : await conn.getName(who)}.`);
  }
  break
  }
};
handler.help = ["unbangroup", "bangroup"];
handler.tags = ["owner"];
handler.command = ["bangroup", "bangrub", "unbangroup", "unbangrub"];
handler.group = true;
handler.rowner = true;
module.exports = handler;