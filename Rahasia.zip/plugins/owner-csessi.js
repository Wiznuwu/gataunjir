const fs = require('fs').promises;
const path = require('path');

const handler = async (m, { conn }) => {
  try {
    const directory = './session';
    const deletedFiles = [];
    const failedFiles = [];
    
    // Membaca semua file dalam direktori
    const files = await fs.readdir(directory);
    
    // Filter file yang akan dihapus (semua kecuali creds.json)
    const filesToDelete = files.filter(file => 
      file !== 'creds.json' && 
      (file.startsWith('session-') || file.endsWith('.json'))
    );
    
    // Hapus file satu per satu
    for (const file of filesToDelete) {
      const filePath = path.join(directory, file);
      
      try {
        // Coba hapus file
        await fs.unlink(filePath);
        deletedFiles.push(file);
      } catch (error) {
        // Jika gagal dengan fs.promises, coba dengan fs synchronous
        try {
          require('fs').unlinkSync(filePath);
          deletedFiles.push(file);
        } catch (syncError) {
          console.error(`Gagal menghapus ${file}:`, syncError);
          failedFiles.push(file);
        }
      }
    }
    
    // Buat pesan hasil
    let message = '📝 *Laporan Pembersihan Sesi*\n\n';
    
    if (deletedFiles.length > 0) {
      message += `✅ *Berhasil dihapus (${deletedFiles.length} file):*\n${deletedFiles.join('\n')}\n\n`;
    }
    
    if (failedFiles.length > 0) {
      message += `❌ *Gagal dihapus (${failedFiles.length} file):*\n${failedFiles.join('\n')}\n`;
      message += '\nSilakan coba:\n1. Restart bot\n2. Hapus manual\n3. Periksa permission file';
    }
    
    if (deletedFiles.length === 0 && failedFiles.length === 0) {
      message += '⚠️ Tidak ada file sesi yang perlu dihapus';
    }
    
    // Kirim laporan
    await m.reply(message);
    
  } catch (error) {
    console.error('Error:', error);
    await m.reply(`❌ Terjadi kesalahan: ${error.message}`);
  }
};

handler.help = ['csessi', 'clearsessi'].map(v => v + ' *[clear trash]*');
handler.tags = ['owner'];
handler.command = /^(csessi|clearsessi)$/i;
handler.rowner = true;
handler.register = true;

module.exports = handler;