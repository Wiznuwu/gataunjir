const axios = require("axios")

let handler = async (m, { conn, text, usedPrefix, command }) => {
  switch (command) {
case 'sdxlwaifu': {
  if (!text) return m.reply(`Example: ${usedPrefix + command} yourrtext`)
  m.reply(wait)
async function sdxlWaifu(prompt) {
  try {
    return await new Promise(async(resolve, reject) => {
      if(!prompt) return reject("failed reading undefined prompt!");
      axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
        prompt,
        negativePrompt: "bad anatomy, bad hands, three hands, three legs, bad arms, missing legs, missing arms, poorly drawn face, bad face, fused face, cloned face, worst face, three crus, extra crus, fused crus, worst feet, three feet, fused feet, fused thigh, three thigh, fused thigh, extra thigh, worst thigh, missing fingers, extra fingers, ugly fingers, long fingers, horn",
        key: "Waifu",
        width: 512,
        height: 768,
        quantity: 1,
        size: "512x768"
      }).then(res => {
        const data = res.data;
        if(data.code !== 0) return reject(data.message);
        if(!data.data?.url) return reject("failed generating image!")
        return resolve({
          status: true,
          image: data.data.url
        })
      }).catch(reject)
    })
  } catch (e) {
    return {
      status: false,
      message: e
    }
  }
}
try {
  let plerl = await sdxlWaifu(text)
  conn.sendMessage(m.chat, { image: { url: plerl.image }, caption: `nah itu bang` }, { quoted: m })
} catch (error) {
  m.reply("Error bang")
 }
}
break
 }
};
handler.help = ["sdxlwaifu"].map((a) => a + " *[prompt]*");
handler.tags = ["premium"];
handler.premium = true
handler.command = ["sdxlwaifu"];
module.exports = handler;