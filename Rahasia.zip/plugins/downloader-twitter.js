let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} *[Twitter/x url]*`;
  m.reply("*[ PROCESSING.... ]*");
  try {
    let res = await Func.fetchJson(`https://api.betabotz.eu.org/api/download/twitter2?url=${text}&apikey=${global.apibeta}`);

    // Inisialisasi array untuk menyimpan URL video dan image
    let videoUrls = [];
    let imageUrls = [];

    // Iterasi melalui setiap media dalam media_extended
    res.result.media_extended.forEach(media => {
      if (media.type === "video") {
        videoUrls.push(media.url);
      } else if (media.type === "image") {
        imageUrls.push(media.url);
      }
    });

    // Kirim video jika ada
    if (videoUrls.length > 0) {
      videoUrls.forEach(url => {
        conn.sendMessage(m.chat, { video: { url }, caption: "*[ TWITTER/X DOWNLOADER ]*" }, { quoted: m });
      });
    }

    // Kirim image jika ada
    if (imageUrls.length > 0) {
      imageUrls.forEach(url => {
        conn.sendMessage(m.chat, { image: { url }, caption: "*[ TWITTER/X DOWNLOADER ]*" }, { quoted: m });
      });
    }
  } catch (e) {
    throw "*[ ERROR CAN'T DOWNLOAD TWITTER ]*";
  }
};
handler.help = ["twit", "twitter"].map((a) => a + " *[twitter url]*");
handler.tags = ["downloader"];
handler.command = ["twit", "twitter"]
handler.register = true;
module.exports = handler;