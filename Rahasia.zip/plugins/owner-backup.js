require("dotenv").config();
const fs = require("fs");
const archiver = require("archiver");
const path = require("path");
const axios = require("axios");

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const OWNER = process.env.OWNER;
const REPO = process.env.REPO;
const BRANCH = process.env.BRANCH;

let handler = async (m, { conn }) => {
  if (!m.sender.includes("6281244622905")) throw "Hanya Wisnu yang bisa.";

  m.reply("*Sedang membuat backup script dan mengunggah ke GitHub...*");

  const backupName = "MakimaBot.zip";
  const backupFilePath = path.resolve(backupName);

  const createBackup = () => {
    return new Promise((resolve, reject) => {
      const output = fs.createWriteStream(backupFilePath);
      const archive = archiver("zip", { zlib: { level: 9 } });

      output.on("close", () => {
        console.log(`Backup ${backupName} berhasil dibuat (${archive.pointer()} bytes).`);
        resolve();
      });

      archive.on("error", (err) => {
        console.log("Error saat membuat arsip:", err.message);
        reject(err);
      });

      archive.pipe(output);

      archive.glob("**/*", {
        cwd: path.resolve(__dirname, "../"),
        ignore: [
          "node_modules/**",
          "tmp/**",
          "**/flyaudio/**",
          "**.pm2/**",
          ".npm/**",
          "session/**",
          backupName,
        ],
      });
      archive.finalize();
    });
  };

  const uploadToGitHub = async () => {
    const content = fs.readFileSync(backupFilePath);
    const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/Rahasia.zip`;

    let sha;
    try {
      const { data } = await axios.get(url, {
        headers: { Authorization: `Bearer ${GITHUB_TOKEN}` },
      });
      sha = data.sha;
      console.log("File Rahasia.zip ditemukan di repository. SHA:", sha);
    } catch (err) {
      if (err.response?.status === 404) {
        console.log("File Rahasia.zip belum ada di repository. Mengunggah sebagai file baru.");
      } else {
        console.log("Error saat memeriksa keberadaan file di GitHub:", err.response?.data || err.message);
        throw err;
      }
    }

    try {
      const response = await axios.put(
        url,
        {
          message: sha ? `Update Rahasia.zip` : `Add Rahasia.zip`,
          content: Buffer.from(content).toString("base64"),
          branch: BRANCH,
          sha,
        },
        {
          headers: { Authorization: `Bearer ${GITHUB_TOKEN}` },
          maxBodyLength: Infinity,
          maxContentLength: Infinity,
        }
      );
      console.log("File berhasil diunggah ke GitHub. Response:", response.data);
    } catch (err) {
      console.log("Error saat mengunggah file ke GitHub:", err.response?.data || err.message);
      throw err;
    }
  };

  try {
    await createBackup();
    await uploadToGitHub();

    const caption = `*[ BACKUP SCRIPT ]*\n> • *Nama file:* ${backupName}\n> • *Ukuran file:* ${fs.statSync(backupFilePath).size} bytes`;
    await conn.sendMessage(
      m.sender,
      {
        document: {
          url: backupName,
        },
        fileName: backupName,
        caption: caption,
        mimetype: "application/zip",
      },
      { quoted: m }
    );

    fs.rmSync(backupFilePath);
    console.log(`File backup ${backupName} berhasil dihapus.`);
  } catch (err) {
    console.log("Terjadi kesalahan:", err.message);
  }
};

handler.help = ["backup"].map((a) => a + " *[backup file]*");

handler.tags = ["owner"];
handler.command = ["backup"];
handler.owner = true;

module.exports = handler;