require("dotenv").config();
const fs = require("fs");
const archiver = require("archiver");
const path = require("path");
const axios = require("axios");

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const OWNER = process.env.OWNER;
const REPO = process.env.REPO;

let handler = async (m, { conn }) => {
  m.reply("*Sedang membuat backup script dan mengunggah ke GitHub...*");

  const backupName = "LucyBot.zip";
  const backupFilePath = path.resolve(backupName);

  const createBackup = () => {
    return new Promise((resolve, reject) => {
      const output = fs.createWriteStream(backupFilePath);
      const archive = archiver("zip", { zlib: { level: 9 } });

      output.on("close", () => {
        console.log(`Backup ${backupName} berhasil dibuat (${archive.pointer()} bytes).`);
        resolve();
      });

      archive.on("error", (err) => {
        console.log("Error saat membuat arsip:", err.message);
        reject(err);
      });

      archive.pipe(output);

      archive.glob("**/*", {
        cwd: path.resolve(__dirname, "../"),
        ignore: [
          "node_modules/**",
          "tmp/**",
          "**/flyaudio/**",
          "**.pm2/**",
          ".npm/**",
          "session/**",
          backupName,
        ],
      });
      archive.finalize();
    });
  };

  const uploadToGitHubRelease = async () => {
    try {
      // 1. Create a new release
      const createReleaseResponse = await axios.post(
        `https://api.github.com/repos/${OWNER}/${REPO}/releases`,
        {
          tag_name: `backup-${new Date().toISOString().split('T')[0]}`,
          name: `Backup ${new Date().toISOString().split('T')[0]}`,
          body: 'Automatic backup',
          draft: false,
          prerelease: false
        },
        {
          headers: {
            'Authorization': `Bearer ${GITHUB_TOKEN}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const releaseId = createReleaseResponse.data.id;

      // 2. Upload the asset to the release
      const stats = fs.statSync(backupFilePath);
      const fileStream = fs.createReadStream(backupFilePath);

      await axios.post(
        `https://uploads.github.com/repos/${OWNER}/${REPO}/releases/${releaseId}/assets?name=${backupName}`,
        fileStream,
        {
          headers: {
            'Authorization': `Bearer ${GITHUB_TOKEN}`,
            'Content-Type': 'application/zip',
            'Content-Length': stats.size
          },
          maxContentLength: Infinity,
          maxBodyLength: Infinity
        }
      );

      console.log("File berhasil diunggah ke GitHub Release");
    } catch (err) {
      console.log("Error saat mengunggah file ke GitHub:", err.response?.data || err.message);
      throw err;
    }
  };

  try {
    await createBackup();
    await uploadToGitHubRelease();

    const caption = `*[ BACKUP SCRIPT ]*\n> • *Nama file:* ${backupName}\n> • *Ukuran file:* ${fs.statSync(backupFilePath).size} bytes`;
    await conn.sendMessage(
      m.sender,
      {
        document: {
          url: backupName,
        },
        fileName: backupName,
        caption: caption,
        mimetype: "application/zip",
      },
      { quoted: m }
    );

    fs.rmSync(backupFilePath);
    console.log(`File backup ${backupName} berhasil dihapus.`);
  } catch (err) {
    console.log("Terjadi kesalahan:", err.message);
    m.reply("Terjadi kesalahan saat backup: " + err.message);
  }
};

handler.help = ["backup"].map((a) => a + " *[backup file]*");
handler.tags = ["owner"];
handler.command = ["backup"];
handler.owner = true;

module.exports = handler;