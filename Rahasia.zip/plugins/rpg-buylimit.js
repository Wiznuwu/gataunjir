const moneyPerLimit = 25000;

let handler = async (m, { conn, command, args }) => {
  let count;

  // Extract count based on command and arguments
  if (command) {
    count = command.replace(/^buylimit/i, "");
  }

  if (count) {
    if (/all/i.test(count)) {
      // Buy all possible limits (considering money and moneyPerLimit)
      count = Math.floor(global.db.data.users[m.sender].money / moneyPerLimit);
    } else {
      // Parse numeric count from command or argument
      count = parseInt(count) || parseInt(args[0]) || 1;
    }
  } else {
    // Default count to 1 if no command or argument is provided
    count = 1;
  }

  // Ensure positive count (avoid potential errors)
  count = Math.max(1, count);

  // Check for sufficient funds
  if (global.db.data.users[m.sender].money >= moneyPerLimit * count) {
    global.db.data.users[m.sender].money -= moneyPerLimit * count;
    global.db.data.users[m.sender].limit += count;

    // Send confirmation message with proper formatting
    m.reply(`-${global.convertMoney(moneyPerLimit * count)} Money\n+${count} Limit`)
  } else {
    // Send informative message about insufficient funds
    m.reply(`Insufficient funds to buy ${count} limits. You need ${global.convertMoney(moneyPerLimit * count)} Money, but you only have ${global.convertMoney(global.db.data.users[m.sender].money)}.`);
  }
};

handler.help = ["buylimit", "buylimitall"];
handler.tags = ["rpg"];
handler.command = ["buylimit", "buylimitall"];
handler.rpg = true;
handler.group = true;

handler.register = true;

module.exports = handler;

