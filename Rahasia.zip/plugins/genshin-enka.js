const fs = require('fs');
const axios = require("axios")

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    if (!args[0] || isNaN(args[0])) {
        throw 'Masukan Uid yang berupa angka'
    }
await m.reply(wait)
          let Ssweb = await Scraper["Tools"].ssweb(`https://enka.network/u/${args[0]}`, "full", "desktop");
			axios.get(`https://enka.network/api/uid/${args[0]}?info`).then(({ data }) => {
				var caption = `▧「 *P R O F I L E  G E N S H I N* 」\n\n ‣ *Nickname* : *${data.playerInfo.nickname}*\n`
				caption += ` ‣ *Adventure Rank* : *${data.playerInfo.level}*\n`
				caption += ` ‣ *Signature* : *${data.playerInfo.signature}*\n`
				caption += ` ‣ *World Level* : *${data.playerInfo.worldLevel}*\n\n`
				caption += ` ‣ *Achievement* : *${data.playerInfo.finishAchievementNum}*\n`
				caption += ` ‣ *Abyss* : *Floor ${data.playerInfo.towerFloorIndex} Chamber ${data.playerInfo.towerLevelIndex}*\n\n`
				caption += `▧ *Mau Lebih Lengkap? Cek Disini :*\nhttps://enka.network/u/${args[0]}\n`
				conn.sendMessage(m.chat ,{ image: Ssweb, caption: caption },{ quoted: m })
			})
	   
}
handler.help = ["enka *[Uid]*"];
handler.tags = ["hoyoverse"];
handler.command = ["enka"];
handler.limit = true
handler.register = true;
module.exports = handler;