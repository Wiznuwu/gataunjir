const fs = require('fs');
const axios = require("axios")

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    if (!args[1] || isNaN(args[1])) {
        throw 'Masukan Uid yang berupa angka'
    }
    if (args[0] == "gi") {
await m.reply(wait)
          let Ssweb = await Scraper["Tools"].ssweb(`https://enka.network/u/${args[1]}`, "full", "desktop");
			axios.get(`https://enka.network/api/uid/${args[1]}?info`).then(({ data }) => {
				var caption = `▧「 *P R O F I L E  G E N S H I N* 」\n\n ‣ *Nickname* : *${data.playerInfo.nickname}*\n`
				caption += ` ‣ *Adventure Rank* : *${data.playerInfo.level}*\n`
				caption += ` ‣ *Signature* : *${data.playerInfo.signature}*\n`
				caption += ` ‣ *World Level* : *${data.playerInfo.worldLevel}*\n\n`
				caption += ` ‣ *Achievement* : *${data.playerInfo.finishAchievementNum}*\n`
				caption += ` ‣ *Abyss* : *Floor ${data.playerInfo.towerFloorIndex} Chamber ${data.playerInfo.towerLevelIndex}*\n\n`
				caption += `▧ *Mau Lebih Lengkap? Cek Disini :*\nhttps://enka.network/u/${args[0]}\n`
				conn.sendMessage(m.chat ,{ image: Ssweb, caption: caption },{ quoted: m })
			})	   
} else if (args[0] == "hsr") {
   await m.reply(wait)
          let Ssweb = await Scraper["Tools"].ssweb(`https://enka.network/hsr/${args[1]}/`, "full", "desktop");
			axios.get(`https://enka.network/api/hsr/*uid/${args[1]}?info`).then(({ data }) => {
				var caption = `▧「 *P R O F I L E  H S R* 」\n\n ‣ *Nickname* : *${data.detailInfo.nickname}*\n`
				caption += ` ‣ *Level* : *${data.detailInfo.level}*\n`
				caption += ` ‣ *Signature* : *${data.detailInfo.signature}*\n`
				caption += ` ‣ *World Level* : *${data.detailInfo.worldLevel}*`
				caption += ` ‣ *Achievement* : *${data.detailInfo.recordInfo.achievementCount}*\n`
				caption += `▧ *Mau Lebih Lengkap? Cek Disini :*\nhttps://enka.network/hsr/${args[1]}/\n`
				conn.sendMessage(m.chat ,{ image: Ssweb, caption: caption },{ quoted: m })
			})
	} else {
	m.reply("contoh penggunaan: .enka *gi/hsr* *uid*")
	}
}
handler.help = ["enka *[gi/hsr]* [Uid]*"];
handler.tags = ["hoyoverse"];
handler.command = ["enka"];
handler.limit = true
handler.register = true;
module.exports = handler;