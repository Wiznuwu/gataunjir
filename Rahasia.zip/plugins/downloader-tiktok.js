let { toAudio } = require("../lib/converter.js");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[Tiktok Url]*`;
  if (!Func.isUrl(text))
    throw `*• Example :* ${usedPrefix + command} *[Tiktok Url]*`;
    const cleanTikTokURL = (url) => {    
    const shortLinkMatch = url.match(/(https?:\/\/)?(vm|vt)\.tiktok\.com\/[A-Za-z0-9]+/);
    return shortLinkMatch ? shortLinkMatch[0] : url;
  };
  text = cleanTikTokURL(text); 
  m.reply(wait);
  try {
    let fetch = await Scraper["Download"].tiktok.v1(text);
    let { data } = fetch;
    let media = await conn.getBuffer(data.play)
    let mp4 = await toAudio(media, 'mp4')
    if (data.images) {
      if (m.isGroup && data.images.length > 3) {
      await m.reply("Karena jumlah gambar lebih dari 3, gambar dikirim langsung ke DM Anda.");
        for (let i of data.images) {         
          await conn.sendMessage(
            m.sender, // Gambar dikirim ke pengirim pesan
            {
              image: {
                url: i,
              },
              caption: `*[ TIKTOK SLIDE DOWNLOADER ]*\n*• Title :* ${data.title}\n*• ID :* *[ ${data.id} ]*\n*• Views :* ${Func.formatNumber(data.play_count)}\n*• Likes :* ${Func.formatNumber(data.digg_count)}\n*• Comment :* ${Func.formatNumber(data.comment_count)}\n*• Author :* ${data.author.nickname}`,
            },
            { quoted: m },
          );
        }        
      } else {
        for (let i of data.images) {
          await conn.sendMessage(
            m.chat, // Gambar tetap dikirim ke grup jika jumlah <= 3
            {
              image: {
                url: i,
              },
              caption: `*[ TIKTOK SLIDE DOWNLOADER ]*\n*• Title :* ${data.title}\n*• ID :* *[ ${data.id} ]*\n*• Views :* ${Func.formatNumber(data.play_count)}\n*• Likes :* ${Func.formatNumber(data.digg_count)}\n*• Comment :* ${Func.formatNumber(data.comment_count)}\n*• Author :* ${data.author.nickname}`,
            },
            { quoted: m },
          );
        }
      }
    } else {
      const key = await conn.sendMessage(
        m.chat,
        {
          video: {
            url: data.play,
          },
          caption: `*[ TIKTOK VIDEO DOWNLOADER ]*\n*• Title :* ${data.title}\n*• ID :* *[ ${data.id} ]*\n*• Views :* ${Func.formatNumber(data.play_count)}\n*• Likes :* ${Func.formatNumber(data.digg_count)}\n*• Comment :* ${Func.formatNumber(data.comment_count)}\n*• Author :* ${data.author.nickname}`,
        },
        { quoted: m },
      );
      await conn.sendMessage(m.chat, {
        audio: mp4,
        mimetype: 'audio/mpeg'
      }, {
        quoted: key
      });
    }
  } catch {
    try {
      let tiktok = await Scraper["Download"].tiktok.v2(text);
      let media = await conn.getBuffer(tiktok.server1.url)
      let mp3 = await toAudio(tiktok.server1.url, 'mp4')
      let cap = `*[ TIKTOK V2 DOWNLOADER ]*
*• Caption :* ${tiktok.caption}`;
      const key = await conn.sendMessage(
        m.chat,
        {
          video: {
            url: tiktok.server1.url,
          },
          caption: `*[ TIKTOK VIDEO DOWNLOADER ]*\n*• Title :* ${tiktok.caption}\n*•`,
        },
        { quoted: m },
      );
      await conn.sendMessage(m.chat, {
        audio: mp3,
        mimetype: 'audio/mpeg'
      }, {
        quoted: key
      });
    } catch (e) {
    console.error(e)
      throw eror;
    }
  }
};
handler.help = ["tt", "tiktok"].map((a) => a + " *[Tiktok Url]*");
handler.tags = ["downloader"];
handler.command = ["tt", "tiktok"];
handler.register = true;
handler.limit = true;

module.exports = handler;