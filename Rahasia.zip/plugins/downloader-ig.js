const axios = require("axios")

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[Instagram url]*`;
  if (!Func.isUrl(text))
    throw `*• Example :* ${usedPrefix + command} *[Instagram url]`;
  m.reply(wait);
  try {
  let rez = await axios.get(`https://api.betabotz.eu.org/api/download/igdowloader?url=${text}&apikey=${global.apibeta}`)
const unik = [];
rez.data.message.forEach(obj => {
  if (!unik.includes(obj._url)) {
    unik.push(obj._url);
  }
});
    for (let i of unik) {
      m.reply("*[ INSTAGRAM DOWNLOADER ]*", i);
    }
  } catch (e) {
    throw eror;
  }
};
handler.help = ["ig", "igdl"].map((a) => a + " *[Instagram url]*");
handler.tags = ["downloader"];
handler.command = ["ig", "igdl"];
handler.limit = true;

module.exports = handler;