let handler = async (m, { command, usedPrefix, args }) => {
  let user = global.db.data.users[m.sender];
  let author = global.author;
  let upgrd = (args[0] || "").toLowerCase();
  let type = (args[0] || "").toLowerCase();
  let _type = (args[1] || "").toLowerCase();
  let jualbeli = (args[0] || "").toLowerCase();
  const list = `「 *E A T I N G* 」
╭──『 ғᴏᴏᴅ 』
│⬡ typing command↓
│   ${usedPrefix + command} rendang
│
│⬡ 🍖 *Ayambakar*
│⬡ 🍗 *Ayamgoreng*
│⬡ 🥘 *Rendang*
│⬡ 🥩 *Steak*
│⬡ 🥠 *Babipanggang*
│⬡ 🍲 *Gulaiayam*
│⬡ 🍜 *Oporayam*
│⬡ 🍷 *Vodka*
│⬡ 🍣 *Sushi*
│⬡ 💉 *Bandage*
│⬡ ☘️ *Ganja*
│⬡ 🍺 *Soda*
│⬡  🍞 *Roti*
│⬡ 🍖 *ikan bakar*
│⬡ 🍖 *lele bakar*
│⬡ 🍖 *nila bakar*
│⬡ 🍖 *bawal bakar*
│⬡ 🍖 *udang bakar*
│⬡ 🍖 *paus bakar*
│⬡ 🍖 *kepiting bakar*
╰───────────────
example .makan ayamgoreng 

gunakan spasi
`.trim();
  //try {
  if (/makan|eat/i.test(command)) {
    const count =
      args[1] && args[1].length > 0
        ? Math.min(99999999, Math.max(parseInt(args[1]), 1))
        : !args[1] || args.length < 3
          ? 1
          : Math.min(1, count);
    switch (type) {
      case "ayamgoreng":
        if (user.stamina < 100) {
          if (user.ayamgoreng >= count * 1) {
            user.ayamgoreng -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Ayam goreng kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "ayambakar":
        if (user.stamina < 100) {
          if (user.ayambakar >= count * 1) {
            user.ayambakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Ayam bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "oporayam":
        if (user.stamina < 100) {
          if (user.oporayam >= count * 1) {
            user.oporayam -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Opor ayam kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "rendang":
        if (user.stamina < 100) {
          if (user.rendang >= count * 1) {
            user.rendang -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Rendang kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "steak":
        if (user.stamina < 100) {
          if (user.steak >= count * 1) {
            user.steak -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Steak kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "gulaiayam":
        if (user.stamina < 100) {
          if (user.gulaiayam >= count * 1) {
            user.gulaiayam -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Gulai ayam kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "babipanggang":
        if (user.stamina < 100) {
          if (user.babipanggang >= count * 1) {
            user.babipanggang -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Babi panggang kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "soda":
        if (user.stamina < 100) {
          if (user.soda >= count * 1) {
            user.soda -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Glek glek glek`);
          } else m.reply(` Soda kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "vodka":
        if (user.stamina < 100) {
          if (user.vodka >= count * 1) {
            user.vodka -= count * 1;
            user.stamina += 25 * count;
            m.reply(`Glek Glek Glek`);
          } else m.reply(` Vodka kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "ganja":
        if (user.stamina < 100) {
          if (user.ganja >= count * 1) {
            user.ganja -= count * 1;
            user.healt += 90 * count;
            m.reply(`ngefly`);
          } else m.reply(` Ganja kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "bandage":
        if (user.stamina < 100) {
          if (user.bandage >= count * 1) {
            user.bandage -= count * 1;
            user.healt += 25 * count;
            m.reply(`Sretset`);
          } else m.reply(` Bandage kamu kurang`);
        } else m.reply(`Healt kamu sudah penuh`);
        break;
      case "sushi":
        if (user.stamina < 100) {
          if (user.sushi >= count * 1) {
            user.sushi -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Sushi kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
        break;
      case "roti":
        if (user.stamina < 100) {
          if (user.roti >= count * 1) {
            user.roti -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` Roti kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "ikanbakar":
        if (user.stamina < 100) {
          if (user.ikanbakar >= count * 1) {
            user.ikanbakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` ikan bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "lelebakar":
        if (user.stamina < 100) {
          if (user.lelebakar >= count * 1) {
            user.lelebakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` lele bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "nilabakar":
        if (user.stamina < 100) {
          if (user.nilabakar >= count * 1) {
            user.nilabakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` nila bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "bawalbakar":
        if (user.stamina < 100) {
          if (user.bawalbakar >= count * 1) {
            user.bawalbakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` bawal bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "udangbakar":
        if (user.stamina < 100) {
          if (user.udangbakar >= count * 1) {
            user.udangbakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` udang bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "pausbakar":
        if (user.stamina < 100) {
          if (user.pausbakar >= count * 1) {
            user.pausbakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` paus bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      case "kepitingbakar":
        if (user.stamina < 100) {
          if (user.kepitingbakar >= count * 1) {
            user.kepitingbakar -= count * 1;
            user.stamina += 20 * count;
            m.reply(`Nyam nyam`);
          } else m.reply(` kepiting bakar kamu kurang`);
        } else m.reply(`Stamina kamu sudah penuh`);
        break;
      default:
        await m.reply(list);
    }
  } else if (/p/i.test(command)) {
    const count =
      args[2] && args[2].length > 0
        ? Math.min(99999999, Math.max(parseInt(args[2]), 1))
        : !args[2] || args.length < 4
          ? 1
          : Math.min(1, count);
    switch (_type) {
      case "p":
        break;
      default:
        return m.reply(list);
    }

    console.log(e);
  }
};

handler.help = ["eat", "makan"];
handler.tags = ["rpg"];
handler.register = true;
handler.command = ["eat", "makan"];
handler.rpg = true;
handler.group = true;

module.exports = handler;

