const cheerio = require('cheerio');
const axios = require("axios")
const PDFDocument = require('pdfkit');
const fs = require("fs")
const imageSize = require('image-size');

let handler = async (m, { conn, text, usedPrefix, command }) => {
conn.nhentai = conn.nhentai ? conn.nhentai : {};
if (!text) throw "Masukan code nuklir nya kak"
if (!isNaN(text)) {
let p = await Func.fetchJson(`https://cin.monster/v/${text}`)
const $ = cheerio.load(p);
const scriptTag = $('script[type="application/json"]');
if (scriptTag.length == 0) throw "Code yang kamu berikan tidak dapat di temukan"
m.reply(`${wait}\n> Waktu yg di butuhkan untuk mengirim file tergantung oleh ukuran file`)
const json = JSON.parse(scriptTag.text());
const images = json.props.pageProps.data.images.pages
const title = json.props.pageProps.data.title.english || json.props.pageProps.data.title.japanese
let pdf = new PDFDocument({
size: [Math.max(...images.map(img => img.w)), Math.max(...images.map(img => img.h))],
align: "center",
valign: "center"
});
for (let serah of images) {
try {
let tumbas_wedhus = await axios.get(serah.t, {
headers: {
referer: "https://cin.monster"
},
responseType: 'arraybuffer'
});
let buffer = tumbas_wedhus.data
const dimensions = imageSize(buffer);
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth;
const pageHeight = imgHeight + 100;
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(buffer, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Lucy bot +62 877-7767-9087`, 250, 550);
} catch (error) {
console.log(`Error fetching image ${i + 1}: ${error.message}`);
continue;
}
}
const pdfStream = fs.createWriteStream("gambar.pdf");
pdf.pipe(pdfStream);
pdf.end();
pdfStream.on('finish', () => {
const hasilpdf = fs.readFileSync('gambar.pdf');
conn.sendMessage(m.chat, { document: hasilpdf, mimetype: "application/pdf", fileName: title, caption: done }, { quoted: m });
fs.unlinkSync('gambar.pdf');
})
} else {
let apa = await scrapeSearchH(text)
if (apa.length == 0) throw "Query yang kamu masukan tidak ditemukan"
let hasil = apa
      .map(
        (v, index) =>
          `*${index + 1}.* *Title:* ${v.caption}`,
      )
      .join("\n\n");
    let { key } = await await conn.reply(m.chat, hasil, m, {
contextInfo: {
mentionedJid: [],
groupMentions: [],
externalAdReply: {
title: "nhentai.com",
body: "Created by Mephistod",
thumbnailUrl: "https://files.catbox.moe/4sw2hw.jpg",
sourceUrl: "",
mediaType: 1,
renderLargerThumbnail: true,
},
},
});
    await conn.reply(
      m.chat,
      `Ketik angka *1 - ${apa.length}* sesuai dengan pesan di atas`,
      null,
    );
    conn.nhentai[m.sender] = apa;      
}
}
handler.before = async (m, { conn }) => {
    conn.nhentai = conn.nhentai ? conn.nhentai : {};
    if (m.isBaileys) return;
    if (!m.text) return;
    if (!conn.nhentai[m.sender]) return;
    if (
      isNaN(m.text) ||
      m.text <= 0 ||
      m.text > conn.nhentai[m.sender].length
    )
      return;
      
    let pilihan = conn.nhentai[m.sender][m.text - 1].code
let p = await Func.fetchJson(`https://cin.monster/v/${pilihan}`)
const $ = cheerio.load(p);
const scriptTag = $('script[type="application/json"]');
if (scriptTag.length == 0) throw "Code yang kamu berikan tidak dapat di temukan"
m.reply(`${wait}\n> Waktu yg di butuhkan untuk mengirim file tergantung oleh ukuran file`)
const json = JSON.parse(scriptTag.text());
const images = json.props.pageProps.data.images.pages
const title = json.props.pageProps.data.title.english || json.props.pageProps.data.title.japanese
const pdf = new PDFDocument({
layout: 'portrait',
margins: {
top: 50,
bottom: 50,
left: 50,
right: 50
}
});
for (let serah of images) {
try {
let tumbas_wedhus = await axios.get(serah.t, {
headers: {
referer: "https://cin.monster"
},
responseType: 'arraybuffer'
});
let buffer = tumbas_wedhus.data
const dimensions = imageSize(buffer);
const imgWidth = dimensions.width;
const imgHeight = dimensions.height;
const pageWidth = imgWidth;
const pageHeight = imgHeight + 100;
pdf.addPage({ size: [pageWidth, pageHeight] });
pdf.image(buffer, 0, 0, { width: imgWidth, height: imgHeight });
pdf.fontSize(24).text(`Makima bot +62 838-3991-6169`, 250, 550);
} catch (error) {
console.log(`Error fetching image ${error.message}`);
continue;
}
}
const pdfStream = fs.createWriteStream("gambar.pdf");
pdf.pipe(pdfStream);
pdf.end();
pdfStream.on('finish', () => {
const hasilpdf = fs.readFileSync('gambar.pdf');
conn.sendMessage(m.chat, { document: hasilpdf, mimetype: "application/pdf", fileName: title, caption: done }, { quoted: m });
fs.unlinkSync('gambar.pdf');
delete conn.nhentai[m.sender];
})
}
handler.help = ["nhentai"].map((a) => a + " *[code]*");
handler.tags = ["premium"];
handler.command = ["nhentai"];
handler.premium = true;

handler.register = true;
module.exports = handler;

async function scrapeSearchH(nama) {
const result = [];
let page = 1;
let hasNextPage = true;
while (hasNextPage && page <= 20) {
const url = `https://nhentai.net/search/?q=${nama}&page=${page}`;
const html = await Func.fetchJson(url);
const $ = cheerio.load(html);
const galleries = $('.gallery');
if (galleries.length === 0) {
hasNextPage = false;
} else {
galleries.each((index, gallery) => {
const href = $(gallery).find('a').attr('href');
const code = href.match(/\/g\/(\d+)/)[1];
const caption = $(gallery).find('.caption').text().trim();
result.push({ code, caption });
});
page++;
}
}
return result
}