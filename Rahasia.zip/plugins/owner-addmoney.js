const handler = async (m, { conn, text, command }) => {

  if (!text) throw "Masukkan jumlah money yang akan diberi";
  let who;

  if (m.isGroup) who = m.mentionedJid[0];
  else who = m.chat;

  if (!who) throw "Tag salah satu lah";
  let txt = text.replace("@" + who.split`@`[0], "").trim();

  if (isNaN(txt)) throw "Hanya angka";

  let poin = parseInt(txt);
  let money = poin;

  if (money < 1) throw "Minimal 1";
  if (money > 1000000000000) throw "Lu mau bot jadi lemot?????";

  let users = global.db.data.users;
  users[who].money += poin;
  m.reply(`Selamat @${who.split`@`[0]}. Kamu mendapatkan +${poin} MONEY!`);
};

handler.help = ["addmoney *[@user] [jumlah]*"];
handler.tags = ["owner"];
handler.command =["addmoney"];
handler.owner = true
handler.group = true;

module.exports = handler;