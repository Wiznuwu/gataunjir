const uploadImage = require("../lib/uploadFile");
let handler = async (m, { conn, args, usedPrefix, command }) => {
  let text;
  if (args.length >= 1) {
    text = args.slice(0).join(" ");
  } else if (m.quoted && m.quoted.text) {
    text = `apa maksunya\n${m.quoted.text}`
  } else return m.reply("• *Example :* .gemini halo");
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  let { key } = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });
     try {
     let option = {
  messages: [
    { role: "system", content: `Kamu adalah Ai yang serba bisa bernama Lucy, saat ini kami sedang berbicara dengan ${conn.getName(m.sender)}` },
    { role: "user", content: text }
  ],
  temperature: 0.3,
  top_p: 0.9,
  top_k: 40
}
        let res = await Scraper["Ai"].gemini(option);
         await conn.sendMessage(
      m.chat,
      { text: `*[ GEMINI RESPONSE ]*\n${res.answer}`, edit: key },
      { quoted: m },
    );
    } catch (e) {
      throw e;
    }
};
handler.help = ["gemini"].map((a) => a + " *[query]*");
handler.tags = ["ai"];
handler.command = /^(gemini)$/i;
module.exports = handler;