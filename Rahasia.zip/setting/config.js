
module.exports = {
    // Bot settings
    namebot: "MakimaBot",
    nameowner: "MEPSHISTOD",
    nomorown: "6281244622905",
    
    // Other settings
    autoread: true,
    autoketik: true,
    autorecording: true,
    autobio: true,
    autoblok212: true,
    onlyindo: true,
    packname: "Created By",
    author: "MakimaBot",
    sessionName: "session",
    prefa: ".",
    self: false
};