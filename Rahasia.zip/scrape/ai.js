const WebSocket = require("ws");
const axios = require("axios");
const cheerio = require("cheerio");

function generateRandomUserAgent() {
  const androidVersions = [
    "4.0.3",
    "4.1.1",
    "4.2.2",
    "4.3",
    "4.4",
    "5.0.2",
    "5.1",
    "6.0",
    "7.0",
    "8.0",
    "9.0",
    "10.0",
    "11.0",
  ];
  const deviceModels = [
    "M2004J19C",
    "S2020X3",
    "Xiaomi4S",
    "RedmiNote9",
    "SamsungS21",
    "GooglePixel5",
  ];
  const buildVersions = [
    "RP1A.200720.011",
    "RP1A.210505.003",
    "RP1A.210812.016",
    "QKQ1.200114.002",
    "RQ2A.210505.003",
  ];
  const selectedModel =
    deviceModels[Math.floor(Math.random() * deviceModels.length)];
  const selectedBuild =
    buildVersions[Math.floor(Math.random() * buildVersions.length)];
  const chromeVersion =
    "Chrome/" +
    (Math.floor(Math.random() * 80) + 1) +
    "." +
    (Math.floor(Math.random() * 999) + 1) +
    "." +
    (Math.floor(Math.random() * 9999) + 1);
  const userAgent = `Mozilla/5.0 (Linux; Android ${androidVersions[Math.floor(Math.random() * androidVersions.length)]}; ${selectedModel} Build/${selectedBuild}) AppleWebKit/537.36 (KHTML, like Gecko) ${chromeVersion} Mobile Safari/537.36 WhatsApp/1.${Math.floor(Math.random() * 9) + 1}.${Math.floor(Math.random() * 9) + 1}`;
  return userAgent;
}

function generateRandomIP() {
  const octet = () => Math.floor(Math.random() * 256);
  return `${octet()}.${octet()}.${octet()}.${octet()}`;
}

async function talkai(type, message) {
  try {
    const headers = {
      "User-Agent": generateRandomUserAgent(),
      Referer: "https://talkai.info/id/chat/",
      "X-Forwarded-For": generateRandomIP(),
    };

    const data = {
      temperature: 1,
      frequency_penalty: 0,
      type: type,
      messagesHistory: [
        {
          from: "chatGPT",
          content:
            "Nama ku akiraa aku adalah maskot dari TalkAi sedang bisa membantu mu 😋👍",
        },
        {
          from: "you",
          content: message,
        },
      ],
      message: message,
    };

    let response;

    try {
      response = await axios.post("https://talkai.info/id/chat/send/", data, {
        headers,
      });
    } catch (sendError) {
      console.error(
        'Error with "send" request. Falling back to "send2".',
        sendError,
      );
      // If "send" fails, try "send2"
      response = await axios.post("https://talkai.info/id/chat/send2/", data, {
        headers,
      });
    }

    return response.data;
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
  }
}
async function BlackBox(text) {
  return new Promise(async (resolve, reject) => {
    try {
      const danz = await axios.post(
        "https://www.useblackbox.io/chat-request-v4",
        {
          text: text,
          allMessages: [
            {
              user: text,
            },
          ],
          stream: "",
          clickedContinue: false,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "User-Agent":
              "Mozilla/5.0 (Linux x86_64) Gecko/20130401 Firefox/71.3",
          },
        },
      );
      resolve(danz.data);
    } catch (e) {
      reject(e);
    }
  });
}
const soVits = {
  model: async (number) => {
    return new Promise(async (resolve) => {
      const { data } = await axios.get(
        "https://raw.githubusercontent.com/ArifzynXD/database/master/ai/anime.json",
      );
      const model = data.model[number.toString()];

      if (model) {
        resolve(model);
      } else {
        resolve(data);
      }
    });
  },
  language: async (id) => {
    return new Promise(async (resolve) => {
      const { data } = await axios.get(
        "https://raw.githubusercontent.com/ArifzynXD/database/master/ai/anime.json",
      );
      const lang = data.language[id.toString()];

      if (lang) {
        resolve(lang);
      } else {
        resolve(data);
      }
    });
  },
  generate: async (text, model_id, language) => {
    return new Promise(async (resolve, reject) => {
      const model = await this.model(model_id);
      const lang = await this.language(language);

      const send_hash = {
        session_hash: "4odx020bres",
        fn_index: 2,
      };
      const send_data = {
        fn_index: 2,
        data: [text, model, lang, 1, false],
        session_hash: "4odx020bres",
      };
      const result = {};

      const ws = new WebSocket(
        "wss://plachta-vits-umamusume-voice-synthesizer.hf.space/queue/join",
      );

      ws.onopen = function () {
        console.log("Connected to websocket");
      };

      ws.onmessage = async function (event) {
        let message = JSON.parse(event.data);
        switch (message.msg) {
          case "send_hash":
            ws.send(JSON.stringify(send_hash));
            break;
          case "estimation":
            console.log("Menunggu antrean: ️" + message.rank);
            break;
          case "send_data":
            console.log("Processing your audio....");
            ws.send(JSON.stringify(send_data));
            break;
          case "process_completed":
            result.url =
              "https://plachta-vits-umamusume-voice-synthesizer.hf.space/file=" +
              message.output.data[1].name;
            break;
        }
      };

      ws.onclose = function (event) {
        if (event.code === 1000) {
          console.log("Process completed️");
        } else {
          console.log("Err : WebSocket Connection Error:\n");
        }
        resolve(result);
      };
    });
  },
};
async function imgToPrompt(url) {
  try {
    const response = await fetch(url);
    const imageData = await response.buffer();
    const imageBase64 = Buffer.from(imageData).toString("base64");

    const payload = {
      consume_points: 1,
      image: imageBase64,
    };

    const headers = {
      "Content-Type": "application/json",
      Cookie:
        "_ga=GA1.1.1902043976.1711876868; _ga_WQ0WB7ZY96=GS1.1.1711876868.1.1.1711877146.0.0.0",
      Origin: "https://animegenius.live3d.io",
      Referer: "https://animegenius.live3d.io/",
      Authorization:
        "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MTI5MTQyMTIsInN1YiI6Imdvb2dsZSAxNjEzMTIzIGdlbnR1cnN5MDJAZ21haWwuY29tIn0.niSNoUYnECi7nKdY9BObDHAt_EX-FsLcdhxfoUCWbbs",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    };

    const result = await fetch(
      "https://api.live3d.io/api/v1/generation/img2prompt",
      {
        method: "POST",
        headers: headers,
        body: JSON.stringify(payload),
      },
    );

    const responseData = await result.json();
    return responseData;
  } catch (error) {
    console.error("Terjadi kesalahan:", error.message);
    return null;
  }
}

async function gemini(options) {
  try {
    return await new Promise(async(resolve, reject) => {
      options = {
        model: "gemini-pro",
        messages: options?.messages,
        temperature: options?.temperature || 0.9,
        top_p: options?.top_p || 0.7,
        top_k: options?.top_p || 40,
      }
      if(!options?.messages) return reject("missing messages input payload!");
      if(!Array.isArray(options?.messages)) return reject("invalid array in messages input payload!");
      if(isNaN(options?.top_p)) return reject("invalid number in top_p payload!");
      if(isNaN(options?.top_k)) return reject("invalid number in top_k payload!");
      axios.post("https://api.acloudapp.com/v1/completions", options, {
        headers: {
          authorization: "sk-9jL26pavtzAHk9mdF0A5AeAfFcE1480b9b06737d9eC62c1e"
        }
      }).then(res => {
        const data = res.data;
        if(!data.choices[0].message.content) return reject("failed get response message!")
        resolve({
          success: true,
          answer: data.choices[0].message.content
        })
      }).catch(reject)
    })
  } catch (e) {
    return {
      success: false,
      errors: [e]
    }
  }
}

async function gpt4o(query, orang) {
  try {
    const response = await axios.post('https://api.yanzbotz.my.id/api/ai/gpt4', {
      query: query,
      prompt: `Saya adalah Lucy-GPT asisten virtual yang canggih dan populer saat ini, saya di ciptakan oleh Mephistod Dev, dan saat ini saya sedang berbicara dengan ${orang}`
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const regex = /"answer":"([^"]*)"/g;
    let match;
    let result = '';
    while ((match = regex.exec(response.data)) !== null) {
      result += match[1];
    }

    return result.replace(/\\n/g, '\n')
      .replace(/\\/g, '')
      .replace(/\*\*/g, '*')
      .replace(/###/g, '>');
  } catch (e) {
    reject(e);
   }
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

async function ambatronAi(content) {
  return new Promise(async (resolve, reject) => {
    const url = 'https://www.blackbox.ai/api/chat';

    const headers = {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36',
      'Referer': 'https://www.blackbox.ai/agent/ambatron'
    };

    const body = {
      messages: [
        {
          id: generateId(),
          content,
          role: "user"
        }
      ],
      id: generateId(),
      previewToken: null,
      userId: null,
      codeModelMode: true,
      agentMode: {
        mode: true,
        id: "ambatron",
        name: "Ambatron"
      },
      trendingAgentMode: {},
      isMicMode: false,
      maxTokens: 1024,
      isChromeExt: false,
      githubToken: null,
      clickedAnswer2: false,
      clickedAnswer3: false,
      clickedForceWebSearch: false,
      visitFromDelta: false,
      mobileClient: false
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(body),
        compress: true
      });

      let data = await response.text(); 
      data = data.replace(/^\$@\$.+?\$@\$/, '');

      resolve(data);
    } catch (e) {
      reject('Error:', e);
    }
  });
}

async function aiCai(name, chara_id, text) {

  try {

    const response = await axios.post(

      'https://api.apigratis.site/cai/send_message',

      {

        external_id: chara_id,

        message: `*Lanjutan Roleplay Menggunakan Bahasa Indonesia*\n\n(Saat ini Kamu sedang berbicara dengan ${conn.getName(name)}, berikan jawaban sesuai konteks percakapan)\n${conn.getName(name)}: ${text}`,

      }

    );

    return response.data.result.replies[0].text;

  } catch (error) {

    console.error('Terjadi kesalahan saat mengirim pesan:', error);

    return null; // Atau return nilai default lainnya

  }

}

module.exports = {
  ambatronAi,
  talkai,
  BlackBox,
  soVits,
  imgToPrompt,
  gpt4o,
  aiCai,
  gemini,
};

let fs = require("fs");
let chalk = require("chalk");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update scrape"));
  delete require.cache[file];
  require(file);
});
